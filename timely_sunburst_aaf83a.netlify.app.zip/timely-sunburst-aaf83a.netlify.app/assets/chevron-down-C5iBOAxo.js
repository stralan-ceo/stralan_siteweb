import {
    c as o
} from "./index-avb3Y0q4.js";
const c = [
        ["path", {
            d: "M5 12h14",
            key: "1ays0h"
        }],
        ["path", {
            d: "m12 5 7 7-7 7",
            key: "xquz4c"
        }]
    ],
    t = o("arrow-right", c);
const n = [
        ["path", {
            d: "m6 9 6 6 6-6",
            key: "qrunsl"
        }]
    ],
    e = o("chevron-down", n);
export {
    t as A, e as C
};