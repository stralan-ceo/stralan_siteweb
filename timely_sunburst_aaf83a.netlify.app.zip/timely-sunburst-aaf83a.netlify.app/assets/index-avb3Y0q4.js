const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/faq-NaKEF1lm.js", "assets/chevron-down-C5iBOAxo.js", "assets/index-AJhdsfAu.js"]))) => i.map(i => d[i]);

function i0(a) {
    return a && a.__esModule && Object.prototype.hasOwnProperty.call(a, "default") ? a.default : a
}
var Qo = {
        exports: {}
    },
    Ai = {};
var Om;

function u0() {
    if (Om) return Ai;
    Om = 1;
    var a = Symbol.for("react.transitional.element"),
        i = Symbol.for("react.fragment");

    function u(r, c, f) {
        var h = null;
        if (f !== void 0 && (h = "" + f), c.key !== void 0 && (h = "" + c.key), "key" in c) {
            f = {};
            for (var y in c) y !== "key" && (f[y] = c[y])
        } else f = c;
        return c = f.ref, {
            $$typeof: a,
            type: r,
            key: h,
            ref: c !== void 0 ? c : null,
            props: f
        }
    }
    return Ai.Fragment = i, Ai.jsx = u, Ai.jsxs = u, Ai
}
var zm;

function s0() {
    return zm || (zm = 1, Qo.exports = u0()), Qo.exports
}
var Z = s0(),
    Zo = {
        exports: {}
    },
    rt = {};
var Cm;

function r0() {
    if (Cm) return rt;
    Cm = 1;
    var a = Symbol.for("react.transitional.element"),
        i = Symbol.for("react.portal"),
        u = Symbol.for("react.fragment"),
        r = Symbol.for("react.strict_mode"),
        c = Symbol.for("react.profiler"),
        f = Symbol.for("react.consumer"),
        h = Symbol.for("react.context"),
        y = Symbol.for("react.forward_ref"),
        p = Symbol.for("react.suspense"),
        m = Symbol.for("react.memo"),
        S = Symbol.for("react.lazy"),
        g = Symbol.for("react.activity"),
        _ = Symbol.iterator;

    function E(M) {
        return M === null || typeof M != "object" ? null : (M = _ && M[_] || M["@@iterator"], typeof M == "function" ? M : null)
    }
    var O = {
            isMounted: function() {
                return !1
            },
            enqueueForceUpdate: function() {},
            enqueueReplaceState: function() {},
            enqueueSetState: function() {}
        },
        w = Object.assign,
        A = {};

    function z(M, Y, k) {
        this.props = M, this.context = Y, this.refs = A, this.updater = k || O
    }
    z.prototype.isReactComponent = {}, z.prototype.setState = function(M, Y) {
        if (typeof M != "object" && typeof M != "function" && M != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
        this.updater.enqueueSetState(this, M, Y, "setState")
    }, z.prototype.forceUpdate = function(M) {
        this.updater.enqueueForceUpdate(this, M, "forceUpdate")
    };

    function X() {}
    X.prototype = z.prototype;

    function Q(M, Y, k) {
        this.props = M, this.context = Y, this.refs = A, this.updater = k || O
    }
    var H = Q.prototype = new X;
    H.constructor = Q, w(H, z.prototype), H.isPureReactComponent = !0;
    var W = Array.isArray;

    function F() {}
    var V = {
            H: null,
            A: null,
            T: null,
            S: null
        },
        J = Object.prototype.hasOwnProperty;

    function P(M, Y, k) {
        var I = k.ref;
        return {
            $$typeof: a,
            type: M,
            key: Y,
            ref: I !== void 0 ? I : null,
            props: k
        }
    }

    function ut(M, Y) {
        return P(M.type, Y, M.props)
    }

    function tt(M) {
        return typeof M == "object" && M !== null && M.$$typeof === a
    }

    function dt(M) {
        var Y = {
            "=": "=0",
            ":": "=2"
        };
        return "$" + M.replace(/[=:]/g, function(k) {
            return Y[k]
        })
    }
    var vt = /\/+/g;

    function Yt(M, Y) {
        return typeof M == "object" && M !== null && M.key != null ? dt("" + M.key) : Y.toString(36)
    }

    function Ot(M) {
        switch (M.status) {
            case "fulfilled":
                return M.value;
            case "rejected":
                throw M.reason;
            default:
                switch (typeof M.status == "string" ? M.then(F, F) : (M.status = "pending", M.then(function(Y) {
                    M.status === "pending" && (M.status = "fulfilled", M.value = Y)
                }, function(Y) {
                    M.status === "pending" && (M.status = "rejected", M.reason = Y)
                })), M.status) {
                    case "fulfilled":
                        return M.value;
                    case "rejected":
                        throw M.reason
                }
        }
        throw M
    }

    function B(M, Y, k, I, at) {
        var ft = typeof M;
        (ft === "undefined" || ft === "boolean") && (M = null);
        var St = !1;
        if (M === null) St = !0;
        else switch (ft) {
            case "bigint":
            case "string":
            case "number":
                St = !0;
                break;
            case "object":
                switch (M.$$typeof) {
                    case a:
                    case i:
                        St = !0;
                        break;
                    case S:
                        return St = M._init, B(St(M._payload), Y, k, I, at)
                }
        }
        if (St) return at = at(M), St = I === "" ? "." + Yt(M, 0) : I, W(at) ? (k = "", St != null && (k = St.replace(vt, "$&/") + "/"), B(at, Y, k, "", function(tn) {
            return tn
        })) : at != null && (tt(at) && (at = ut(at, k + (at.key == null || M && M.key === at.key ? "" : ("" + at.key).replace(vt, "$&/") + "/") + St)), Y.push(at)), 1;
        St = 0;
        var Vt = I === "" ? "." : I + ":";
        if (W(M))
            for (var Dt = 0; Dt < M.length; Dt++) I = M[Dt], ft = Vt + Yt(I, Dt), St += B(I, Y, k, ft, at);
        else if (Dt = E(M), typeof Dt == "function")
            for (M = Dt.call(M), Dt = 0; !(I = M.next()).done;) I = I.value, ft = Vt + Yt(I, Dt++), St += B(I, Y, k, ft, at);
        else if (ft === "object") {
            if (typeof M.then == "function") return B(Ot(M), Y, k, I, at);
            throw Y = String(M), Error("Objects are not valid as a React child (found: " + (Y === "[object Object]" ? "object with keys {" + Object.keys(M).join(", ") + "}" : Y) + "). If you meant to render a collection of children, use an array instead.")
        }
        return St
    }

    function K(M, Y, k) {
        if (M == null) return M;
        var I = [],
            at = 0;
        return B(M, I, "", "", function(ft) {
            return Y.call(k, ft, at++)
        }), I
    }

    function it(M) {
        if (M._status === -1) {
            var Y = M._result;
            Y = Y(), Y.then(function(k) {
                (M._status === 0 || M._status === -1) && (M._status = 1, M._result = k)
            }, function(k) {
                (M._status === 0 || M._status === -1) && (M._status = 2, M._result = k)
            }), M._status === -1 && (M._status = 0, M._result = Y)
        }
        if (M._status === 1) return M._result.default;
        throw M._result
    }
    var Rt = typeof reportError == "function" ? reportError : function(M) {
            if (typeof window == "object" && typeof window.ErrorEvent == "function") {
                var Y = new window.ErrorEvent("error", {
                    bubbles: !0,
                    cancelable: !0,
                    message: typeof M == "object" && M !== null && typeof M.message == "string" ? String(M.message) : String(M),
                    error: M
                });
                if (!window.dispatchEvent(Y)) return
            } else if (typeof process == "object" && typeof process.emit == "function") {
                process.emit("uncaughtException", M);
                return
            }
            console.error(M)
        },
        At = {
            map: K,
            forEach: function(M, Y, k) {
                K(M, function() {
                    Y.apply(this, arguments)
                }, k)
            },
            count: function(M) {
                var Y = 0;
                return K(M, function() {
                    Y++
                }), Y
            },
            toArray: function(M) {
                return K(M, function(Y) {
                    return Y
                }) || []
            },
            only: function(M) {
                if (!tt(M)) throw Error("React.Children.only expected to receive a single React element child.");
                return M
            }
        };
    return rt.Activity = g, rt.Children = At, rt.Component = z, rt.Fragment = u, rt.Profiler = c, rt.PureComponent = Q, rt.StrictMode = r, rt.Suspense = p, rt.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = V, rt.__COMPILER_RUNTIME = {
        __proto__: null,
        c: function(M) {
            return V.H.useMemoCache(M)
        }
    }, rt.cache = function(M) {
        return function() {
            return M.apply(null, arguments)
        }
    }, rt.cacheSignal = function() {
        return null
    }, rt.cloneElement = function(M, Y, k) {
        if (M == null) throw Error("The argument must be a React element, but you passed " + M + ".");
        var I = w({}, M.props),
            at = M.key;
        if (Y != null)
            for (ft in Y.key !== void 0 && (at = "" + Y.key), Y) !J.call(Y, ft) || ft === "key" || ft === "__self" || ft === "__source" || ft === "ref" && Y.ref === void 0 || (I[ft] = Y[ft]);
        var ft = arguments.length - 2;
        if (ft === 1) I.children = k;
        else if (1 < ft) {
            for (var St = Array(ft), Vt = 0; Vt < ft; Vt++) St[Vt] = arguments[Vt + 2];
            I.children = St
        }
        return P(M.type, at, I)
    }, rt.createContext = function(M) {
        return M = {
            $$typeof: h,
            _currentValue: M,
            _currentValue2: M,
            _threadCount: 0,
            Provider: null,
            Consumer: null
        }, M.Provider = M, M.Consumer = {
            $$typeof: f,
            _context: M
        }, M
    }, rt.createElement = function(M, Y, k) {
        var I, at = {},
            ft = null;
        if (Y != null)
            for (I in Y.key !== void 0 && (ft = "" + Y.key), Y) J.call(Y, I) && I !== "key" && I !== "__self" && I !== "__source" && (at[I] = Y[I]);
        var St = arguments.length - 2;
        if (St === 1) at.children = k;
        else if (1 < St) {
            for (var Vt = Array(St), Dt = 0; Dt < St; Dt++) Vt[Dt] = arguments[Dt + 2];
            at.children = Vt
        }
        if (M && M.defaultProps)
            for (I in St = M.defaultProps, St) at[I] === void 0 && (at[I] = St[I]);
        return P(M, ft, at)
    }, rt.createRef = function() {
        return {
            current: null
        }
    }, rt.forwardRef = function(M) {
        return {
            $$typeof: y,
            render: M
        }
    }, rt.isValidElement = tt, rt.lazy = function(M) {
        return {
            $$typeof: S,
            _payload: {
                _status: -1,
                _result: M
            },
            _init: it
        }
    }, rt.memo = function(M, Y) {
        return {
            $$typeof: m,
            type: M,
            compare: Y === void 0 ? null : Y
        }
    }, rt.startTransition = function(M) {
        var Y = V.T,
            k = {};
        V.T = k;
        try {
            var I = M(),
                at = V.S;
            at !== null && at(k, I), typeof I == "object" && I !== null && typeof I.then == "function" && I.then(F, Rt)
        } catch (ft) {
            Rt(ft)
        } finally {
            Y !== null && k.types !== null && (Y.types = k.types), V.T = Y
        }
    }, rt.unstable_useCacheRefresh = function() {
        return V.H.useCacheRefresh()
    }, rt.use = function(M) {
        return V.H.use(M)
    }, rt.useActionState = function(M, Y, k) {
        return V.H.useActionState(M, Y, k)
    }, rt.useCallback = function(M, Y) {
        return V.H.useCallback(M, Y)
    }, rt.useContext = function(M) {
        return V.H.useContext(M)
    }, rt.useDebugValue = function() {}, rt.useDeferredValue = function(M, Y) {
        return V.H.useDeferredValue(M, Y)
    }, rt.useEffect = function(M, Y) {
        return V.H.useEffect(M, Y)
    }, rt.useEffectEvent = function(M) {
        return V.H.useEffectEvent(M)
    }, rt.useId = function() {
        return V.H.useId()
    }, rt.useImperativeHandle = function(M, Y, k) {
        return V.H.useImperativeHandle(M, Y, k)
    }, rt.useInsertionEffect = function(M, Y) {
        return V.H.useInsertionEffect(M, Y)
    }, rt.useLayoutEffect = function(M, Y) {
        return V.H.useLayoutEffect(M, Y)
    }, rt.useMemo = function(M, Y) {
        return V.H.useMemo(M, Y)
    }, rt.useOptimistic = function(M, Y) {
        return V.H.useOptimistic(M, Y)
    }, rt.useReducer = function(M, Y, k) {
        return V.H.useReducer(M, Y, k)
    }, rt.useRef = function(M) {
        return V.H.useRef(M)
    }, rt.useState = function(M) {
        return V.H.useState(M)
    }, rt.useSyncExternalStore = function(M, Y, k) {
        return V.H.useSyncExternalStore(M, Y, k)
    }, rt.useTransition = function() {
        return V.H.useTransition()
    }, rt.version = "19.2.5", rt
}
var wm;

function Gi() {
    return wm || (wm = 1, Zo.exports = r0()), Zo.exports
}
var et = Gi();
const Ni = i0(et);
var Ko = {
        exports: {}
    },
    xi = {},
    Jo = {
        exports: {}
    },
    ko = {};
var Dm;

function o0() {
    return Dm || (Dm = 1, (function(a) {
        function i(B, K) {
            var it = B.length;
            B.push(K);
            t: for (; 0 < it;) {
                var Rt = it - 1 >>> 1,
                    At = B[Rt];
                if (0 < c(At, K)) B[Rt] = K, B[it] = At, it = Rt;
                else break t
            }
        }

        function u(B) {
            return B.length === 0 ? null : B[0]
        }

        function r(B) {
            if (B.length === 0) return null;
            var K = B[0],
                it = B.pop();
            if (it !== K) {
                B[0] = it;
                t: for (var Rt = 0, At = B.length, M = At >>> 1; Rt < M;) {
                    var Y = 2 * (Rt + 1) - 1,
                        k = B[Y],
                        I = Y + 1,
                        at = B[I];
                    if (0 > c(k, it)) I < At && 0 > c(at, k) ? (B[Rt] = at, B[I] = it, Rt = I) : (B[Rt] = k, B[Y] = it, Rt = Y);
                    else if (I < At && 0 > c(at, it)) B[Rt] = at, B[I] = it, Rt = I;
                    else break t
                }
            }
            return K
        }

        function c(B, K) {
            var it = B.sortIndex - K.sortIndex;
            return it !== 0 ? it : B.id - K.id
        }
        if (a.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
            var f = performance;
            a.unstable_now = function() {
                return f.now()
            }
        } else {
            var h = Date,
                y = h.now();
            a.unstable_now = function() {
                return h.now() - y
            }
        }
        var p = [],
            m = [],
            S = 1,
            g = null,
            _ = 3,
            E = !1,
            O = !1,
            w = !1,
            A = !1,
            z = typeof setTimeout == "function" ? setTimeout : null,
            X = typeof clearTimeout == "function" ? clearTimeout : null,
            Q = typeof setImmediate < "u" ? setImmediate : null;

        function H(B) {
            for (var K = u(m); K !== null;) {
                if (K.callback === null) r(m);
                else if (K.startTime <= B) r(m), K.sortIndex = K.expirationTime, i(p, K);
                else break;
                K = u(m)
            }
        }

        function W(B) {
            if (w = !1, H(B), !O)
                if (u(p) !== null) O = !0, F || (F = !0, dt());
                else {
                    var K = u(m);
                    K !== null && Ot(W, K.startTime - B)
                }
        }
        var F = !1,
            V = -1,
            J = 5,
            P = -1;

        function ut() {
            return A ? !0 : !(a.unstable_now() - P < J)
        }

        function tt() {
            if (A = !1, F) {
                var B = a.unstable_now();
                P = B;
                var K = !0;
                try {
                    t: {
                        O = !1,
                        w && (w = !1, X(V), V = -1),
                        E = !0;
                        var it = _;
                        try {
                            e: {
                                for (H(B), g = u(p); g !== null && !(g.expirationTime > B && ut());) {
                                    var Rt = g.callback;
                                    if (typeof Rt == "function") {
                                        g.callback = null, _ = g.priorityLevel;
                                        var At = Rt(g.expirationTime <= B);
                                        if (B = a.unstable_now(), typeof At == "function") {
                                            g.callback = At, H(B), K = !0;
                                            break e
                                        }
                                        g === u(p) && r(p), H(B)
                                    } else r(p);
                                    g = u(p)
                                }
                                if (g !== null) K = !0;
                                else {
                                    var M = u(m);
                                    M !== null && Ot(W, M.startTime - B), K = !1
                                }
                            }
                            break t
                        }
                        finally {
                            g = null, _ = it, E = !1
                        }
                        K = void 0
                    }
                }
                finally {
                    K ? dt() : F = !1
                }
            }
        }
        var dt;
        if (typeof Q == "function") dt = function() {
            Q(tt)
        };
        else if (typeof MessageChannel < "u") {
            var vt = new MessageChannel,
                Yt = vt.port2;
            vt.port1.onmessage = tt, dt = function() {
                Yt.postMessage(null)
            }
        } else dt = function() {
            z(tt, 0)
        };

        function Ot(B, K) {
            V = z(function() {
                B(a.unstable_now())
            }, K)
        }
        a.unstable_IdlePriority = 5, a.unstable_ImmediatePriority = 1, a.unstable_LowPriority = 4, a.unstable_NormalPriority = 3, a.unstable_Profiling = null, a.unstable_UserBlockingPriority = 2, a.unstable_cancelCallback = function(B) {
            B.callback = null
        }, a.unstable_forceFrameRate = function(B) {
            0 > B || 125 < B ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : J = 0 < B ? Math.floor(1e3 / B) : 5
        }, a.unstable_getCurrentPriorityLevel = function() {
            return _
        }, a.unstable_next = function(B) {
            switch (_) {
                case 1:
                case 2:
                case 3:
                    var K = 3;
                    break;
                default:
                    K = _
            }
            var it = _;
            _ = K;
            try {
                return B()
            } finally {
                _ = it
            }
        }, a.unstable_requestPaint = function() {
            A = !0
        }, a.unstable_runWithPriority = function(B, K) {
            switch (B) {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    break;
                default:
                    B = 3
            }
            var it = _;
            _ = B;
            try {
                return K()
            } finally {
                _ = it
            }
        }, a.unstable_scheduleCallback = function(B, K, it) {
            var Rt = a.unstable_now();
            switch (typeof it == "object" && it !== null ? (it = it.delay, it = typeof it == "number" && 0 < it ? Rt + it : Rt) : it = Rt, B) {
                case 1:
                    var At = -1;
                    break;
                case 2:
                    At = 250;
                    break;
                case 5:
                    At = 1073741823;
                    break;
                case 4:
                    At = 1e4;
                    break;
                default:
                    At = 5e3
            }
            return At = it + At, B = {
                id: S++,
                callback: K,
                priorityLevel: B,
                startTime: it,
                expirationTime: At,
                sortIndex: -1
            }, it > Rt ? (B.sortIndex = it, i(m, B), u(p) === null && B === u(m) && (w ? (X(V), V = -1) : w = !0, Ot(W, it - Rt))) : (B.sortIndex = At, i(p, B), O || E || (O = !0, F || (F = !0, dt()))), B
        }, a.unstable_shouldYield = ut, a.unstable_wrapCallback = function(B) {
            var K = _;
            return function() {
                var it = _;
                _ = K;
                try {
                    return B.apply(this, arguments)
                } finally {
                    _ = it
                }
            }
        }
    })(ko)), ko
}
var Lm;

function c0() {
    return Lm || (Lm = 1, Jo.exports = o0()), Jo.exports
}
var Po = {
        exports: {}
    },
    ce = {};
var Um;

function f0() {
    if (Um) return ce;
    Um = 1;
    var a = Gi();

    function i(p) {
        var m = "https://react.dev/errors/" + p;
        if (1 < arguments.length) {
            m += "?args[]=" + encodeURIComponent(arguments[1]);
            for (var S = 2; S < arguments.length; S++) m += "&args[]=" + encodeURIComponent(arguments[S])
        }
        return "Minified React error #" + p + "; visit " + m + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    }

    function u() {}
    var r = {
            d: {
                f: u,
                r: function() {
                    throw Error(i(522))
                },
                D: u,
                C: u,
                L: u,
                m: u,
                X: u,
                S: u,
                M: u
            },
            p: 0,
            findDOMNode: null
        },
        c = Symbol.for("react.portal");

    function f(p, m, S) {
        var g = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
        return {
            $$typeof: c,
            key: g == null ? null : "" + g,
            children: p,
            containerInfo: m,
            implementation: S
        }
    }
    var h = a.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;

    function y(p, m) {
        if (p === "font") return "";
        if (typeof m == "string") return m === "use-credentials" ? m : ""
    }
    return ce.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = r, ce.createPortal = function(p, m) {
        var S = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
        if (!m || m.nodeType !== 1 && m.nodeType !== 9 && m.nodeType !== 11) throw Error(i(299));
        return f(p, m, null, S)
    }, ce.flushSync = function(p) {
        var m = h.T,
            S = r.p;
        try {
            if (h.T = null, r.p = 2, p) return p()
        } finally {
            h.T = m, r.p = S, r.d.f()
        }
    }, ce.preconnect = function(p, m) {
        typeof p == "string" && (m ? (m = m.crossOrigin, m = typeof m == "string" ? m === "use-credentials" ? m : "" : void 0) : m = null, r.d.C(p, m))
    }, ce.prefetchDNS = function(p) {
        typeof p == "string" && r.d.D(p)
    }, ce.preinit = function(p, m) {
        if (typeof p == "string" && m && typeof m.as == "string") {
            var S = m.as,
                g = y(S, m.crossOrigin),
                _ = typeof m.integrity == "string" ? m.integrity : void 0,
                E = typeof m.fetchPriority == "string" ? m.fetchPriority : void 0;
            S === "style" ? r.d.S(p, typeof m.precedence == "string" ? m.precedence : void 0, {
                crossOrigin: g,
                integrity: _,
                fetchPriority: E
            }) : S === "script" && r.d.X(p, {
                crossOrigin: g,
                integrity: _,
                fetchPriority: E,
                nonce: typeof m.nonce == "string" ? m.nonce : void 0
            })
        }
    }, ce.preinitModule = function(p, m) {
        if (typeof p == "string")
            if (typeof m == "object" && m !== null) {
                if (m.as == null || m.as === "script") {
                    var S = y(m.as, m.crossOrigin);
                    r.d.M(p, {
                        crossOrigin: S,
                        integrity: typeof m.integrity == "string" ? m.integrity : void 0,
                        nonce: typeof m.nonce == "string" ? m.nonce : void 0
                    })
                }
            } else m == null && r.d.M(p)
    }, ce.preload = function(p, m) {
        if (typeof p == "string" && typeof m == "object" && m !== null && typeof m.as == "string") {
            var S = m.as,
                g = y(S, m.crossOrigin);
            r.d.L(p, S, {
                crossOrigin: g,
                integrity: typeof m.integrity == "string" ? m.integrity : void 0,
                nonce: typeof m.nonce == "string" ? m.nonce : void 0,
                type: typeof m.type == "string" ? m.type : void 0,
                fetchPriority: typeof m.fetchPriority == "string" ? m.fetchPriority : void 0,
                referrerPolicy: typeof m.referrerPolicy == "string" ? m.referrerPolicy : void 0,
                imageSrcSet: typeof m.imageSrcSet == "string" ? m.imageSrcSet : void 0,
                imageSizes: typeof m.imageSizes == "string" ? m.imageSizes : void 0,
                media: typeof m.media == "string" ? m.media : void 0
            })
        }
    }, ce.preloadModule = function(p, m) {
        if (typeof p == "string")
            if (m) {
                var S = y(m.as, m.crossOrigin);
                r.d.m(p, {
                    as: typeof m.as == "string" && m.as !== "script" ? m.as : void 0,
                    crossOrigin: S,
                    integrity: typeof m.integrity == "string" ? m.integrity : void 0
                })
            } else r.d.m(p)
    }, ce.requestFormReset = function(p) {
        r.d.r(p)
    }, ce.unstable_batchedUpdates = function(p, m) {
        return p(m)
    }, ce.useFormState = function(p, m, S) {
        return h.H.useFormState(p, m, S)
    }, ce.useFormStatus = function() {
        return h.H.useHostTransitionStatus()
    }, ce.version = "19.2.5", ce
}
var Nm;

function xy() {
    if (Nm) return Po.exports;
    Nm = 1;

    function a() {
        if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
            __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(a)
        } catch (i) {
            console.error(i)
        }
    }
    return a(), Po.exports = f0(), Po.exports
}
var Bm;

function d0() {
    if (Bm) return xi;
    Bm = 1;
    var a = c0(),
        i = Gi(),
        u = xy();

    function r(t) {
        var e = "https://react.dev/errors/" + t;
        if (1 < arguments.length) {
            e += "?args[]=" + encodeURIComponent(arguments[1]);
            for (var n = 2; n < arguments.length; n++) e += "&args[]=" + encodeURIComponent(arguments[n])
        }
        return "Minified React error #" + t + "; visit " + e + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    }

    function c(t) {
        return !(!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11)
    }

    function f(t) {
        var e = t,
            n = t;
        if (t.alternate)
            for (; e.return;) e = e.return;
        else {
            t = e;
            do e = t, (e.flags & 4098) !== 0 && (n = e.return), t = e.return; while (t)
        }
        return e.tag === 3 ? n : null
    }

    function h(t) {
        if (t.tag === 13) {
            var e = t.memoizedState;
            if (e === null && (t = t.alternate, t !== null && (e = t.memoizedState)), e !== null) return e.dehydrated
        }
        return null
    }

    function y(t) {
        if (t.tag === 31) {
            var e = t.memoizedState;
            if (e === null && (t = t.alternate, t !== null && (e = t.memoizedState)), e !== null) return e.dehydrated
        }
        return null
    }

    function p(t) {
        if (f(t) !== t) throw Error(r(188))
    }

    function m(t) {
        var e = t.alternate;
        if (!e) {
            if (e = f(t), e === null) throw Error(r(188));
            return e !== t ? null : t
        }
        for (var n = t, l = e;;) {
            var s = n.return;
            if (s === null) break;
            var o = s.alternate;
            if (o === null) {
                if (l = s.return, l !== null) {
                    n = l;
                    continue
                }
                break
            }
            if (s.child === o.child) {
                for (o = s.child; o;) {
                    if (o === n) return p(s), t;
                    if (o === l) return p(s), e;
                    o = o.sibling
                }
                throw Error(r(188))
            }
            if (n.return !== l.return) n = s, l = o;
            else {
                for (var d = !1, v = s.child; v;) {
                    if (v === n) {
                        d = !0, n = s, l = o;
                        break
                    }
                    if (v === l) {
                        d = !0, l = s, n = o;
                        break
                    }
                    v = v.sibling
                }
                if (!d) {
                    for (v = o.child; v;) {
                        if (v === n) {
                            d = !0, n = o, l = s;
                            break
                        }
                        if (v === l) {
                            d = !0, l = o, n = s;
                            break
                        }
                        v = v.sibling
                    }
                    if (!d) throw Error(r(189))
                }
            }
            if (n.alternate !== l) throw Error(r(190))
        }
        if (n.tag !== 3) throw Error(r(188));
        return n.stateNode.current === n ? t : e
    }

    function S(t) {
        var e = t.tag;
        if (e === 5 || e === 26 || e === 27 || e === 6) return t;
        for (t = t.child; t !== null;) {
            if (e = S(t), e !== null) return e;
            t = t.sibling
        }
        return null
    }
    var g = Object.assign,
        _ = Symbol.for("react.element"),
        E = Symbol.for("react.transitional.element"),
        O = Symbol.for("react.portal"),
        w = Symbol.for("react.fragment"),
        A = Symbol.for("react.strict_mode"),
        z = Symbol.for("react.profiler"),
        X = Symbol.for("react.consumer"),
        Q = Symbol.for("react.context"),
        H = Symbol.for("react.forward_ref"),
        W = Symbol.for("react.suspense"),
        F = Symbol.for("react.suspense_list"),
        V = Symbol.for("react.memo"),
        J = Symbol.for("react.lazy"),
        P = Symbol.for("react.activity"),
        ut = Symbol.for("react.memo_cache_sentinel"),
        tt = Symbol.iterator;

    function dt(t) {
        return t === null || typeof t != "object" ? null : (t = tt && t[tt] || t["@@iterator"], typeof t == "function" ? t : null)
    }
    var vt = Symbol.for("react.client.reference");

    function Yt(t) {
        if (t == null) return null;
        if (typeof t == "function") return t.$$typeof === vt ? null : t.displayName || t.name || null;
        if (typeof t == "string") return t;
        switch (t) {
            case w:
                return "Fragment";
            case z:
                return "Profiler";
            case A:
                return "StrictMode";
            case W:
                return "Suspense";
            case F:
                return "SuspenseList";
            case P:
                return "Activity"
        }
        if (typeof t == "object") switch (t.$$typeof) {
            case O:
                return "Portal";
            case Q:
                return t.displayName || "Context";
            case X:
                return (t._context.displayName || "Context") + ".Consumer";
            case H:
                var e = t.render;
                return t = t.displayName, t || (t = e.displayName || e.name || "", t = t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef"), t;
            case V:
                return e = t.displayName || null, e !== null ? e : Yt(t.type) || "Memo";
            case J:
                e = t._payload, t = t._init;
                try {
                    return Yt(t(e))
                } catch {}
        }
        return null
    }
    var Ot = Array.isArray,
        B = i.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
        K = u.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
        it = {
            pending: !1,
            data: null,
            method: null,
            action: null
        },
        Rt = [],
        At = -1;

    function M(t) {
        return {
            current: t
        }
    }

    function Y(t) {
        0 > At || (t.current = Rt[At], Rt[At] = null, At--)
    }

    function k(t, e) {
        At++, Rt[At] = t.current, t.current = e
    }
    var I = M(null),
        at = M(null),
        ft = M(null),
        St = M(null);

    function Vt(t, e) {
        switch (k(ft, e), k(at, t), k(I, null), e.nodeType) {
            case 9:
            case 11:
                t = (t = e.documentElement) && (t = t.namespaceURI) ? Ih(t) : 0;
                break;
            default:
                if (t = e.tagName, e = e.namespaceURI) e = Ih(e), t = Wh(e, t);
                else switch (t) {
                    case "svg":
                        t = 1;
                        break;
                    case "math":
                        t = 2;
                        break;
                    default:
                        t = 0
                }
        }
        Y(I), k(I, t)
    }

    function Dt() {
        Y(I), Y(at), Y(ft)
    }

    function tn(t) {
        t.memoizedState !== null && k(St, t);
        var e = I.current,
            n = Wh(e, t.type);
        e !== n && (k(at, t), k(I, n))
    }

    function en(t) {
        at.current === t && (Y(I), Y(at)), St.current === t && (Y(St), _i._currentValue = it)
    }
    var xn, Cl;

    function Ke(t) {
        if (xn === void 0) try {
            throw Error()
        } catch (n) {
            var e = n.stack.trim().match(/\n( *(at )?)/);
            xn = e && e[1] || "", Cl = -1 < n.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < n.stack.indexOf("@") ? "@unknown:0:0" : ""
        }
        return `
` + xn + t + Cl
    }
    var wl = !1;

    function ja(t, e) {
        if (!t || wl) return "";
        wl = !0;
        var n = Error.prepareStackTrace;
        Error.prepareStackTrace = void 0;
        try {
            var l = {
                DetermineComponentFrameRoot: function() {
                    try {
                        if (e) {
                            var G = function() {
                                throw Error()
                            };
                            if (Object.defineProperty(G.prototype, "props", {
                                    set: function() {
                                        throw Error()
                                    }
                                }), typeof Reflect == "object" && Reflect.construct) {
                                try {
                                    Reflect.construct(G, [])
                                } catch (N) {
                                    var U = N
                                }
                                Reflect.construct(t, [], G)
                            } else {
                                try {
                                    G.call()
                                } catch (N) {
                                    U = N
                                }
                                t.call(G.prototype)
                            }
                        } else {
                            try {
                                throw Error()
                            } catch (N) {
                                U = N
                            }(G = t()) && typeof G.catch == "function" && G.catch(function() {})
                        }
                    } catch (N) {
                        if (N && U && typeof N.stack == "string") return [N.stack, U.stack]
                    }
                    return [null, null]
                }
            };
            l.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
            var s = Object.getOwnPropertyDescriptor(l.DetermineComponentFrameRoot, "name");
            s && s.configurable && Object.defineProperty(l.DetermineComponentFrameRoot, "name", {
                value: "DetermineComponentFrameRoot"
            });
            var o = l.DetermineComponentFrameRoot(),
                d = o[0],
                v = o[1];
            if (d && v) {
                var R = d.split(`
`),
                    L = v.split(`
`);
                for (s = l = 0; l < R.length && !R[l].includes("DetermineComponentFrameRoot");) l++;
                for (; s < L.length && !L[s].includes("DetermineComponentFrameRoot");) s++;
                if (l === R.length || s === L.length)
                    for (l = R.length - 1, s = L.length - 1; 1 <= l && 0 <= s && R[l] !== L[s];) s--;
                for (; 1 <= l && 0 <= s; l--, s--)
                    if (R[l] !== L[s]) {
                        if (l !== 1 || s !== 1)
                            do
                                if (l--, s--, 0 > s || R[l] !== L[s]) {
                                    var j = `
` + R[l].replace(" at new ", " at ");
                                    return t.displayName && j.includes("<anonymous>") && (j = j.replace("<anonymous>", t.displayName)), j
                                }
                        while (1 <= l && 0 <= s);
                        break
                    }
            }
        } finally {
            wl = !1, Error.prepareStackTrace = n
        }
        return (n = t ? t.displayName || t.name : "") ? Ke(n) : ""
    }

    function Vi(t, e) {
        switch (t.tag) {
            case 26:
            case 27:
            case 5:
                return Ke(t.type);
            case 16:
                return Ke("Lazy");
            case 13:
                return t.child !== e && e !== null ? Ke("Suspense Fallback") : Ke("Suspense");
            case 19:
                return Ke("SuspenseList");
            case 0:
            case 15:
                return ja(t.type, !1);
            case 11:
                return ja(t.type.render, !1);
            case 1:
                return ja(t.type, !0);
            case 31:
                return Ke("Activity");
            default:
                return ""
        }
    }

    function nn(t) {
        try {
            var e = "",
                n = null;
            do e += Vi(t, n), n = t, t = t.return; while (t);
            return e
        } catch (l) {
            return `
Error generating stack: ` + l.message + `
` + l.stack
        }
    }
    var ra = Object.prototype.hasOwnProperty,
        Xe = a.unstable_scheduleCallback,
        Dl = a.unstable_cancelCallback,
        Qi = a.unstable_shouldYield,
        Cs = a.unstable_requestPaint,
        oe = a.unstable_now,
        Nt = a.unstable_getCurrentPriorityLevel,
        ae = a.unstable_ImmediatePriority,
        Je = a.unstable_UserBlockingPriority,
        Ha = a.unstable_NormalPriority,
        Yp = a.unstable_LowPriority,
        Cc = a.unstable_IdlePriority,
        Gp = a.log,
        Xp = a.unstable_setDisableYieldValue,
        Ll = null,
        Re = null;

    function Mn(t) {
        if (typeof Gp == "function" && Xp(t), Re && typeof Re.setStrictMode == "function") try {
            Re.setStrictMode(Ll, t)
        } catch {}
    }
    var Te = Math.clz32 ? Math.clz32 : Zp,
        Vp = Math.log,
        Qp = Math.LN2;

    function Zp(t) {
        return t >>>= 0, t === 0 ? 32 : 31 - (Vp(t) / Qp | 0) | 0
    }
    var Zi = 256,
        Ki = 262144,
        Ji = 4194304;

    function oa(t) {
        var e = t & 42;
        if (e !== 0) return e;
        switch (t & -t) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 4:
                return 4;
            case 8:
                return 8;
            case 16:
                return 16;
            case 32:
                return 32;
            case 64:
                return 64;
            case 128:
                return 128;
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
                return t & 261888;
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
                return t & 3932160;
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
                return t & 62914560;
            case 67108864:
                return 67108864;
            case 134217728:
                return 134217728;
            case 268435456:
                return 268435456;
            case 536870912:
                return 536870912;
            case 1073741824:
                return 0;
            default:
                return t
        }
    }

    function ki(t, e, n) {
        var l = t.pendingLanes;
        if (l === 0) return 0;
        var s = 0,
            o = t.suspendedLanes,
            d = t.pingedLanes;
        t = t.warmLanes;
        var v = l & 134217727;
        return v !== 0 ? (l = v & ~o, l !== 0 ? s = oa(l) : (d &= v, d !== 0 ? s = oa(d) : n || (n = v & ~t, n !== 0 && (s = oa(n))))) : (v = l & ~o, v !== 0 ? s = oa(v) : d !== 0 ? s = oa(d) : n || (n = l & ~t, n !== 0 && (s = oa(n)))), s === 0 ? 0 : e !== 0 && e !== s && (e & o) === 0 && (o = s & -s, n = e & -e, o >= n || o === 32 && (n & 4194048) !== 0) ? e : s
    }

    function Ul(t, e) {
        return (t.pendingLanes & ~(t.suspendedLanes & ~t.pingedLanes) & e) === 0
    }

    function Kp(t, e) {
        switch (t) {
            case 1:
            case 2:
            case 4:
            case 8:
            case 64:
                return e + 250;
            case 16:
            case 32:
            case 128:
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
                return e + 5e3;
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
                return -1;
            case 67108864:
            case 134217728:
            case 268435456:
            case 536870912:
            case 1073741824:
                return -1;
            default:
                return -1
        }
    }

    function wc() {
        var t = Ji;
        return Ji <<= 1, (Ji & 62914560) === 0 && (Ji = 4194304), t
    }

    function ws(t) {
        for (var e = [], n = 0; 31 > n; n++) e.push(t);
        return e
    }

    function Nl(t, e) {
        t.pendingLanes |= e, e !== 268435456 && (t.suspendedLanes = 0, t.pingedLanes = 0, t.warmLanes = 0)
    }

    function Jp(t, e, n, l, s, o) {
        var d = t.pendingLanes;
        t.pendingLanes = n, t.suspendedLanes = 0, t.pingedLanes = 0, t.warmLanes = 0, t.expiredLanes &= n, t.entangledLanes &= n, t.errorRecoveryDisabledLanes &= n, t.shellSuspendCounter = 0;
        var v = t.entanglements,
            R = t.expirationTimes,
            L = t.hiddenUpdates;
        for (n = d & ~n; 0 < n;) {
            var j = 31 - Te(n),
                G = 1 << j;
            v[j] = 0, R[j] = -1;
            var U = L[j];
            if (U !== null)
                for (L[j] = null, j = 0; j < U.length; j++) {
                    var N = U[j];
                    N !== null && (N.lane &= -536870913)
                }
            n &= ~G
        }
        l !== 0 && Dc(t, l, 0), o !== 0 && s === 0 && t.tag !== 0 && (t.suspendedLanes |= o & ~(d & ~e))
    }

    function Dc(t, e, n) {
        t.pendingLanes |= e, t.suspendedLanes &= ~e;
        var l = 31 - Te(e);
        t.entangledLanes |= e, t.entanglements[l] = t.entanglements[l] | 1073741824 | n & 261930
    }

    function Lc(t, e) {
        var n = t.entangledLanes |= e;
        for (t = t.entanglements; n;) {
            var l = 31 - Te(n),
                s = 1 << l;
            s & e | t[l] & e && (t[l] |= e), n &= ~s
        }
    }

    function Uc(t, e) {
        var n = e & -e;
        return n = (n & 42) !== 0 ? 1 : Ds(n), (n & (t.suspendedLanes | e)) !== 0 ? 0 : n
    }

    function Ds(t) {
        switch (t) {
            case 2:
                t = 1;
                break;
            case 8:
                t = 4;
                break;
            case 32:
                t = 16;
                break;
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
                t = 128;
                break;
            case 268435456:
                t = 134217728;
                break;
            default:
                t = 0
        }
        return t
    }

    function Ls(t) {
        return t &= -t, 2 < t ? 8 < t ? (t & 134217727) !== 0 ? 32 : 268435456 : 8 : 2
    }

    function Nc() {
        var t = K.p;
        return t !== 0 ? t : (t = window.event, t === void 0 ? 32 : _m(t.type))
    }

    function Bc(t, e) {
        var n = K.p;
        try {
            return K.p = t, e()
        } finally {
            K.p = n
        }
    }
    var On = Math.random().toString(36).slice(2),
        le = "__reactFiber$" + On,
        he = "__reactProps$" + On,
        qa = "__reactContainer$" + On,
        Us = "__reactEvents$" + On,
        kp = "__reactListeners$" + On,
        Pp = "__reactHandles$" + On,
        jc = "__reactResources$" + On,
        Bl = "__reactMarker$" + On;

    function Ns(t) {
        delete t[le], delete t[he], delete t[Us], delete t[kp], delete t[Pp]
    }

    function Ya(t) {
        var e = t[le];
        if (e) return e;
        for (var n = t.parentNode; n;) {
            if (e = n[qa] || n[le]) {
                if (n = e.alternate, e.child !== null || n !== null && n.child !== null)
                    for (t = im(t); t !== null;) {
                        if (n = t[le]) return n;
                        t = im(t)
                    }
                return e
            }
            t = n, n = t.parentNode
        }
        return null
    }

    function Ga(t) {
        if (t = t[le] || t[qa]) {
            var e = t.tag;
            if (e === 5 || e === 6 || e === 13 || e === 31 || e === 26 || e === 27 || e === 3) return t
        }
        return null
    }

    function jl(t) {
        var e = t.tag;
        if (e === 5 || e === 26 || e === 27 || e === 6) return t.stateNode;
        throw Error(r(33))
    }

    function Xa(t) {
        var e = t[jc];
        return e || (e = t[jc] = {
            hoistableStyles: new Map,
            hoistableScripts: new Map
        }), e
    }

    function te(t) {
        t[Bl] = !0
    }
    var Hc = new Set,
        qc = {};

    function ca(t, e) {
        Va(t, e), Va(t + "Capture", e)
    }

    function Va(t, e) {
        for (qc[t] = e, t = 0; t < e.length; t++) Hc.add(e[t])
    }
    var Fp = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),
        Yc = {},
        Gc = {};

    function Ip(t) {
        return ra.call(Gc, t) ? !0 : ra.call(Yc, t) ? !1 : Fp.test(t) ? Gc[t] = !0 : (Yc[t] = !0, !1)
    }

    function Pi(t, e, n) {
        if (Ip(e))
            if (n === null) t.removeAttribute(e);
            else {
                switch (typeof n) {
                    case "undefined":
                    case "function":
                    case "symbol":
                        t.removeAttribute(e);
                        return;
                    case "boolean":
                        var l = e.toLowerCase().slice(0, 5);
                        if (l !== "data-" && l !== "aria-") {
                            t.removeAttribute(e);
                            return
                        }
                }
                t.setAttribute(e, "" + n)
            }
    }

    function Fi(t, e, n) {
        if (n === null) t.removeAttribute(e);
        else {
            switch (typeof n) {
                case "undefined":
                case "function":
                case "symbol":
                case "boolean":
                    t.removeAttribute(e);
                    return
            }
            t.setAttribute(e, "" + n)
        }
    }

    function an(t, e, n, l) {
        if (l === null) t.removeAttribute(n);
        else {
            switch (typeof l) {
                case "undefined":
                case "function":
                case "symbol":
                case "boolean":
                    t.removeAttribute(n);
                    return
            }
            t.setAttributeNS(e, n, "" + l)
        }
    }

    function De(t) {
        switch (typeof t) {
            case "bigint":
            case "boolean":
            case "number":
            case "string":
            case "undefined":
                return t;
            case "object":
                return t;
            default:
                return ""
        }
    }

    function Xc(t) {
        var e = t.type;
        return (t = t.nodeName) && t.toLowerCase() === "input" && (e === "checkbox" || e === "radio")
    }

    function Wp(t, e, n) {
        var l = Object.getOwnPropertyDescriptor(t.constructor.prototype, e);
        if (!t.hasOwnProperty(e) && typeof l < "u" && typeof l.get == "function" && typeof l.set == "function") {
            var s = l.get,
                o = l.set;
            return Object.defineProperty(t, e, {
                configurable: !0,
                get: function() {
                    return s.call(this)
                },
                set: function(d) {
                    n = "" + d, o.call(this, d)
                }
            }), Object.defineProperty(t, e, {
                enumerable: l.enumerable
            }), {
                getValue: function() {
                    return n
                },
                setValue: function(d) {
                    n = "" + d
                },
                stopTracking: function() {
                    t._valueTracker = null, delete t[e]
                }
            }
        }
    }

    function Bs(t) {
        if (!t._valueTracker) {
            var e = Xc(t) ? "checked" : "value";
            t._valueTracker = Wp(t, e, "" + t[e])
        }
    }

    function Vc(t) {
        if (!t) return !1;
        var e = t._valueTracker;
        if (!e) return !0;
        var n = e.getValue(),
            l = "";
        return t && (l = Xc(t) ? t.checked ? "true" : "false" : t.value), t = l, t !== n ? (e.setValue(t), !0) : !1
    }

    function Ii(t) {
        if (t = t || (typeof document < "u" ? document : void 0), typeof t > "u") return null;
        try {
            return t.activeElement || t.body
        } catch {
            return t.body
        }
    }
    var $p = /[\n"\\]/g;

    function Le(t) {
        return t.replace($p, function(e) {
            return "\\" + e.charCodeAt(0).toString(16) + " "
        })
    }

    function js(t, e, n, l, s, o, d, v) {
        t.name = "", d != null && typeof d != "function" && typeof d != "symbol" && typeof d != "boolean" ? t.type = d : t.removeAttribute("type"), e != null ? d === "number" ? (e === 0 && t.value === "" || t.value != e) && (t.value = "" + De(e)) : t.value !== "" + De(e) && (t.value = "" + De(e)) : d !== "submit" && d !== "reset" || t.removeAttribute("value"), e != null ? Hs(t, d, De(e)) : n != null ? Hs(t, d, De(n)) : l != null && t.removeAttribute("value"), s == null && o != null && (t.defaultChecked = !!o), s != null && (t.checked = s && typeof s != "function" && typeof s != "symbol"), v != null && typeof v != "function" && typeof v != "symbol" && typeof v != "boolean" ? t.name = "" + De(v) : t.removeAttribute("name")
    }

    function Qc(t, e, n, l, s, o, d, v) {
        if (o != null && typeof o != "function" && typeof o != "symbol" && typeof o != "boolean" && (t.type = o), e != null || n != null) {
            if (!(o !== "submit" && o !== "reset" || e != null)) {
                Bs(t);
                return
            }
            n = n != null ? "" + De(n) : "", e = e != null ? "" + De(e) : n, v || e === t.value || (t.value = e), t.defaultValue = e
        }
        l = l ? ? s, l = typeof l != "function" && typeof l != "symbol" && !!l, t.checked = v ? t.checked : !!l, t.defaultChecked = !!l, d != null && typeof d != "function" && typeof d != "symbol" && typeof d != "boolean" && (t.name = d), Bs(t)
    }

    function Hs(t, e, n) {
        e === "number" && Ii(t.ownerDocument) === t || t.defaultValue === "" + n || (t.defaultValue = "" + n)
    }

    function Qa(t, e, n, l) {
        if (t = t.options, e) {
            e = {};
            for (var s = 0; s < n.length; s++) e["$" + n[s]] = !0;
            for (n = 0; n < t.length; n++) s = e.hasOwnProperty("$" + t[n].value), t[n].selected !== s && (t[n].selected = s), s && l && (t[n].defaultSelected = !0)
        } else {
            for (n = "" + De(n), e = null, s = 0; s < t.length; s++) {
                if (t[s].value === n) {
                    t[s].selected = !0, l && (t[s].defaultSelected = !0);
                    return
                }
                e !== null || t[s].disabled || (e = t[s])
            }
            e !== null && (e.selected = !0)
        }
    }

    function Zc(t, e, n) {
        if (e != null && (e = "" + De(e), e !== t.value && (t.value = e), n == null)) {
            t.defaultValue !== e && (t.defaultValue = e);
            return
        }
        t.defaultValue = n != null ? "" + De(n) : ""
    }

    function Kc(t, e, n, l) {
        if (e == null) {
            if (l != null) {
                if (n != null) throw Error(r(92));
                if (Ot(l)) {
                    if (1 < l.length) throw Error(r(93));
                    l = l[0]
                }
                n = l
            }
            n == null && (n = ""), e = n
        }
        n = De(e), t.defaultValue = n, l = t.textContent, l === n && l !== "" && l !== null && (t.value = l), Bs(t)
    }

    function Za(t, e) {
        if (e) {
            var n = t.firstChild;
            if (n && n === t.lastChild && n.nodeType === 3) {
                n.nodeValue = e;
                return
            }
        }
        t.textContent = e
    }
    var tv = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));

    function Jc(t, e, n) {
        var l = e.indexOf("--") === 0;
        n == null || typeof n == "boolean" || n === "" ? l ? t.setProperty(e, "") : e === "float" ? t.cssFloat = "" : t[e] = "" : l ? t.setProperty(e, n) : typeof n != "number" || n === 0 || tv.has(e) ? e === "float" ? t.cssFloat = n : t[e] = ("" + n).trim() : t[e] = n + "px"
    }

    function kc(t, e, n) {
        if (e != null && typeof e != "object") throw Error(r(62));
        if (t = t.style, n != null) {
            for (var l in n) !n.hasOwnProperty(l) || e != null && e.hasOwnProperty(l) || (l.indexOf("--") === 0 ? t.setProperty(l, "") : l === "float" ? t.cssFloat = "" : t[l] = "");
            for (var s in e) l = e[s], e.hasOwnProperty(s) && n[s] !== l && Jc(t, s, l)
        } else
            for (var o in e) e.hasOwnProperty(o) && Jc(t, o, e[o])
    }

    function qs(t) {
        if (t.indexOf("-") === -1) return !1;
        switch (t) {
            case "annotation-xml":
            case "color-profile":
            case "font-face":
            case "font-face-src":
            case "font-face-uri":
            case "font-face-format":
            case "font-face-name":
            case "missing-glyph":
                return !1;
            default:
                return !0
        }
    }
    var ev = new Map([
            ["acceptCharset", "accept-charset"],
            ["htmlFor", "for"],
            ["httpEquiv", "http-equiv"],
            ["crossOrigin", "crossorigin"],
            ["accentHeight", "accent-height"],
            ["alignmentBaseline", "alignment-baseline"],
            ["arabicForm", "arabic-form"],
            ["baselineShift", "baseline-shift"],
            ["capHeight", "cap-height"],
            ["clipPath", "clip-path"],
            ["clipRule", "clip-rule"],
            ["colorInterpolation", "color-interpolation"],
            ["colorInterpolationFilters", "color-interpolation-filters"],
            ["colorProfile", "color-profile"],
            ["colorRendering", "color-rendering"],
            ["dominantBaseline", "dominant-baseline"],
            ["enableBackground", "enable-background"],
            ["fillOpacity", "fill-opacity"],
            ["fillRule", "fill-rule"],
            ["floodColor", "flood-color"],
            ["floodOpacity", "flood-opacity"],
            ["fontFamily", "font-family"],
            ["fontSize", "font-size"],
            ["fontSizeAdjust", "font-size-adjust"],
            ["fontStretch", "font-stretch"],
            ["fontStyle", "font-style"],
            ["fontVariant", "font-variant"],
            ["fontWeight", "font-weight"],
            ["glyphName", "glyph-name"],
            ["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
            ["glyphOrientationVertical", "glyph-orientation-vertical"],
            ["horizAdvX", "horiz-adv-x"],
            ["horizOriginX", "horiz-origin-x"],
            ["imageRendering", "image-rendering"],
            ["letterSpacing", "letter-spacing"],
            ["lightingColor", "lighting-color"],
            ["markerEnd", "marker-end"],
            ["markerMid", "marker-mid"],
            ["markerStart", "marker-start"],
            ["overlinePosition", "overline-position"],
            ["overlineThickness", "overline-thickness"],
            ["paintOrder", "paint-order"],
            ["panose-1", "panose-1"],
            ["pointerEvents", "pointer-events"],
            ["renderingIntent", "rendering-intent"],
            ["shapeRendering", "shape-rendering"],
            ["stopColor", "stop-color"],
            ["stopOpacity", "stop-opacity"],
            ["strikethroughPosition", "strikethrough-position"],
            ["strikethroughThickness", "strikethrough-thickness"],
            ["strokeDasharray", "stroke-dasharray"],
            ["strokeDashoffset", "stroke-dashoffset"],
            ["strokeLinecap", "stroke-linecap"],
            ["strokeLinejoin", "stroke-linejoin"],
            ["strokeMiterlimit", "stroke-miterlimit"],
            ["strokeOpacity", "stroke-opacity"],
            ["strokeWidth", "stroke-width"],
            ["textAnchor", "text-anchor"],
            ["textDecoration", "text-decoration"],
            ["textRendering", "text-rendering"],
            ["transformOrigin", "transform-origin"],
            ["underlinePosition", "underline-position"],
            ["underlineThickness", "underline-thickness"],
            ["unicodeBidi", "unicode-bidi"],
            ["unicodeRange", "unicode-range"],
            ["unitsPerEm", "units-per-em"],
            ["vAlphabetic", "v-alphabetic"],
            ["vHanging", "v-hanging"],
            ["vIdeographic", "v-ideographic"],
            ["vMathematical", "v-mathematical"],
            ["vectorEffect", "vector-effect"],
            ["vertAdvY", "vert-adv-y"],
            ["vertOriginX", "vert-origin-x"],
            ["vertOriginY", "vert-origin-y"],
            ["wordSpacing", "word-spacing"],
            ["writingMode", "writing-mode"],
            ["xmlnsXlink", "xmlns:xlink"],
            ["xHeight", "x-height"]
        ]),
        nv = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;

    function Wi(t) {
        return nv.test("" + t) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : t
    }

    function ln() {}
    var Ys = null;

    function Gs(t) {
        return t = t.target || t.srcElement || window, t.correspondingUseElement && (t = t.correspondingUseElement), t.nodeType === 3 ? t.parentNode : t
    }
    var Ka = null,
        Ja = null;

    function Pc(t) {
        var e = Ga(t);
        if (e && (t = e.stateNode)) {
            var n = t[he] || null;
            t: switch (t = e.stateNode, e.type) {
                case "input":
                    if (js(t, n.value, n.defaultValue, n.defaultValue, n.checked, n.defaultChecked, n.type, n.name), e = n.name, n.type === "radio" && e != null) {
                        for (n = t; n.parentNode;) n = n.parentNode;
                        for (n = n.querySelectorAll('input[name="' + Le("" + e) + '"][type="radio"]'), e = 0; e < n.length; e++) {
                            var l = n[e];
                            if (l !== t && l.form === t.form) {
                                var s = l[he] || null;
                                if (!s) throw Error(r(90));
                                js(l, s.value, s.defaultValue, s.defaultValue, s.checked, s.defaultChecked, s.type, s.name)
                            }
                        }
                        for (e = 0; e < n.length; e++) l = n[e], l.form === t.form && Vc(l)
                    }
                    break t;
                case "textarea":
                    Zc(t, n.value, n.defaultValue);
                    break t;
                case "select":
                    e = n.value, e != null && Qa(t, !!n.multiple, e, !1)
            }
        }
    }
    var Xs = !1;

    function Fc(t, e, n) {
        if (Xs) return t(e, n);
        Xs = !0;
        try {
            var l = t(e);
            return l
        } finally {
            if (Xs = !1, (Ka !== null || Ja !== null) && (qu(), Ka && (e = Ka, t = Ja, Ja = Ka = null, Pc(e), t)))
                for (e = 0; e < t.length; e++) Pc(t[e])
        }
    }

    function Hl(t, e) {
        var n = t.stateNode;
        if (n === null) return null;
        var l = n[he] || null;
        if (l === null) return null;
        n = l[e];
        t: switch (e) {
            case "onClick":
            case "onClickCapture":
            case "onDoubleClick":
            case "onDoubleClickCapture":
            case "onMouseDown":
            case "onMouseDownCapture":
            case "onMouseMove":
            case "onMouseMoveCapture":
            case "onMouseUp":
            case "onMouseUpCapture":
            case "onMouseEnter":
                (l = !l.disabled) || (t = t.type, l = !(t === "button" || t === "input" || t === "select" || t === "textarea")), t = !l;
                break t;
            default:
                t = !1
        }
        if (t) return null;
        if (n && typeof n != "function") throw Error(r(231, e, typeof n));
        return n
    }
    var un = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
        Vs = !1;
    if (un) try {
        var ql = {};
        Object.defineProperty(ql, "passive", {
            get: function() {
                Vs = !0
            }
        }), window.addEventListener("test", ql, ql), window.removeEventListener("test", ql, ql)
    } catch {
        Vs = !1
    }
    var zn = null,
        Qs = null,
        $i = null;

    function Ic() {
        if ($i) return $i;
        var t, e = Qs,
            n = e.length,
            l, s = "value" in zn ? zn.value : zn.textContent,
            o = s.length;
        for (t = 0; t < n && e[t] === s[t]; t++);
        var d = n - t;
        for (l = 1; l <= d && e[n - l] === s[o - l]; l++);
        return $i = s.slice(t, 1 < l ? 1 - l : void 0)
    }

    function tu(t) {
        var e = t.keyCode;
        return "charCode" in t ? (t = t.charCode, t === 0 && e === 13 && (t = 13)) : t = e, t === 10 && (t = 13), 32 <= t || t === 13 ? t : 0
    }

    function eu() {
        return !0
    }

    function Wc() {
        return !1
    }

    function me(t) {
        function e(n, l, s, o, d) {
            this._reactName = n, this._targetInst = s, this.type = l, this.nativeEvent = o, this.target = d, this.currentTarget = null;
            for (var v in t) t.hasOwnProperty(v) && (n = t[v], this[v] = n ? n(o) : o[v]);
            return this.isDefaultPrevented = (o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === !1) ? eu : Wc, this.isPropagationStopped = Wc, this
        }
        return g(e.prototype, {
            preventDefault: function() {
                this.defaultPrevented = !0;
                var n = this.nativeEvent;
                n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = eu)
            },
            stopPropagation: function() {
                var n = this.nativeEvent;
                n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = eu)
            },
            persist: function() {},
            isPersistent: eu
        }), e
    }
    var fa = {
            eventPhase: 0,
            bubbles: 0,
            cancelable: 0,
            timeStamp: function(t) {
                return t.timeStamp || Date.now()
            },
            defaultPrevented: 0,
            isTrusted: 0
        },
        nu = me(fa),
        Yl = g({}, fa, {
            view: 0,
            detail: 0
        }),
        av = me(Yl),
        Zs, Ks, Gl, au = g({}, Yl, {
            screenX: 0,
            screenY: 0,
            clientX: 0,
            clientY: 0,
            pageX: 0,
            pageY: 0,
            ctrlKey: 0,
            shiftKey: 0,
            altKey: 0,
            metaKey: 0,
            getModifierState: ks,
            button: 0,
            buttons: 0,
            relatedTarget: function(t) {
                return t.relatedTarget === void 0 ? t.fromElement === t.srcElement ? t.toElement : t.fromElement : t.relatedTarget
            },
            movementX: function(t) {
                return "movementX" in t ? t.movementX : (t !== Gl && (Gl && t.type === "mousemove" ? (Zs = t.screenX - Gl.screenX, Ks = t.screenY - Gl.screenY) : Ks = Zs = 0, Gl = t), Zs)
            },
            movementY: function(t) {
                return "movementY" in t ? t.movementY : Ks
            }
        }),
        $c = me(au),
        lv = g({}, au, {
            dataTransfer: 0
        }),
        iv = me(lv),
        uv = g({}, Yl, {
            relatedTarget: 0
        }),
        Js = me(uv),
        sv = g({}, fa, {
            animationName: 0,
            elapsedTime: 0,
            pseudoElement: 0
        }),
        rv = me(sv),
        ov = g({}, fa, {
            clipboardData: function(t) {
                return "clipboardData" in t ? t.clipboardData : window.clipboardData
            }
        }),
        cv = me(ov),
        fv = g({}, fa, {
            data: 0
        }),
        tf = me(fv),
        dv = {
            Esc: "Escape",
            Spacebar: " ",
            Left: "ArrowLeft",
            Up: "ArrowUp",
            Right: "ArrowRight",
            Down: "ArrowDown",
            Del: "Delete",
            Win: "OS",
            Menu: "ContextMenu",
            Apps: "ContextMenu",
            Scroll: "ScrollLock",
            MozPrintableKey: "Unidentified"
        },
        hv = {
            8: "Backspace",
            9: "Tab",
            12: "Clear",
            13: "Enter",
            16: "Shift",
            17: "Control",
            18: "Alt",
            19: "Pause",
            20: "CapsLock",
            27: "Escape",
            32: " ",
            33: "PageUp",
            34: "PageDown",
            35: "End",
            36: "Home",
            37: "ArrowLeft",
            38: "ArrowUp",
            39: "ArrowRight",
            40: "ArrowDown",
            45: "Insert",
            46: "Delete",
            112: "F1",
            113: "F2",
            114: "F3",
            115: "F4",
            116: "F5",
            117: "F6",
            118: "F7",
            119: "F8",
            120: "F9",
            121: "F10",
            122: "F11",
            123: "F12",
            144: "NumLock",
            145: "ScrollLock",
            224: "Meta"
        },
        mv = {
            Alt: "altKey",
            Control: "ctrlKey",
            Meta: "metaKey",
            Shift: "shiftKey"
        };

    function yv(t) {
        var e = this.nativeEvent;
        return e.getModifierState ? e.getModifierState(t) : (t = mv[t]) ? !!e[t] : !1
    }

    function ks() {
        return yv
    }
    var pv = g({}, Yl, {
            key: function(t) {
                if (t.key) {
                    var e = dv[t.key] || t.key;
                    if (e !== "Unidentified") return e
                }
                return t.type === "keypress" ? (t = tu(t), t === 13 ? "Enter" : String.fromCharCode(t)) : t.type === "keydown" || t.type === "keyup" ? hv[t.keyCode] || "Unidentified" : ""
            },
            code: 0,
            location: 0,
            ctrlKey: 0,
            shiftKey: 0,
            altKey: 0,
            metaKey: 0,
            repeat: 0,
            locale: 0,
            getModifierState: ks,
            charCode: function(t) {
                return t.type === "keypress" ? tu(t) : 0
            },
            keyCode: function(t) {
                return t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0
            },
            which: function(t) {
                return t.type === "keypress" ? tu(t) : t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0
            }
        }),
        vv = me(pv),
        gv = g({}, au, {
            pointerId: 0,
            width: 0,
            height: 0,
            pressure: 0,
            tangentialPressure: 0,
            tiltX: 0,
            tiltY: 0,
            twist: 0,
            pointerType: 0,
            isPrimary: 0
        }),
        ef = me(gv),
        Sv = g({}, Yl, {
            touches: 0,
            targetTouches: 0,
            changedTouches: 0,
            altKey: 0,
            metaKey: 0,
            ctrlKey: 0,
            shiftKey: 0,
            getModifierState: ks
        }),
        bv = me(Sv),
        _v = g({}, fa, {
            propertyName: 0,
            elapsedTime: 0,
            pseudoElement: 0
        }),
        Ev = me(_v),
        Rv = g({}, au, {
            deltaX: function(t) {
                return "deltaX" in t ? t.deltaX : "wheelDeltaX" in t ? -t.wheelDeltaX : 0
            },
            deltaY: function(t) {
                return "deltaY" in t ? t.deltaY : "wheelDeltaY" in t ? -t.wheelDeltaY : "wheelDelta" in t ? -t.wheelDelta : 0
            },
            deltaZ: 0,
            deltaMode: 0
        }),
        Tv = me(Rv),
        Av = g({}, fa, {
            newState: 0,
            oldState: 0
        }),
        xv = me(Av),
        Mv = [9, 13, 27, 32],
        Ps = un && "CompositionEvent" in window,
        Xl = null;
    un && "documentMode" in document && (Xl = document.documentMode);
    var Ov = un && "TextEvent" in window && !Xl,
        nf = un && (!Ps || Xl && 8 < Xl && 11 >= Xl),
        af = " ",
        lf = !1;

    function uf(t, e) {
        switch (t) {
            case "keyup":
                return Mv.indexOf(e.keyCode) !== -1;
            case "keydown":
                return e.keyCode !== 229;
            case "keypress":
            case "mousedown":
            case "focusout":
                return !0;
            default:
                return !1
        }
    }

    function sf(t) {
        return t = t.detail, typeof t == "object" && "data" in t ? t.data : null
    }
    var ka = !1;

    function zv(t, e) {
        switch (t) {
            case "compositionend":
                return sf(e);
            case "keypress":
                return e.which !== 32 ? null : (lf = !0, af);
            case "textInput":
                return t = e.data, t === af && lf ? null : t;
            default:
                return null
        }
    }

    function Cv(t, e) {
        if (ka) return t === "compositionend" || !Ps && uf(t, e) ? (t = Ic(), $i = Qs = zn = null, ka = !1, t) : null;
        switch (t) {
            case "paste":
                return null;
            case "keypress":
                if (!(e.ctrlKey || e.altKey || e.metaKey) || e.ctrlKey && e.altKey) {
                    if (e.char && 1 < e.char.length) return e.char;
                    if (e.which) return String.fromCharCode(e.which)
                }
                return null;
            case "compositionend":
                return nf && e.locale !== "ko" ? null : e.data;
            default:
                return null
        }
    }
    var wv = {
        color: !0,
        date: !0,
        datetime: !0,
        "datetime-local": !0,
        email: !0,
        month: !0,
        number: !0,
        password: !0,
        range: !0,
        search: !0,
        tel: !0,
        text: !0,
        time: !0,
        url: !0,
        week: !0
    };

    function rf(t) {
        var e = t && t.nodeName && t.nodeName.toLowerCase();
        return e === "input" ? !!wv[t.type] : e === "textarea"
    }

    function of (t, e, n, l) {
        Ka ? Ja ? Ja.push(l) : Ja = [l] : Ka = l, e = Ku(e, "onChange"), 0 < e.length && (n = new nu("onChange", "change", null, n, l), t.push({
            event: n,
            listeners: e
        }))
    }
    var Vl = null,
        Ql = null;

    function Dv(t) {
        Zh(t, 0)
    }

    function lu(t) {
        var e = jl(t);
        if (Vc(e)) return t
    }

    function cf(t, e) {
        if (t === "change") return e
    }
    var ff = !1;
    if (un) {
        var Fs;
        if (un) {
            var Is = "oninput" in document;
            if (!Is) {
                var df = document.createElement("div");
                df.setAttribute("oninput", "return;"), Is = typeof df.oninput == "function"
            }
            Fs = Is
        } else Fs = !1;
        ff = Fs && (!document.documentMode || 9 < document.documentMode)
    }

    function hf() {
        Vl && (Vl.detachEvent("onpropertychange", mf), Ql = Vl = null)
    }

    function mf(t) {
        if (t.propertyName === "value" && lu(Ql)) {
            var e = []; of (e, Ql, t, Gs(t)), Fc(Dv, e)
        }
    }

    function Lv(t, e, n) {
        t === "focusin" ? (hf(), Vl = e, Ql = n, Vl.attachEvent("onpropertychange", mf)) : t === "focusout" && hf()
    }

    function Uv(t) {
        if (t === "selectionchange" || t === "keyup" || t === "keydown") return lu(Ql)
    }

    function Nv(t, e) {
        if (t === "click") return lu(e)
    }

    function Bv(t, e) {
        if (t === "input" || t === "change") return lu(e)
    }

    function jv(t, e) {
        return t === e && (t !== 0 || 1 / t === 1 / e) || t !== t && e !== e
    }
    var Ae = typeof Object.is == "function" ? Object.is : jv;

    function Zl(t, e) {
        if (Ae(t, e)) return !0;
        if (typeof t != "object" || t === null || typeof e != "object" || e === null) return !1;
        var n = Object.keys(t),
            l = Object.keys(e);
        if (n.length !== l.length) return !1;
        for (l = 0; l < n.length; l++) {
            var s = n[l];
            if (!ra.call(e, s) || !Ae(t[s], e[s])) return !1
        }
        return !0
    }

    function yf(t) {
        for (; t && t.firstChild;) t = t.firstChild;
        return t
    }

    function pf(t, e) {
        var n = yf(t);
        t = 0;
        for (var l; n;) {
            if (n.nodeType === 3) {
                if (l = t + n.textContent.length, t <= e && l >= e) return {
                    node: n,
                    offset: e - t
                };
                t = l
            }
            t: {
                for (; n;) {
                    if (n.nextSibling) {
                        n = n.nextSibling;
                        break t
                    }
                    n = n.parentNode
                }
                n = void 0
            }
            n = yf(n)
        }
    }

    function vf(t, e) {
        return t && e ? t === e ? !0 : t && t.nodeType === 3 ? !1 : e && e.nodeType === 3 ? vf(t, e.parentNode) : "contains" in t ? t.contains(e) : t.compareDocumentPosition ? !!(t.compareDocumentPosition(e) & 16) : !1 : !1
    }

    function gf(t) {
        t = t != null && t.ownerDocument != null && t.ownerDocument.defaultView != null ? t.ownerDocument.defaultView : window;
        for (var e = Ii(t.document); e instanceof t.HTMLIFrameElement;) {
            try {
                var n = typeof e.contentWindow.location.href == "string"
            } catch {
                n = !1
            }
            if (n) t = e.contentWindow;
            else break;
            e = Ii(t.document)
        }
        return e
    }

    function Ws(t) {
        var e = t && t.nodeName && t.nodeName.toLowerCase();
        return e && (e === "input" && (t.type === "text" || t.type === "search" || t.type === "tel" || t.type === "url" || t.type === "password") || e === "textarea" || t.contentEditable === "true")
    }
    var Hv = un && "documentMode" in document && 11 >= document.documentMode,
        Pa = null,
        $s = null,
        Kl = null,
        tr = !1;

    function Sf(t, e, n) {
        var l = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
        tr || Pa == null || Pa !== Ii(l) || (l = Pa, "selectionStart" in l && Ws(l) ? l = {
            start: l.selectionStart,
            end: l.selectionEnd
        } : (l = (l.ownerDocument && l.ownerDocument.defaultView || window).getSelection(), l = {
            anchorNode: l.anchorNode,
            anchorOffset: l.anchorOffset,
            focusNode: l.focusNode,
            focusOffset: l.focusOffset
        }), Kl && Zl(Kl, l) || (Kl = l, l = Ku($s, "onSelect"), 0 < l.length && (e = new nu("onSelect", "select", null, e, n), t.push({
            event: e,
            listeners: l
        }), e.target = Pa)))
    }

    function da(t, e) {
        var n = {};
        return n[t.toLowerCase()] = e.toLowerCase(), n["Webkit" + t] = "webkit" + e, n["Moz" + t] = "moz" + e, n
    }
    var Fa = {
            animationend: da("Animation", "AnimationEnd"),
            animationiteration: da("Animation", "AnimationIteration"),
            animationstart: da("Animation", "AnimationStart"),
            transitionrun: da("Transition", "TransitionRun"),
            transitionstart: da("Transition", "TransitionStart"),
            transitioncancel: da("Transition", "TransitionCancel"),
            transitionend: da("Transition", "TransitionEnd")
        },
        er = {},
        bf = {};
    un && (bf = document.createElement("div").style, "AnimationEvent" in window || (delete Fa.animationend.animation, delete Fa.animationiteration.animation, delete Fa.animationstart.animation), "TransitionEvent" in window || delete Fa.transitionend.transition);

    function ha(t) {
        if (er[t]) return er[t];
        if (!Fa[t]) return t;
        var e = Fa[t],
            n;
        for (n in e)
            if (e.hasOwnProperty(n) && n in bf) return er[t] = e[n];
        return t
    }
    var _f = ha("animationend"),
        Ef = ha("animationiteration"),
        Rf = ha("animationstart"),
        qv = ha("transitionrun"),
        Yv = ha("transitionstart"),
        Gv = ha("transitioncancel"),
        Tf = ha("transitionend"),
        Af = new Map,
        nr = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
    nr.push("scrollEnd");

    function Ve(t, e) {
        Af.set(t, e), ca(e, [t])
    }
    var iu = typeof reportError == "function" ? reportError : function(t) {
            if (typeof window == "object" && typeof window.ErrorEvent == "function") {
                var e = new window.ErrorEvent("error", {
                    bubbles: !0,
                    cancelable: !0,
                    message: typeof t == "object" && t !== null && typeof t.message == "string" ? String(t.message) : String(t),
                    error: t
                });
                if (!window.dispatchEvent(e)) return
            } else if (typeof process == "object" && typeof process.emit == "function") {
                process.emit("uncaughtException", t);
                return
            }
            console.error(t)
        },
        Ue = [],
        Ia = 0,
        ar = 0;

    function uu() {
        for (var t = Ia, e = ar = Ia = 0; e < t;) {
            var n = Ue[e];
            Ue[e++] = null;
            var l = Ue[e];
            Ue[e++] = null;
            var s = Ue[e];
            Ue[e++] = null;
            var o = Ue[e];
            if (Ue[e++] = null, l !== null && s !== null) {
                var d = l.pending;
                d === null ? s.next = s : (s.next = d.next, d.next = s), l.pending = s
            }
            o !== 0 && xf(n, s, o)
        }
    }

    function su(t, e, n, l) {
        Ue[Ia++] = t, Ue[Ia++] = e, Ue[Ia++] = n, Ue[Ia++] = l, ar |= l, t.lanes |= l, t = t.alternate, t !== null && (t.lanes |= l)
    }

    function lr(t, e, n, l) {
        return su(t, e, n, l), ru(t)
    }

    function ma(t, e) {
        return su(t, null, null, e), ru(t)
    }

    function xf(t, e, n) {
        t.lanes |= n;
        var l = t.alternate;
        l !== null && (l.lanes |= n);
        for (var s = !1, o = t.return; o !== null;) o.childLanes |= n, l = o.alternate, l !== null && (l.childLanes |= n), o.tag === 22 && (t = o.stateNode, t === null || t._visibility & 1 || (s = !0)), t = o, o = o.return;
        return t.tag === 3 ? (o = t.stateNode, s && e !== null && (s = 31 - Te(n), t = o.hiddenUpdates, l = t[s], l === null ? t[s] = [e] : l.push(e), e.lane = n | 536870912), o) : null
    }

    function ru(t) {
        if (50 < mi) throw mi = 0, mo = null, Error(r(185));
        for (var e = t.return; e !== null;) t = e, e = t.return;
        return t.tag === 3 ? t.stateNode : null
    }
    var Wa = {};

    function Xv(t, e, n, l) {
        this.tag = t, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = e, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = l, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
    }

    function xe(t, e, n, l) {
        return new Xv(t, e, n, l)
    }

    function ir(t) {
        return t = t.prototype, !(!t || !t.isReactComponent)
    }

    function sn(t, e) {
        var n = t.alternate;
        return n === null ? (n = xe(t.tag, e, t.key, t.mode), n.elementType = t.elementType, n.type = t.type, n.stateNode = t.stateNode, n.alternate = t, t.alternate = n) : (n.pendingProps = e, n.type = t.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = t.flags & 65011712, n.childLanes = t.childLanes, n.lanes = t.lanes, n.child = t.child, n.memoizedProps = t.memoizedProps, n.memoizedState = t.memoizedState, n.updateQueue = t.updateQueue, e = t.dependencies, n.dependencies = e === null ? null : {
            lanes: e.lanes,
            firstContext: e.firstContext
        }, n.sibling = t.sibling, n.index = t.index, n.ref = t.ref, n.refCleanup = t.refCleanup, n
    }

    function Mf(t, e) {
        t.flags &= 65011714;
        var n = t.alternate;
        return n === null ? (t.childLanes = 0, t.lanes = e, t.child = null, t.subtreeFlags = 0, t.memoizedProps = null, t.memoizedState = null, t.updateQueue = null, t.dependencies = null, t.stateNode = null) : (t.childLanes = n.childLanes, t.lanes = n.lanes, t.child = n.child, t.subtreeFlags = 0, t.deletions = null, t.memoizedProps = n.memoizedProps, t.memoizedState = n.memoizedState, t.updateQueue = n.updateQueue, t.type = n.type, e = n.dependencies, t.dependencies = e === null ? null : {
            lanes: e.lanes,
            firstContext: e.firstContext
        }), t
    }

    function ou(t, e, n, l, s, o) {
        var d = 0;
        if (l = t, typeof t == "function") ir(t) && (d = 1);
        else if (typeof t == "string") d = Jg(t, n, I.current) ? 26 : t === "html" || t === "head" || t === "body" ? 27 : 5;
        else t: switch (t) {
            case P:
                return t = xe(31, n, e, s), t.elementType = P, t.lanes = o, t;
            case w:
                return ya(n.children, s, o, e);
            case A:
                d = 8, s |= 24;
                break;
            case z:
                return t = xe(12, n, e, s | 2), t.elementType = z, t.lanes = o, t;
            case W:
                return t = xe(13, n, e, s), t.elementType = W, t.lanes = o, t;
            case F:
                return t = xe(19, n, e, s), t.elementType = F, t.lanes = o, t;
            default:
                if (typeof t == "object" && t !== null) switch (t.$$typeof) {
                    case Q:
                        d = 10;
                        break t;
                    case X:
                        d = 9;
                        break t;
                    case H:
                        d = 11;
                        break t;
                    case V:
                        d = 14;
                        break t;
                    case J:
                        d = 16, l = null;
                        break t
                }
                d = 29, n = Error(r(130, t === null ? "null" : typeof t, "")), l = null
        }
        return e = xe(d, n, e, s), e.elementType = t, e.type = l, e.lanes = o, e
    }

    function ya(t, e, n, l) {
        return t = xe(7, t, l, e), t.lanes = n, t
    }

    function ur(t, e, n) {
        return t = xe(6, t, null, e), t.lanes = n, t
    }

    function Of(t) {
        var e = xe(18, null, null, 0);
        return e.stateNode = t, e
    }

    function sr(t, e, n) {
        return e = xe(4, t.children !== null ? t.children : [], t.key, e), e.lanes = n, e.stateNode = {
            containerInfo: t.containerInfo,
            pendingChildren: null,
            implementation: t.implementation
        }, e
    }
    var zf = new WeakMap;

    function Ne(t, e) {
        if (typeof t == "object" && t !== null) {
            var n = zf.get(t);
            return n !== void 0 ? n : (e = {
                value: t,
                source: e,
                stack: nn(e)
            }, zf.set(t, e), e)
        }
        return {
            value: t,
            source: e,
            stack: nn(e)
        }
    }
    var $a = [],
        tl = 0,
        cu = null,
        Jl = 0,
        Be = [],
        je = 0,
        Cn = null,
        ke = 1,
        Pe = "";

    function rn(t, e) {
        $a[tl++] = Jl, $a[tl++] = cu, cu = t, Jl = e
    }

    function Cf(t, e, n) {
        Be[je++] = ke, Be[je++] = Pe, Be[je++] = Cn, Cn = t;
        var l = ke;
        t = Pe;
        var s = 32 - Te(l) - 1;
        l &= ~(1 << s), n += 1;
        var o = 32 - Te(e) + s;
        if (30 < o) {
            var d = s - s % 5;
            o = (l & (1 << d) - 1).toString(32), l >>= d, s -= d, ke = 1 << 32 - Te(e) + s | n << s | l, Pe = o + t
        } else ke = 1 << o | n << s | l, Pe = t
    }

    function rr(t) {
        t.return !== null && (rn(t, 1), Cf(t, 1, 0))
    }

    function or(t) {
        for (; t === cu;) cu = $a[--tl], $a[tl] = null, Jl = $a[--tl], $a[tl] = null;
        for (; t === Cn;) Cn = Be[--je], Be[je] = null, Pe = Be[--je], Be[je] = null, ke = Be[--je], Be[je] = null
    }

    function wf(t, e) {
        Be[je++] = ke, Be[je++] = Pe, Be[je++] = Cn, ke = e.id, Pe = e.overflow, Cn = t
    }
    var ie = null,
        Bt = null,
        gt = !1,
        wn = null,
        He = !1,
        cr = Error(r(519));

    function Dn(t) {
        var e = Error(r(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML", ""));
        throw kl(Ne(e, t)), cr
    }

    function Df(t) {
        var e = t.stateNode,
            n = t.type,
            l = t.memoizedProps;
        switch (e[le] = t, e[he] = l, n) {
            case "dialog":
                mt("cancel", e), mt("close", e);
                break;
            case "iframe":
            case "object":
            case "embed":
                mt("load", e);
                break;
            case "video":
            case "audio":
                for (n = 0; n < pi.length; n++) mt(pi[n], e);
                break;
            case "source":
                mt("error", e);
                break;
            case "img":
            case "image":
            case "link":
                mt("error", e), mt("load", e);
                break;
            case "details":
                mt("toggle", e);
                break;
            case "input":
                mt("invalid", e), Qc(e, l.value, l.defaultValue, l.checked, l.defaultChecked, l.type, l.name, !0);
                break;
            case "select":
                mt("invalid", e);
                break;
            case "textarea":
                mt("invalid", e), Kc(e, l.value, l.defaultValue, l.children)
        }
        n = l.children, typeof n != "string" && typeof n != "number" && typeof n != "bigint" || e.textContent === "" + n || l.suppressHydrationWarning === !0 || Ph(e.textContent, n) ? (l.popover != null && (mt("beforetoggle", e), mt("toggle", e)), l.onScroll != null && mt("scroll", e), l.onScrollEnd != null && mt("scrollend", e), l.onClick != null && (e.onclick = ln), e = !0) : e = !1, e || Dn(t, !0)
    }

    function Lf(t) {
        for (ie = t.return; ie;) switch (ie.tag) {
            case 5:
            case 31:
            case 13:
                He = !1;
                return;
            case 27:
            case 3:
                He = !0;
                return;
            default:
                ie = ie.return
        }
    }

    function el(t) {
        if (t !== ie) return !1;
        if (!gt) return Lf(t), gt = !0, !1;
        var e = t.tag,
            n;
        if ((n = e !== 3 && e !== 27) && ((n = e === 5) && (n = t.type, n = !(n !== "form" && n !== "button") || zo(t.type, t.memoizedProps)), n = !n), n && Bt && Dn(t), Lf(t), e === 13) {
            if (t = t.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(r(317));
            Bt = lm(t)
        } else if (e === 31) {
            if (t = t.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(r(317));
            Bt = lm(t)
        } else e === 27 ? (e = Bt, Kn(t.type) ? (t = Uo, Uo = null, Bt = t) : Bt = e) : Bt = ie ? Ye(t.stateNode.nextSibling) : null;
        return !0
    }

    function pa() {
        Bt = ie = null, gt = !1
    }

    function fr() {
        var t = wn;
        return t !== null && (ge === null ? ge = t : ge.push.apply(ge, t), wn = null), t
    }

    function kl(t) {
        wn === null ? wn = [t] : wn.push(t)
    }
    var dr = M(null),
        va = null,
        on = null;

    function Ln(t, e, n) {
        k(dr, e._currentValue), e._currentValue = n
    }

    function cn(t) {
        t._currentValue = dr.current, Y(dr)
    }

    function hr(t, e, n) {
        for (; t !== null;) {
            var l = t.alternate;
            if ((t.childLanes & e) !== e ? (t.childLanes |= e, l !== null && (l.childLanes |= e)) : l !== null && (l.childLanes & e) !== e && (l.childLanes |= e), t === n) break;
            t = t.return
        }
    }

    function mr(t, e, n, l) {
        var s = t.child;
        for (s !== null && (s.return = t); s !== null;) {
            var o = s.dependencies;
            if (o !== null) {
                var d = s.child;
                o = o.firstContext;
                t: for (; o !== null;) {
                    var v = o;
                    o = s;
                    for (var R = 0; R < e.length; R++)
                        if (v.context === e[R]) {
                            o.lanes |= n, v = o.alternate, v !== null && (v.lanes |= n), hr(o.return, n, t), l || (d = null);
                            break t
                        }
                    o = v.next
                }
            } else if (s.tag === 18) {
                if (d = s.return, d === null) throw Error(r(341));
                d.lanes |= n, o = d.alternate, o !== null && (o.lanes |= n), hr(d, n, t), d = null
            } else d = s.child;
            if (d !== null) d.return = s;
            else
                for (d = s; d !== null;) {
                    if (d === t) {
                        d = null;
                        break
                    }
                    if (s = d.sibling, s !== null) {
                        s.return = d.return, d = s;
                        break
                    }
                    d = d.return
                }
            s = d
        }
    }

    function nl(t, e, n, l) {
        t = null;
        for (var s = e, o = !1; s !== null;) {
            if (!o) {
                if ((s.flags & 524288) !== 0) o = !0;
                else if ((s.flags & 262144) !== 0) break
            }
            if (s.tag === 10) {
                var d = s.alternate;
                if (d === null) throw Error(r(387));
                if (d = d.memoizedProps, d !== null) {
                    var v = s.type;
                    Ae(s.pendingProps.value, d.value) || (t !== null ? t.push(v) : t = [v])
                }
            } else if (s === St.current) {
                if (d = s.alternate, d === null) throw Error(r(387));
                d.memoizedState.memoizedState !== s.memoizedState.memoizedState && (t !== null ? t.push(_i) : t = [_i])
            }
            s = s.return
        }
        t !== null && mr(e, t, n, l), e.flags |= 262144
    }

    function fu(t) {
        for (t = t.firstContext; t !== null;) {
            if (!Ae(t.context._currentValue, t.memoizedValue)) return !0;
            t = t.next
        }
        return !1
    }

    function ga(t) {
        va = t, on = null, t = t.dependencies, t !== null && (t.firstContext = null)
    }

    function ue(t) {
        return Uf(va, t)
    }

    function du(t, e) {
        return va === null && ga(t), Uf(t, e)
    }

    function Uf(t, e) {
        var n = e._currentValue;
        if (e = {
                context: e,
                memoizedValue: n,
                next: null
            }, on === null) {
            if (t === null) throw Error(r(308));
            on = e, t.dependencies = {
                lanes: 0,
                firstContext: e
            }, t.flags |= 524288
        } else on = on.next = e;
        return n
    }
    var Vv = typeof AbortController < "u" ? AbortController : function() {
            var t = [],
                e = this.signal = {
                    aborted: !1,
                    addEventListener: function(n, l) {
                        t.push(l)
                    }
                };
            this.abort = function() {
                e.aborted = !0, t.forEach(function(n) {
                    return n()
                })
            }
        },
        Qv = a.unstable_scheduleCallback,
        Zv = a.unstable_NormalPriority,
        Kt = {
            $$typeof: Q,
            Consumer: null,
            Provider: null,
            _currentValue: null,
            _currentValue2: null,
            _threadCount: 0
        };

    function yr() {
        return {
            controller: new Vv,
            data: new Map,
            refCount: 0
        }
    }

    function Pl(t) {
        t.refCount--, t.refCount === 0 && Qv(Zv, function() {
            t.controller.abort()
        })
    }
    var Fl = null,
        pr = 0,
        al = 0,
        ll = null;

    function Kv(t, e) {
        if (Fl === null) {
            var n = Fl = [];
            pr = 0, al = bo(), ll = {
                status: "pending",
                value: void 0,
                then: function(l) {
                    n.push(l)
                }
            }
        }
        return pr++, e.then(Nf, Nf), e
    }

    function Nf() {
        if (--pr === 0 && Fl !== null) {
            ll !== null && (ll.status = "fulfilled");
            var t = Fl;
            Fl = null, al = 0, ll = null;
            for (var e = 0; e < t.length; e++)(0, t[e])()
        }
    }

    function Jv(t, e) {
        var n = [],
            l = {
                status: "pending",
                value: null,
                reason: null,
                then: function(s) {
                    n.push(s)
                }
            };
        return t.then(function() {
            l.status = "fulfilled", l.value = e;
            for (var s = 0; s < n.length; s++)(0, n[s])(e)
        }, function(s) {
            for (l.status = "rejected", l.reason = s, s = 0; s < n.length; s++)(0, n[s])(void 0)
        }), l
    }
    var Bf = B.S;
    B.S = function(t, e) {
        Sh = oe(), typeof e == "object" && e !== null && typeof e.then == "function" && Kv(t, e), Bf !== null && Bf(t, e)
    };
    var Sa = M(null);

    function vr() {
        var t = Sa.current;
        return t !== null ? t : Lt.pooledCache
    }

    function hu(t, e) {
        e === null ? k(Sa, Sa.current) : k(Sa, e.pool)
    }

    function jf() {
        var t = vr();
        return t === null ? null : {
            parent: Kt._currentValue,
            pool: t
        }
    }
    var il = Error(r(460)),
        gr = Error(r(474)),
        mu = Error(r(542)),
        yu = {
            then: function() {}
        };

    function Hf(t) {
        return t = t.status, t === "fulfilled" || t === "rejected"
    }

    function qf(t, e, n) {
        switch (n = t[n], n === void 0 ? t.push(e) : n !== e && (e.then(ln, ln), e = n), e.status) {
            case "fulfilled":
                return e.value;
            case "rejected":
                throw t = e.reason, Gf(t), t;
            default:
                if (typeof e.status == "string") e.then(ln, ln);
                else {
                    if (t = Lt, t !== null && 100 < t.shellSuspendCounter) throw Error(r(482));
                    t = e, t.status = "pending", t.then(function(l) {
                        if (e.status === "pending") {
                            var s = e;
                            s.status = "fulfilled", s.value = l
                        }
                    }, function(l) {
                        if (e.status === "pending") {
                            var s = e;
                            s.status = "rejected", s.reason = l
                        }
                    })
                }
                switch (e.status) {
                    case "fulfilled":
                        return e.value;
                    case "rejected":
                        throw t = e.reason, Gf(t), t
                }
                throw _a = e, il
        }
    }

    function ba(t) {
        try {
            var e = t._init;
            return e(t._payload)
        } catch (n) {
            throw n !== null && typeof n == "object" && typeof n.then == "function" ? (_a = n, il) : n
        }
    }
    var _a = null;

    function Yf() {
        if (_a === null) throw Error(r(459));
        var t = _a;
        return _a = null, t
    }

    function Gf(t) {
        if (t === il || t === mu) throw Error(r(483))
    }
    var ul = null,
        Il = 0;

    function pu(t) {
        var e = Il;
        return Il += 1, ul === null && (ul = []), qf(ul, t, e)
    }

    function Wl(t, e) {
        e = e.props.ref, t.ref = e !== void 0 ? e : null
    }

    function vu(t, e) {
        throw e.$$typeof === _ ? Error(r(525)) : (t = Object.prototype.toString.call(e), Error(r(31, t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t)))
    }

    function Xf(t) {
        function e(C, x) {
            if (t) {
                var D = C.deletions;
                D === null ? (C.deletions = [x], C.flags |= 16) : D.push(x)
            }
        }

        function n(C, x) {
            if (!t) return null;
            for (; x !== null;) e(C, x), x = x.sibling;
            return null
        }

        function l(C) {
            for (var x = new Map; C !== null;) C.key !== null ? x.set(C.key, C) : x.set(C.index, C), C = C.sibling;
            return x
        }

        function s(C, x) {
            return C = sn(C, x), C.index = 0, C.sibling = null, C
        }

        function o(C, x, D) {
            return C.index = D, t ? (D = C.alternate, D !== null ? (D = D.index, D < x ? (C.flags |= 67108866, x) : D) : (C.flags |= 67108866, x)) : (C.flags |= 1048576, x)
        }

        function d(C) {
            return t && C.alternate === null && (C.flags |= 67108866), C
        }

        function v(C, x, D, q) {
            return x === null || x.tag !== 6 ? (x = ur(D, C.mode, q), x.return = C, x) : (x = s(x, D), x.return = C, x)
        }

        function R(C, x, D, q) {
            var lt = D.type;
            return lt === w ? j(C, x, D.props.children, q, D.key) : x !== null && (x.elementType === lt || typeof lt == "object" && lt !== null && lt.$$typeof === J && ba(lt) === x.type) ? (x = s(x, D.props), Wl(x, D), x.return = C, x) : (x = ou(D.type, D.key, D.props, null, C.mode, q), Wl(x, D), x.return = C, x)
        }

        function L(C, x, D, q) {
            return x === null || x.tag !== 4 || x.stateNode.containerInfo !== D.containerInfo || x.stateNode.implementation !== D.implementation ? (x = sr(D, C.mode, q), x.return = C, x) : (x = s(x, D.children || []), x.return = C, x)
        }

        function j(C, x, D, q, lt) {
            return x === null || x.tag !== 7 ? (x = ya(D, C.mode, q, lt), x.return = C, x) : (x = s(x, D), x.return = C, x)
        }

        function G(C, x, D) {
            if (typeof x == "string" && x !== "" || typeof x == "number" || typeof x == "bigint") return x = ur("" + x, C.mode, D), x.return = C, x;
            if (typeof x == "object" && x !== null) {
                switch (x.$$typeof) {
                    case E:
                        return D = ou(x.type, x.key, x.props, null, C.mode, D), Wl(D, x), D.return = C, D;
                    case O:
                        return x = sr(x, C.mode, D), x.return = C, x;
                    case J:
                        return x = ba(x), G(C, x, D)
                }
                if (Ot(x) || dt(x)) return x = ya(x, C.mode, D, null), x.return = C, x;
                if (typeof x.then == "function") return G(C, pu(x), D);
                if (x.$$typeof === Q) return G(C, du(C, x), D);
                vu(C, x)
            }
            return null
        }

        function U(C, x, D, q) {
            var lt = x !== null ? x.key : null;
            if (typeof D == "string" && D !== "" || typeof D == "number" || typeof D == "bigint") return lt !== null ? null : v(C, x, "" + D, q);
            if (typeof D == "object" && D !== null) {
                switch (D.$$typeof) {
                    case E:
                        return D.key === lt ? R(C, x, D, q) : null;
                    case O:
                        return D.key === lt ? L(C, x, D, q) : null;
                    case J:
                        return D = ba(D), U(C, x, D, q)
                }
                if (Ot(D) || dt(D)) return lt !== null ? null : j(C, x, D, q, null);
                if (typeof D.then == "function") return U(C, x, pu(D), q);
                if (D.$$typeof === Q) return U(C, x, du(C, D), q);
                vu(C, D)
            }
            return null
        }

        function N(C, x, D, q, lt) {
            if (typeof q == "string" && q !== "" || typeof q == "number" || typeof q == "bigint") return C = C.get(D) || null, v(x, C, "" + q, lt);
            if (typeof q == "object" && q !== null) {
                switch (q.$$typeof) {
                    case E:
                        return C = C.get(q.key === null ? D : q.key) || null, R(x, C, q, lt);
                    case O:
                        return C = C.get(q.key === null ? D : q.key) || null, L(x, C, q, lt);
                    case J:
                        return q = ba(q), N(C, x, D, q, lt)
                }
                if (Ot(q) || dt(q)) return C = C.get(D) || null, j(x, C, q, lt, null);
                if (typeof q.then == "function") return N(C, x, D, pu(q), lt);
                if (q.$$typeof === Q) return N(C, x, D, du(x, q), lt);
                vu(x, q)
            }
            return null
        }

        function $(C, x, D, q) {
            for (var lt = null, bt = null, nt = x, ct = x = 0, pt = null; nt !== null && ct < D.length; ct++) {
                nt.index > ct ? (pt = nt, nt = null) : pt = nt.sibling;
                var _t = U(C, nt, D[ct], q);
                if (_t === null) {
                    nt === null && (nt = pt);
                    break
                }
                t && nt && _t.alternate === null && e(C, nt), x = o(_t, x, ct), bt === null ? lt = _t : bt.sibling = _t, bt = _t, nt = pt
            }
            if (ct === D.length) return n(C, nt), gt && rn(C, ct), lt;
            if (nt === null) {
                for (; ct < D.length; ct++) nt = G(C, D[ct], q), nt !== null && (x = o(nt, x, ct), bt === null ? lt = nt : bt.sibling = nt, bt = nt);
                return gt && rn(C, ct), lt
            }
            for (nt = l(nt); ct < D.length; ct++) pt = N(nt, C, ct, D[ct], q), pt !== null && (t && pt.alternate !== null && nt.delete(pt.key === null ? ct : pt.key), x = o(pt, x, ct), bt === null ? lt = pt : bt.sibling = pt, bt = pt);
            return t && nt.forEach(function(In) {
                return e(C, In)
            }), gt && rn(C, ct), lt
        }

        function st(C, x, D, q) {
            if (D == null) throw Error(r(151));
            for (var lt = null, bt = null, nt = x, ct = x = 0, pt = null, _t = D.next(); nt !== null && !_t.done; ct++, _t = D.next()) {
                nt.index > ct ? (pt = nt, nt = null) : pt = nt.sibling;
                var In = U(C, nt, _t.value, q);
                if (In === null) {
                    nt === null && (nt = pt);
                    break
                }
                t && nt && In.alternate === null && e(C, nt), x = o(In, x, ct), bt === null ? lt = In : bt.sibling = In, bt = In, nt = pt
            }
            if (_t.done) return n(C, nt), gt && rn(C, ct), lt;
            if (nt === null) {
                for (; !_t.done; ct++, _t = D.next()) _t = G(C, _t.value, q), _t !== null && (x = o(_t, x, ct), bt === null ? lt = _t : bt.sibling = _t, bt = _t);
                return gt && rn(C, ct), lt
            }
            for (nt = l(nt); !_t.done; ct++, _t = D.next()) _t = N(nt, C, ct, _t.value, q), _t !== null && (t && _t.alternate !== null && nt.delete(_t.key === null ? ct : _t.key), x = o(_t, x, ct), bt === null ? lt = _t : bt.sibling = _t, bt = _t);
            return t && nt.forEach(function(l0) {
                return e(C, l0)
            }), gt && rn(C, ct), lt
        }

        function wt(C, x, D, q) {
            if (typeof D == "object" && D !== null && D.type === w && D.key === null && (D = D.props.children), typeof D == "object" && D !== null) {
                switch (D.$$typeof) {
                    case E:
                        t: {
                            for (var lt = D.key; x !== null;) {
                                if (x.key === lt) {
                                    if (lt = D.type, lt === w) {
                                        if (x.tag === 7) {
                                            n(C, x.sibling), q = s(x, D.props.children), q.return = C, C = q;
                                            break t
                                        }
                                    } else if (x.elementType === lt || typeof lt == "object" && lt !== null && lt.$$typeof === J && ba(lt) === x.type) {
                                        n(C, x.sibling), q = s(x, D.props), Wl(q, D), q.return = C, C = q;
                                        break t
                                    }
                                    n(C, x);
                                    break
                                } else e(C, x);
                                x = x.sibling
                            }
                            D.type === w ? (q = ya(D.props.children, C.mode, q, D.key), q.return = C, C = q) : (q = ou(D.type, D.key, D.props, null, C.mode, q), Wl(q, D), q.return = C, C = q)
                        }
                        return d(C);
                    case O:
                        t: {
                            for (lt = D.key; x !== null;) {
                                if (x.key === lt)
                                    if (x.tag === 4 && x.stateNode.containerInfo === D.containerInfo && x.stateNode.implementation === D.implementation) {
                                        n(C, x.sibling), q = s(x, D.children || []), q.return = C, C = q;
                                        break t
                                    } else {
                                        n(C, x);
                                        break
                                    }
                                else e(C, x);
                                x = x.sibling
                            }
                            q = sr(D, C.mode, q),
                            q.return = C,
                            C = q
                        }
                        return d(C);
                    case J:
                        return D = ba(D), wt(C, x, D, q)
                }
                if (Ot(D)) return $(C, x, D, q);
                if (dt(D)) {
                    if (lt = dt(D), typeof lt != "function") throw Error(r(150));
                    return D = lt.call(D), st(C, x, D, q)
                }
                if (typeof D.then == "function") return wt(C, x, pu(D), q);
                if (D.$$typeof === Q) return wt(C, x, du(C, D), q);
                vu(C, D)
            }
            return typeof D == "string" && D !== "" || typeof D == "number" || typeof D == "bigint" ? (D = "" + D, x !== null && x.tag === 6 ? (n(C, x.sibling), q = s(x, D), q.return = C, C = q) : (n(C, x), q = ur(D, C.mode, q), q.return = C, C = q), d(C)) : n(C, x)
        }
        return function(C, x, D, q) {
            try {
                Il = 0;
                var lt = wt(C, x, D, q);
                return ul = null, lt
            } catch (nt) {
                if (nt === il || nt === mu) throw nt;
                var bt = xe(29, nt, null, C.mode);
                return bt.lanes = q, bt.return = C, bt
            }
        }
    }
    var Ea = Xf(!0),
        Vf = Xf(!1),
        Un = !1;

    function Sr(t) {
        t.updateQueue = {
            baseState: t.memoizedState,
            firstBaseUpdate: null,
            lastBaseUpdate: null,
            shared: {
                pending: null,
                lanes: 0,
                hiddenCallbacks: null
            },
            callbacks: null
        }
    }

    function br(t, e) {
        t = t.updateQueue, e.updateQueue === t && (e.updateQueue = {
            baseState: t.baseState,
            firstBaseUpdate: t.firstBaseUpdate,
            lastBaseUpdate: t.lastBaseUpdate,
            shared: t.shared,
            callbacks: null
        })
    }

    function Nn(t) {
        return {
            lane: t,
            tag: 0,
            payload: null,
            callback: null,
            next: null
        }
    }

    function Bn(t, e, n) {
        var l = t.updateQueue;
        if (l === null) return null;
        if (l = l.shared, (Tt & 2) !== 0) {
            var s = l.pending;
            return s === null ? e.next = e : (e.next = s.next, s.next = e), l.pending = e, e = ru(t), xf(t, null, n), e
        }
        return su(t, l, e, n), ru(t)
    }

    function $l(t, e, n) {
        if (e = e.updateQueue, e !== null && (e = e.shared, (n & 4194048) !== 0)) {
            var l = e.lanes;
            l &= t.pendingLanes, n |= l, e.lanes = n, Lc(t, n)
        }
    }

    function _r(t, e) {
        var n = t.updateQueue,
            l = t.alternate;
        if (l !== null && (l = l.updateQueue, n === l)) {
            var s = null,
                o = null;
            if (n = n.firstBaseUpdate, n !== null) {
                do {
                    var d = {
                        lane: n.lane,
                        tag: n.tag,
                        payload: n.payload,
                        callback: null,
                        next: null
                    };
                    o === null ? s = o = d : o = o.next = d, n = n.next
                } while (n !== null);
                o === null ? s = o = e : o = o.next = e
            } else s = o = e;
            n = {
                baseState: l.baseState,
                firstBaseUpdate: s,
                lastBaseUpdate: o,
                shared: l.shared,
                callbacks: l.callbacks
            }, t.updateQueue = n;
            return
        }
        t = n.lastBaseUpdate, t === null ? n.firstBaseUpdate = e : t.next = e, n.lastBaseUpdate = e
    }
    var Er = !1;

    function ti() {
        if (Er) {
            var t = ll;
            if (t !== null) throw t
        }
    }

    function ei(t, e, n, l) {
        Er = !1;
        var s = t.updateQueue;
        Un = !1;
        var o = s.firstBaseUpdate,
            d = s.lastBaseUpdate,
            v = s.shared.pending;
        if (v !== null) {
            s.shared.pending = null;
            var R = v,
                L = R.next;
            R.next = null, d === null ? o = L : d.next = L, d = R;
            var j = t.alternate;
            j !== null && (j = j.updateQueue, v = j.lastBaseUpdate, v !== d && (v === null ? j.firstBaseUpdate = L : v.next = L, j.lastBaseUpdate = R))
        }
        if (o !== null) {
            var G = s.baseState;
            d = 0, j = L = R = null, v = o;
            do {
                var U = v.lane & -536870913,
                    N = U !== v.lane;
                if (N ? (yt & U) === U : (l & U) === U) {
                    U !== 0 && U === al && (Er = !0), j !== null && (j = j.next = {
                        lane: 0,
                        tag: v.tag,
                        payload: v.payload,
                        callback: null,
                        next: null
                    });
                    t: {
                        var $ = t,
                            st = v;U = e;
                        var wt = n;
                        switch (st.tag) {
                            case 1:
                                if ($ = st.payload, typeof $ == "function") {
                                    G = $.call(wt, G, U);
                                    break t
                                }
                                G = $;
                                break t;
                            case 3:
                                $.flags = $.flags & -65537 | 128;
                            case 0:
                                if ($ = st.payload, U = typeof $ == "function" ? $.call(wt, G, U) : $, U == null) break t;
                                G = g({}, G, U);
                                break t;
                            case 2:
                                Un = !0
                        }
                    }
                    U = v.callback, U !== null && (t.flags |= 64, N && (t.flags |= 8192), N = s.callbacks, N === null ? s.callbacks = [U] : N.push(U))
                } else N = {
                    lane: U,
                    tag: v.tag,
                    payload: v.payload,
                    callback: v.callback,
                    next: null
                }, j === null ? (L = j = N, R = G) : j = j.next = N, d |= U;
                if (v = v.next, v === null) {
                    if (v = s.shared.pending, v === null) break;
                    N = v, v = N.next, N.next = null, s.lastBaseUpdate = N, s.shared.pending = null
                }
            } while (!0);
            j === null && (R = G), s.baseState = R, s.firstBaseUpdate = L, s.lastBaseUpdate = j, o === null && (s.shared.lanes = 0), Gn |= d, t.lanes = d, t.memoizedState = G
        }
    }

    function Qf(t, e) {
        if (typeof t != "function") throw Error(r(191, t));
        t.call(e)
    }

    function Zf(t, e) {
        var n = t.callbacks;
        if (n !== null)
            for (t.callbacks = null, t = 0; t < n.length; t++) Qf(n[t], e)
    }
    var sl = M(null),
        gu = M(0);

    function Kf(t, e) {
        t = Sn, k(gu, t), k(sl, e), Sn = t | e.baseLanes
    }

    function Rr() {
        k(gu, Sn), k(sl, sl.current)
    }

    function Tr() {
        Sn = gu.current, Y(sl), Y(gu)
    }
    var Me = M(null),
        qe = null;

    function jn(t) {
        var e = t.alternate;
        k(Qt, Qt.current & 1), k(Me, t), qe === null && (e === null || sl.current !== null || e.memoizedState !== null) && (qe = t)
    }

    function Ar(t) {
        k(Qt, Qt.current), k(Me, t), qe === null && (qe = t)
    }

    function Jf(t) {
        t.tag === 22 ? (k(Qt, Qt.current), k(Me, t), qe === null && (qe = t)) : Hn()
    }

    function Hn() {
        k(Qt, Qt.current), k(Me, Me.current)
    }

    function Oe(t) {
        Y(Me), qe === t && (qe = null), Y(Qt)
    }
    var Qt = M(0);

    function Su(t) {
        for (var e = t; e !== null;) {
            if (e.tag === 13) {
                var n = e.memoizedState;
                if (n !== null && (n = n.dehydrated, n === null || Do(n) || Lo(n))) return e
            } else if (e.tag === 19 && (e.memoizedProps.revealOrder === "forwards" || e.memoizedProps.revealOrder === "backwards" || e.memoizedProps.revealOrder === "unstable_legacy-backwards" || e.memoizedProps.revealOrder === "together")) {
                if ((e.flags & 128) !== 0) return e
            } else if (e.child !== null) {
                e.child.return = e, e = e.child;
                continue
            }
            if (e === t) break;
            for (; e.sibling === null;) {
                if (e.return === null || e.return === t) return null;
                e = e.return
            }
            e.sibling.return = e.return, e = e.sibling
        }
        return null
    }
    var fn = 0,
        ot = null,
        zt = null,
        Jt = null,
        bu = !1,
        rl = !1,
        Ra = !1,
        _u = 0,
        ni = 0,
        ol = null,
        kv = 0;

    function Gt() {
        throw Error(r(321))
    }

    function xr(t, e) {
        if (e === null) return !1;
        for (var n = 0; n < e.length && n < t.length; n++)
            if (!Ae(t[n], e[n])) return !1;
        return !0
    }

    function Mr(t, e, n, l, s, o) {
        return fn = o, ot = e, e.memoizedState = null, e.updateQueue = null, e.lanes = 0, B.H = t === null || t.memoizedState === null ? Cd : Xr, Ra = !1, o = n(l, s), Ra = !1, rl && (o = Pf(e, n, l, s)), kf(t), o
    }

    function kf(t) {
        B.H = ii;
        var e = zt !== null && zt.next !== null;
        if (fn = 0, Jt = zt = ot = null, bu = !1, ni = 0, ol = null, e) throw Error(r(300));
        t === null || kt || (t = t.dependencies, t !== null && fu(t) && (kt = !0))
    }

    function Pf(t, e, n, l) {
        ot = t;
        var s = 0;
        do {
            if (rl && (ol = null), ni = 0, rl = !1, 25 <= s) throw Error(r(301));
            if (s += 1, Jt = zt = null, t.updateQueue != null) {
                var o = t.updateQueue;
                o.lastEffect = null, o.events = null, o.stores = null, o.memoCache != null && (o.memoCache.index = 0)
            }
            B.H = wd, o = e(n, l)
        } while (rl);
        return o
    }

    function Pv() {
        var t = B.H,
            e = t.useState()[0];
        return e = typeof e.then == "function" ? ai(e) : e, t = t.useState()[0], (zt !== null ? zt.memoizedState : null) !== t && (ot.flags |= 1024), e
    }

    function Or() {
        var t = _u !== 0;
        return _u = 0, t
    }

    function zr(t, e, n) {
        e.updateQueue = t.updateQueue, e.flags &= -2053, t.lanes &= ~n
    }

    function Cr(t) {
        if (bu) {
            for (t = t.memoizedState; t !== null;) {
                var e = t.queue;
                e !== null && (e.pending = null), t = t.next
            }
            bu = !1
        }
        fn = 0, Jt = zt = ot = null, rl = !1, ni = _u = 0, ol = null
    }

    function de() {
        var t = {
            memoizedState: null,
            baseState: null,
            baseQueue: null,
            queue: null,
            next: null
        };
        return Jt === null ? ot.memoizedState = Jt = t : Jt = Jt.next = t, Jt
    }

    function Zt() {
        if (zt === null) {
            var t = ot.alternate;
            t = t !== null ? t.memoizedState : null
        } else t = zt.next;
        var e = Jt === null ? ot.memoizedState : Jt.next;
        if (e !== null) Jt = e, zt = t;
        else {
            if (t === null) throw ot.alternate === null ? Error(r(467)) : Error(r(310));
            zt = t, t = {
                memoizedState: zt.memoizedState,
                baseState: zt.baseState,
                baseQueue: zt.baseQueue,
                queue: zt.queue,
                next: null
            }, Jt === null ? ot.memoizedState = Jt = t : Jt = Jt.next = t
        }
        return Jt
    }

    function Eu() {
        return {
            lastEffect: null,
            events: null,
            stores: null,
            memoCache: null
        }
    }

    function ai(t) {
        var e = ni;
        return ni += 1, ol === null && (ol = []), t = qf(ol, t, e), e = ot, (Jt === null ? e.memoizedState : Jt.next) === null && (e = e.alternate, B.H = e === null || e.memoizedState === null ? Cd : Xr), t
    }

    function Ru(t) {
        if (t !== null && typeof t == "object") {
            if (typeof t.then == "function") return ai(t);
            if (t.$$typeof === Q) return ue(t)
        }
        throw Error(r(438, String(t)))
    }

    function wr(t) {
        var e = null,
            n = ot.updateQueue;
        if (n !== null && (e = n.memoCache), e == null) {
            var l = ot.alternate;
            l !== null && (l = l.updateQueue, l !== null && (l = l.memoCache, l != null && (e = {
                data: l.data.map(function(s) {
                    return s.slice()
                }),
                index: 0
            })))
        }
        if (e == null && (e = {
                data: [],
                index: 0
            }), n === null && (n = Eu(), ot.updateQueue = n), n.memoCache = e, n = e.data[e.index], n === void 0)
            for (n = e.data[e.index] = Array(t), l = 0; l < t; l++) n[l] = ut;
        return e.index++, n
    }

    function dn(t, e) {
        return typeof e == "function" ? e(t) : e
    }

    function Tu(t) {
        var e = Zt();
        return Dr(e, zt, t)
    }

    function Dr(t, e, n) {
        var l = t.queue;
        if (l === null) throw Error(r(311));
        l.lastRenderedReducer = n;
        var s = t.baseQueue,
            o = l.pending;
        if (o !== null) {
            if (s !== null) {
                var d = s.next;
                s.next = o.next, o.next = d
            }
            e.baseQueue = s = o, l.pending = null
        }
        if (o = t.baseState, s === null) t.memoizedState = o;
        else {
            e = s.next;
            var v = d = null,
                R = null,
                L = e,
                j = !1;
            do {
                var G = L.lane & -536870913;
                if (G !== L.lane ? (yt & G) === G : (fn & G) === G) {
                    var U = L.revertLane;
                    if (U === 0) R !== null && (R = R.next = {
                        lane: 0,
                        revertLane: 0,
                        gesture: null,
                        action: L.action,
                        hasEagerState: L.hasEagerState,
                        eagerState: L.eagerState,
                        next: null
                    }), G === al && (j = !0);
                    else if ((fn & U) === U) {
                        L = L.next, U === al && (j = !0);
                        continue
                    } else G = {
                        lane: 0,
                        revertLane: L.revertLane,
                        gesture: null,
                        action: L.action,
                        hasEagerState: L.hasEagerState,
                        eagerState: L.eagerState,
                        next: null
                    }, R === null ? (v = R = G, d = o) : R = R.next = G, ot.lanes |= U, Gn |= U;
                    G = L.action, Ra && n(o, G), o = L.hasEagerState ? L.eagerState : n(o, G)
                } else U = {
                    lane: G,
                    revertLane: L.revertLane,
                    gesture: L.gesture,
                    action: L.action,
                    hasEagerState: L.hasEagerState,
                    eagerState: L.eagerState,
                    next: null
                }, R === null ? (v = R = U, d = o) : R = R.next = U, ot.lanes |= G, Gn |= G;
                L = L.next
            } while (L !== null && L !== e);
            if (R === null ? d = o : R.next = v, !Ae(o, t.memoizedState) && (kt = !0, j && (n = ll, n !== null))) throw n;
            t.memoizedState = o, t.baseState = d, t.baseQueue = R, l.lastRenderedState = o
        }
        return s === null && (l.lanes = 0), [t.memoizedState, l.dispatch]
    }

    function Lr(t) {
        var e = Zt(),
            n = e.queue;
        if (n === null) throw Error(r(311));
        n.lastRenderedReducer = t;
        var l = n.dispatch,
            s = n.pending,
            o = e.memoizedState;
        if (s !== null) {
            n.pending = null;
            var d = s = s.next;
            do o = t(o, d.action), d = d.next; while (d !== s);
            Ae(o, e.memoizedState) || (kt = !0), e.memoizedState = o, e.baseQueue === null && (e.baseState = o), n.lastRenderedState = o
        }
        return [o, l]
    }

    function Ff(t, e, n) {
        var l = ot,
            s = Zt(),
            o = gt;
        if (o) {
            if (n === void 0) throw Error(r(407));
            n = n()
        } else n = e();
        var d = !Ae((zt || s).memoizedState, n);
        if (d && (s.memoizedState = n, kt = !0), s = s.queue, Br($f.bind(null, l, s, t), [t]), s.getSnapshot !== e || d || Jt !== null && Jt.memoizedState.tag & 1) {
            if (l.flags |= 2048, cl(9, {
                    destroy: void 0
                }, Wf.bind(null, l, s, n, e), null), Lt === null) throw Error(r(349));
            o || (fn & 127) !== 0 || If(l, e, n)
        }
        return n
    }

    function If(t, e, n) {
        t.flags |= 16384, t = {
            getSnapshot: e,
            value: n
        }, e = ot.updateQueue, e === null ? (e = Eu(), ot.updateQueue = e, e.stores = [t]) : (n = e.stores, n === null ? e.stores = [t] : n.push(t))
    }

    function Wf(t, e, n, l) {
        e.value = n, e.getSnapshot = l, td(e) && ed(t)
    }

    function $f(t, e, n) {
        return n(function() {
            td(e) && ed(t)
        })
    }

    function td(t) {
        var e = t.getSnapshot;
        t = t.value;
        try {
            var n = e();
            return !Ae(t, n)
        } catch {
            return !0
        }
    }

    function ed(t) {
        var e = ma(t, 2);
        e !== null && Se(e, t, 2)
    }

    function Ur(t) {
        var e = de();
        if (typeof t == "function") {
            var n = t;
            if (t = n(), Ra) {
                Mn(!0);
                try {
                    n()
                } finally {
                    Mn(!1)
                }
            }
        }
        return e.memoizedState = e.baseState = t, e.queue = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: dn,
            lastRenderedState: t
        }, e
    }

    function nd(t, e, n, l) {
        return t.baseState = n, Dr(t, zt, typeof l == "function" ? l : dn)
    }

    function Fv(t, e, n, l, s) {
        if (Mu(t)) throw Error(r(485));
        if (t = e.action, t !== null) {
            var o = {
                payload: s,
                action: t,
                next: null,
                isTransition: !0,
                status: "pending",
                value: null,
                reason: null,
                listeners: [],
                then: function(d) {
                    o.listeners.push(d)
                }
            };
            B.T !== null ? n(!0) : o.isTransition = !1, l(o), n = e.pending, n === null ? (o.next = e.pending = o, ad(e, o)) : (o.next = n.next, e.pending = n.next = o)
        }
    }

    function ad(t, e) {
        var n = e.action,
            l = e.payload,
            s = t.state;
        if (e.isTransition) {
            var o = B.T,
                d = {};
            B.T = d;
            try {
                var v = n(s, l),
                    R = B.S;
                R !== null && R(d, v), ld(t, e, v)
            } catch (L) {
                Nr(t, e, L)
            } finally {
                o !== null && d.types !== null && (o.types = d.types), B.T = o
            }
        } else try {
            o = n(s, l), ld(t, e, o)
        } catch (L) {
            Nr(t, e, L)
        }
    }

    function ld(t, e, n) {
        n !== null && typeof n == "object" && typeof n.then == "function" ? n.then(function(l) {
            id(t, e, l)
        }, function(l) {
            return Nr(t, e, l)
        }) : id(t, e, n)
    }

    function id(t, e, n) {
        e.status = "fulfilled", e.value = n, ud(e), t.state = n, e = t.pending, e !== null && (n = e.next, n === e ? t.pending = null : (n = n.next, e.next = n, ad(t, n)))
    }

    function Nr(t, e, n) {
        var l = t.pending;
        if (t.pending = null, l !== null) {
            l = l.next;
            do e.status = "rejected", e.reason = n, ud(e), e = e.next; while (e !== l)
        }
        t.action = null
    }

    function ud(t) {
        t = t.listeners;
        for (var e = 0; e < t.length; e++)(0, t[e])()
    }

    function sd(t, e) {
        return e
    }

    function rd(t, e) {
        if (gt) {
            var n = Lt.formState;
            if (n !== null) {
                t: {
                    var l = ot;
                    if (gt) {
                        if (Bt) {
                            e: {
                                for (var s = Bt, o = He; s.nodeType !== 8;) {
                                    if (!o) {
                                        s = null;
                                        break e
                                    }
                                    if (s = Ye(s.nextSibling), s === null) {
                                        s = null;
                                        break e
                                    }
                                }
                                o = s.data,
                                s = o === "F!" || o === "F" ? s : null
                            }
                            if (s) {
                                Bt = Ye(s.nextSibling), l = s.data === "F!";
                                break t
                            }
                        }
                        Dn(l)
                    }
                    l = !1
                }
                l && (e = n[0])
            }
        }
        return n = de(), n.memoizedState = n.baseState = e, l = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: sd,
            lastRenderedState: e
        }, n.queue = l, n = Md.bind(null, ot, l), l.dispatch = n, l = Ur(!1), o = Gr.bind(null, ot, !1, l.queue), l = de(), s = {
            state: e,
            dispatch: null,
            action: t,
            pending: null
        }, l.queue = s, n = Fv.bind(null, ot, s, o, n), s.dispatch = n, l.memoizedState = t, [e, n, !1]
    }

    function od(t) {
        var e = Zt();
        return cd(e, zt, t)
    }

    function cd(t, e, n) {
        if (e = Dr(t, e, sd)[0], t = Tu(dn)[0], typeof e == "object" && e !== null && typeof e.then == "function") try {
            var l = ai(e)
        } catch (d) {
            throw d === il ? mu : d
        } else l = e;
        e = Zt();
        var s = e.queue,
            o = s.dispatch;
        return n !== e.memoizedState && (ot.flags |= 2048, cl(9, {
            destroy: void 0
        }, Iv.bind(null, s, n), null)), [l, o, t]
    }

    function Iv(t, e) {
        t.action = e
    }

    function fd(t) {
        var e = Zt(),
            n = zt;
        if (n !== null) return cd(e, n, t);
        Zt(), e = e.memoizedState, n = Zt();
        var l = n.queue.dispatch;
        return n.memoizedState = t, [e, l, !1]
    }

    function cl(t, e, n, l) {
        return t = {
            tag: t,
            create: n,
            deps: l,
            inst: e,
            next: null
        }, e = ot.updateQueue, e === null && (e = Eu(), ot.updateQueue = e), n = e.lastEffect, n === null ? e.lastEffect = t.next = t : (l = n.next, n.next = t, t.next = l, e.lastEffect = t), t
    }

    function dd() {
        return Zt().memoizedState
    }

    function Au(t, e, n, l) {
        var s = de();
        ot.flags |= t, s.memoizedState = cl(1 | e, {
            destroy: void 0
        }, n, l === void 0 ? null : l)
    }

    function xu(t, e, n, l) {
        var s = Zt();
        l = l === void 0 ? null : l;
        var o = s.memoizedState.inst;
        zt !== null && l !== null && xr(l, zt.memoizedState.deps) ? s.memoizedState = cl(e, o, n, l) : (ot.flags |= t, s.memoizedState = cl(1 | e, o, n, l))
    }

    function hd(t, e) {
        Au(8390656, 8, t, e)
    }

    function Br(t, e) {
        xu(2048, 8, t, e)
    }

    function Wv(t) {
        ot.flags |= 4;
        var e = ot.updateQueue;
        if (e === null) e = Eu(), ot.updateQueue = e, e.events = [t];
        else {
            var n = e.events;
            n === null ? e.events = [t] : n.push(t)
        }
    }

    function md(t) {
        var e = Zt().memoizedState;
        return Wv({
                ref: e,
                nextImpl: t
            }),
            function() {
                if ((Tt & 2) !== 0) throw Error(r(440));
                return e.impl.apply(void 0, arguments)
            }
    }

    function yd(t, e) {
        return xu(4, 2, t, e)
    }

    function pd(t, e) {
        return xu(4, 4, t, e)
    }

    function vd(t, e) {
        if (typeof e == "function") {
            t = t();
            var n = e(t);
            return function() {
                typeof n == "function" ? n() : e(null)
            }
        }
        if (e != null) return t = t(), e.current = t,
            function() {
                e.current = null
            }
    }

    function gd(t, e, n) {
        n = n != null ? n.concat([t]) : null, xu(4, 4, vd.bind(null, e, t), n)
    }

    function jr() {}

    function Sd(t, e) {
        var n = Zt();
        e = e === void 0 ? null : e;
        var l = n.memoizedState;
        return e !== null && xr(e, l[1]) ? l[0] : (n.memoizedState = [t, e], t)
    }

    function bd(t, e) {
        var n = Zt();
        e = e === void 0 ? null : e;
        var l = n.memoizedState;
        if (e !== null && xr(e, l[1])) return l[0];
        if (l = t(), Ra) {
            Mn(!0);
            try {
                t()
            } finally {
                Mn(!1)
            }
        }
        return n.memoizedState = [l, e], l
    }

    function Hr(t, e, n) {
        return n === void 0 || (fn & 1073741824) !== 0 && (yt & 261930) === 0 ? t.memoizedState = e : (t.memoizedState = n, t = _h(), ot.lanes |= t, Gn |= t, n)
    }

    function _d(t, e, n, l) {
        return Ae(n, e) ? n : sl.current !== null ? (t = Hr(t, n, l), Ae(t, e) || (kt = !0), t) : (fn & 42) === 0 || (fn & 1073741824) !== 0 && (yt & 261930) === 0 ? (kt = !0, t.memoizedState = n) : (t = _h(), ot.lanes |= t, Gn |= t, e)
    }

    function Ed(t, e, n, l, s) {
        var o = K.p;
        K.p = o !== 0 && 8 > o ? o : 8;
        var d = B.T,
            v = {};
        B.T = v, Gr(t, !1, e, n);
        try {
            var R = s(),
                L = B.S;
            if (L !== null && L(v, R), R !== null && typeof R == "object" && typeof R.then == "function") {
                var j = Jv(R, l);
                li(t, e, j, we(t))
            } else li(t, e, l, we(t))
        } catch (G) {
            li(t, e, {
                then: function() {},
                status: "rejected",
                reason: G
            }, we())
        } finally {
            K.p = o, d !== null && v.types !== null && (d.types = v.types), B.T = d
        }
    }

    function $v() {}

    function qr(t, e, n, l) {
        if (t.tag !== 5) throw Error(r(476));
        var s = Rd(t).queue;
        Ed(t, s, e, it, n === null ? $v : function() {
            return Td(t), n(l)
        })
    }

    function Rd(t) {
        var e = t.memoizedState;
        if (e !== null) return e;
        e = {
            memoizedState: it,
            baseState: it,
            baseQueue: null,
            queue: {
                pending: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: dn,
                lastRenderedState: it
            },
            next: null
        };
        var n = {};
        return e.next = {
            memoizedState: n,
            baseState: n,
            baseQueue: null,
            queue: {
                pending: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: dn,
                lastRenderedState: n
            },
            next: null
        }, t.memoizedState = e, t = t.alternate, t !== null && (t.memoizedState = e), e
    }

    function Td(t) {
        var e = Rd(t);
        e.next === null && (e = t.alternate.memoizedState), li(t, e.next.queue, {}, we())
    }

    function Yr() {
        return ue(_i)
    }

    function Ad() {
        return Zt().memoizedState
    }

    function xd() {
        return Zt().memoizedState
    }

    function tg(t) {
        for (var e = t.return; e !== null;) {
            switch (e.tag) {
                case 24:
                case 3:
                    var n = we();
                    t = Nn(n);
                    var l = Bn(e, t, n);
                    l !== null && (Se(l, e, n), $l(l, e, n)), e = {
                        cache: yr()
                    }, t.payload = e;
                    return
            }
            e = e.return
        }
    }

    function eg(t, e, n) {
        var l = we();
        n = {
            lane: l,
            revertLane: 0,
            gesture: null,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        }, Mu(t) ? Od(e, n) : (n = lr(t, e, n, l), n !== null && (Se(n, t, l), zd(n, e, l)))
    }

    function Md(t, e, n) {
        var l = we();
        li(t, e, n, l)
    }

    function li(t, e, n, l) {
        var s = {
            lane: l,
            revertLane: 0,
            gesture: null,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        };
        if (Mu(t)) Od(e, s);
        else {
            var o = t.alternate;
            if (t.lanes === 0 && (o === null || o.lanes === 0) && (o = e.lastRenderedReducer, o !== null)) try {
                var d = e.lastRenderedState,
                    v = o(d, n);
                if (s.hasEagerState = !0, s.eagerState = v, Ae(v, d)) return su(t, e, s, 0), Lt === null && uu(), !1
            } catch {}
            if (n = lr(t, e, s, l), n !== null) return Se(n, t, l), zd(n, e, l), !0
        }
        return !1
    }

    function Gr(t, e, n, l) {
        if (l = {
                lane: 2,
                revertLane: bo(),
                gesture: null,
                action: l,
                hasEagerState: !1,
                eagerState: null,
                next: null
            }, Mu(t)) {
            if (e) throw Error(r(479))
        } else e = lr(t, n, l, 2), e !== null && Se(e, t, 2)
    }

    function Mu(t) {
        var e = t.alternate;
        return t === ot || e !== null && e === ot
    }

    function Od(t, e) {
        rl = bu = !0;
        var n = t.pending;
        n === null ? e.next = e : (e.next = n.next, n.next = e), t.pending = e
    }

    function zd(t, e, n) {
        if ((n & 4194048) !== 0) {
            var l = e.lanes;
            l &= t.pendingLanes, n |= l, e.lanes = n, Lc(t, n)
        }
    }
    var ii = {
        readContext: ue,
        use: Ru,
        useCallback: Gt,
        useContext: Gt,
        useEffect: Gt,
        useImperativeHandle: Gt,
        useLayoutEffect: Gt,
        useInsertionEffect: Gt,
        useMemo: Gt,
        useReducer: Gt,
        useRef: Gt,
        useState: Gt,
        useDebugValue: Gt,
        useDeferredValue: Gt,
        useTransition: Gt,
        useSyncExternalStore: Gt,
        useId: Gt,
        useHostTransitionStatus: Gt,
        useFormState: Gt,
        useActionState: Gt,
        useOptimistic: Gt,
        useMemoCache: Gt,
        useCacheRefresh: Gt
    };
    ii.useEffectEvent = Gt;
    var Cd = {
            readContext: ue,
            use: Ru,
            useCallback: function(t, e) {
                return de().memoizedState = [t, e === void 0 ? null : e], t
            },
            useContext: ue,
            useEffect: hd,
            useImperativeHandle: function(t, e, n) {
                n = n != null ? n.concat([t]) : null, Au(4194308, 4, vd.bind(null, e, t), n)
            },
            useLayoutEffect: function(t, e) {
                return Au(4194308, 4, t, e)
            },
            useInsertionEffect: function(t, e) {
                Au(4, 2, t, e)
            },
            useMemo: function(t, e) {
                var n = de();
                e = e === void 0 ? null : e;
                var l = t();
                if (Ra) {
                    Mn(!0);
                    try {
                        t()
                    } finally {
                        Mn(!1)
                    }
                }
                return n.memoizedState = [l, e], l
            },
            useReducer: function(t, e, n) {
                var l = de();
                if (n !== void 0) {
                    var s = n(e);
                    if (Ra) {
                        Mn(!0);
                        try {
                            n(e)
                        } finally {
                            Mn(!1)
                        }
                    }
                } else s = e;
                return l.memoizedState = l.baseState = s, t = {
                    pending: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: t,
                    lastRenderedState: s
                }, l.queue = t, t = t.dispatch = eg.bind(null, ot, t), [l.memoizedState, t]
            },
            useRef: function(t) {
                var e = de();
                return t = {
                    current: t
                }, e.memoizedState = t
            },
            useState: function(t) {
                t = Ur(t);
                var e = t.queue,
                    n = Md.bind(null, ot, e);
                return e.dispatch = n, [t.memoizedState, n]
            },
            useDebugValue: jr,
            useDeferredValue: function(t, e) {
                var n = de();
                return Hr(n, t, e)
            },
            useTransition: function() {
                var t = Ur(!1);
                return t = Ed.bind(null, ot, t.queue, !0, !1), de().memoizedState = t, [!1, t]
            },
            useSyncExternalStore: function(t, e, n) {
                var l = ot,
                    s = de();
                if (gt) {
                    if (n === void 0) throw Error(r(407));
                    n = n()
                } else {
                    if (n = e(), Lt === null) throw Error(r(349));
                    (yt & 127) !== 0 || If(l, e, n)
                }
                s.memoizedState = n;
                var o = {
                    value: n,
                    getSnapshot: e
                };
                return s.queue = o, hd($f.bind(null, l, o, t), [t]), l.flags |= 2048, cl(9, {
                    destroy: void 0
                }, Wf.bind(null, l, o, n, e), null), n
            },
            useId: function() {
                var t = de(),
                    e = Lt.identifierPrefix;
                if (gt) {
                    var n = Pe,
                        l = ke;
                    n = (l & ~(1 << 32 - Te(l) - 1)).toString(32) + n, e = "_" + e + "R_" + n, n = _u++, 0 < n && (e += "H" + n.toString(32)), e += "_"
                } else n = kv++, e = "_" + e + "r_" + n.toString(32) + "_";
                return t.memoizedState = e
            },
            useHostTransitionStatus: Yr,
            useFormState: rd,
            useActionState: rd,
            useOptimistic: function(t) {
                var e = de();
                e.memoizedState = e.baseState = t;
                var n = {
                    pending: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: null,
                    lastRenderedState: null
                };
                return e.queue = n, e = Gr.bind(null, ot, !0, n), n.dispatch = e, [t, e]
            },
            useMemoCache: wr,
            useCacheRefresh: function() {
                return de().memoizedState = tg.bind(null, ot)
            },
            useEffectEvent: function(t) {
                var e = de(),
                    n = {
                        impl: t
                    };
                return e.memoizedState = n,
                    function() {
                        if ((Tt & 2) !== 0) throw Error(r(440));
                        return n.impl.apply(void 0, arguments)
                    }
            }
        },
        Xr = {
            readContext: ue,
            use: Ru,
            useCallback: Sd,
            useContext: ue,
            useEffect: Br,
            useImperativeHandle: gd,
            useInsertionEffect: yd,
            useLayoutEffect: pd,
            useMemo: bd,
            useReducer: Tu,
            useRef: dd,
            useState: function() {
                return Tu(dn)
            },
            useDebugValue: jr,
            useDeferredValue: function(t, e) {
                var n = Zt();
                return _d(n, zt.memoizedState, t, e)
            },
            useTransition: function() {
                var t = Tu(dn)[0],
                    e = Zt().memoizedState;
                return [typeof t == "boolean" ? t : ai(t), e]
            },
            useSyncExternalStore: Ff,
            useId: Ad,
            useHostTransitionStatus: Yr,
            useFormState: od,
            useActionState: od,
            useOptimistic: function(t, e) {
                var n = Zt();
                return nd(n, zt, t, e)
            },
            useMemoCache: wr,
            useCacheRefresh: xd
        };
    Xr.useEffectEvent = md;
    var wd = {
        readContext: ue,
        use: Ru,
        useCallback: Sd,
        useContext: ue,
        useEffect: Br,
        useImperativeHandle: gd,
        useInsertionEffect: yd,
        useLayoutEffect: pd,
        useMemo: bd,
        useReducer: Lr,
        useRef: dd,
        useState: function() {
            return Lr(dn)
        },
        useDebugValue: jr,
        useDeferredValue: function(t, e) {
            var n = Zt();
            return zt === null ? Hr(n, t, e) : _d(n, zt.memoizedState, t, e)
        },
        useTransition: function() {
            var t = Lr(dn)[0],
                e = Zt().memoizedState;
            return [typeof t == "boolean" ? t : ai(t), e]
        },
        useSyncExternalStore: Ff,
        useId: Ad,
        useHostTransitionStatus: Yr,
        useFormState: fd,
        useActionState: fd,
        useOptimistic: function(t, e) {
            var n = Zt();
            return zt !== null ? nd(n, zt, t, e) : (n.baseState = t, [t, n.queue.dispatch])
        },
        useMemoCache: wr,
        useCacheRefresh: xd
    };
    wd.useEffectEvent = md;

    function Vr(t, e, n, l) {
        e = t.memoizedState, n = n(l, e), n = n == null ? e : g({}, e, n), t.memoizedState = n, t.lanes === 0 && (t.updateQueue.baseState = n)
    }
    var Qr = {
        enqueueSetState: function(t, e, n) {
            t = t._reactInternals;
            var l = we(),
                s = Nn(l);
            s.payload = e, n != null && (s.callback = n), e = Bn(t, s, l), e !== null && (Se(e, t, l), $l(e, t, l))
        },
        enqueueReplaceState: function(t, e, n) {
            t = t._reactInternals;
            var l = we(),
                s = Nn(l);
            s.tag = 1, s.payload = e, n != null && (s.callback = n), e = Bn(t, s, l), e !== null && (Se(e, t, l), $l(e, t, l))
        },
        enqueueForceUpdate: function(t, e) {
            t = t._reactInternals;
            var n = we(),
                l = Nn(n);
            l.tag = 2, e != null && (l.callback = e), e = Bn(t, l, n), e !== null && (Se(e, t, n), $l(e, t, n))
        }
    };

    function Dd(t, e, n, l, s, o, d) {
        return t = t.stateNode, typeof t.shouldComponentUpdate == "function" ? t.shouldComponentUpdate(l, o, d) : e.prototype && e.prototype.isPureReactComponent ? !Zl(n, l) || !Zl(s, o) : !0
    }

    function Ld(t, e, n, l) {
        t = e.state, typeof e.componentWillReceiveProps == "function" && e.componentWillReceiveProps(n, l), typeof e.UNSAFE_componentWillReceiveProps == "function" && e.UNSAFE_componentWillReceiveProps(n, l), e.state !== t && Qr.enqueueReplaceState(e, e.state, null)
    }

    function Ta(t, e) {
        var n = e;
        if ("ref" in e) {
            n = {};
            for (var l in e) l !== "ref" && (n[l] = e[l])
        }
        if (t = t.defaultProps) {
            n === e && (n = g({}, n));
            for (var s in t) n[s] === void 0 && (n[s] = t[s])
        }
        return n
    }

    function Ud(t) {
        iu(t)
    }

    function Nd(t) {
        console.error(t)
    }

    function Bd(t) {
        iu(t)
    }

    function Ou(t, e) {
        try {
            var n = t.onUncaughtError;
            n(e.value, {
                componentStack: e.stack
            })
        } catch (l) {
            setTimeout(function() {
                throw l
            })
        }
    }

    function jd(t, e, n) {
        try {
            var l = t.onCaughtError;
            l(n.value, {
                componentStack: n.stack,
                errorBoundary: e.tag === 1 ? e.stateNode : null
            })
        } catch (s) {
            setTimeout(function() {
                throw s
            })
        }
    }

    function Zr(t, e, n) {
        return n = Nn(n), n.tag = 3, n.payload = {
            element: null
        }, n.callback = function() {
            Ou(t, e)
        }, n
    }

    function Hd(t) {
        return t = Nn(t), t.tag = 3, t
    }

    function qd(t, e, n, l) {
        var s = n.type.getDerivedStateFromError;
        if (typeof s == "function") {
            var o = l.value;
            t.payload = function() {
                return s(o)
            }, t.callback = function() {
                jd(e, n, l)
            }
        }
        var d = n.stateNode;
        d !== null && typeof d.componentDidCatch == "function" && (t.callback = function() {
            jd(e, n, l), typeof s != "function" && (Xn === null ? Xn = new Set([this]) : Xn.add(this));
            var v = l.stack;
            this.componentDidCatch(l.value, {
                componentStack: v !== null ? v : ""
            })
        })
    }

    function ng(t, e, n, l, s) {
        if (n.flags |= 32768, l !== null && typeof l == "object" && typeof l.then == "function") {
            if (e = n.alternate, e !== null && nl(e, n, s, !0), n = Me.current, n !== null) {
                switch (n.tag) {
                    case 31:
                    case 13:
                        return qe === null ? Yu() : n.alternate === null && Xt === 0 && (Xt = 3), n.flags &= -257, n.flags |= 65536, n.lanes = s, l === yu ? n.flags |= 16384 : (e = n.updateQueue, e === null ? n.updateQueue = new Set([l]) : e.add(l), vo(t, l, s)), !1;
                    case 22:
                        return n.flags |= 65536, l === yu ? n.flags |= 16384 : (e = n.updateQueue, e === null ? (e = {
                            transitions: null,
                            markerInstances: null,
                            retryQueue: new Set([l])
                        }, n.updateQueue = e) : (n = e.retryQueue, n === null ? e.retryQueue = new Set([l]) : n.add(l)), vo(t, l, s)), !1
                }
                throw Error(r(435, n.tag))
            }
            return vo(t, l, s), Yu(), !1
        }
        if (gt) return e = Me.current, e !== null ? ((e.flags & 65536) === 0 && (e.flags |= 256), e.flags |= 65536, e.lanes = s, l !== cr && (t = Error(r(422), {
            cause: l
        }), kl(Ne(t, n)))) : (l !== cr && (e = Error(r(423), {
            cause: l
        }), kl(Ne(e, n))), t = t.current.alternate, t.flags |= 65536, s &= -s, t.lanes |= s, l = Ne(l, n), s = Zr(t.stateNode, l, s), _r(t, s), Xt !== 4 && (Xt = 2)), !1;
        var o = Error(r(520), {
            cause: l
        });
        if (o = Ne(o, n), hi === null ? hi = [o] : hi.push(o), Xt !== 4 && (Xt = 2), e === null) return !0;
        l = Ne(l, n), n = e;
        do {
            switch (n.tag) {
                case 3:
                    return n.flags |= 65536, t = s & -s, n.lanes |= t, t = Zr(n.stateNode, l, t), _r(n, t), !1;
                case 1:
                    if (e = n.type, o = n.stateNode, (n.flags & 128) === 0 && (typeof e.getDerivedStateFromError == "function" || o !== null && typeof o.componentDidCatch == "function" && (Xn === null || !Xn.has(o)))) return n.flags |= 65536, s &= -s, n.lanes |= s, s = Hd(s), qd(s, t, n, l), _r(n, s), !1
            }
            n = n.return
        } while (n !== null);
        return !1
    }
    var Kr = Error(r(461)),
        kt = !1;

    function se(t, e, n, l) {
        e.child = t === null ? Vf(e, null, n, l) : Ea(e, t.child, n, l)
    }

    function Yd(t, e, n, l, s) {
        n = n.render;
        var o = e.ref;
        if ("ref" in l) {
            var d = {};
            for (var v in l) v !== "ref" && (d[v] = l[v])
        } else d = l;
        return ga(e), l = Mr(t, e, n, d, o, s), v = Or(), t !== null && !kt ? (zr(t, e, s), hn(t, e, s)) : (gt && v && rr(e), e.flags |= 1, se(t, e, l, s), e.child)
    }

    function Gd(t, e, n, l, s) {
        if (t === null) {
            var o = n.type;
            return typeof o == "function" && !ir(o) && o.defaultProps === void 0 && n.compare === null ? (e.tag = 15, e.type = o, Xd(t, e, o, l, s)) : (t = ou(n.type, null, l, e, e.mode, s), t.ref = e.ref, t.return = e, e.child = t)
        }
        if (o = t.child, !to(t, s)) {
            var d = o.memoizedProps;
            if (n = n.compare, n = n !== null ? n : Zl, n(d, l) && t.ref === e.ref) return hn(t, e, s)
        }
        return e.flags |= 1, t = sn(o, l), t.ref = e.ref, t.return = e, e.child = t
    }

    function Xd(t, e, n, l, s) {
        if (t !== null) {
            var o = t.memoizedProps;
            if (Zl(o, l) && t.ref === e.ref)
                if (kt = !1, e.pendingProps = l = o, to(t, s))(t.flags & 131072) !== 0 && (kt = !0);
                else return e.lanes = t.lanes, hn(t, e, s)
        }
        return Jr(t, e, n, l, s)
    }

    function Vd(t, e, n, l) {
        var s = l.children,
            o = t !== null ? t.memoizedState : null;
        if (t === null && e.stateNode === null && (e.stateNode = {
                _visibility: 1,
                _pendingMarkers: null,
                _retryCache: null,
                _transitions: null
            }), l.mode === "hidden") {
            if ((e.flags & 128) !== 0) {
                if (o = o !== null ? o.baseLanes | n : n, t !== null) {
                    for (l = e.child = t.child, s = 0; l !== null;) s = s | l.lanes | l.childLanes, l = l.sibling;
                    l = s & ~o
                } else l = 0, e.child = null;
                return Qd(t, e, o, n, l)
            }
            if ((n & 536870912) !== 0) e.memoizedState = {
                baseLanes: 0,
                cachePool: null
            }, t !== null && hu(e, o !== null ? o.cachePool : null), o !== null ? Kf(e, o) : Rr(), Jf(e);
            else return l = e.lanes = 536870912, Qd(t, e, o !== null ? o.baseLanes | n : n, n, l)
        } else o !== null ? (hu(e, o.cachePool), Kf(e, o), Hn(), e.memoizedState = null) : (t !== null && hu(e, null), Rr(), Hn());
        return se(t, e, s, n), e.child
    }

    function ui(t, e) {
        return t !== null && t.tag === 22 || e.stateNode !== null || (e.stateNode = {
            _visibility: 1,
            _pendingMarkers: null,
            _retryCache: null,
            _transitions: null
        }), e.sibling
    }

    function Qd(t, e, n, l, s) {
        var o = vr();
        return o = o === null ? null : {
            parent: Kt._currentValue,
            pool: o
        }, e.memoizedState = {
            baseLanes: n,
            cachePool: o
        }, t !== null && hu(e, null), Rr(), Jf(e), t !== null && nl(t, e, l, !0), e.childLanes = s, null
    }

    function zu(t, e) {
        return e = wu({
            mode: e.mode,
            children: e.children
        }, t.mode), e.ref = t.ref, t.child = e, e.return = t, e
    }

    function Zd(t, e, n) {
        return Ea(e, t.child, null, n), t = zu(e, e.pendingProps), t.flags |= 2, Oe(e), e.memoizedState = null, t
    }

    function ag(t, e, n) {
        var l = e.pendingProps,
            s = (e.flags & 128) !== 0;
        if (e.flags &= -129, t === null) {
            if (gt) {
                if (l.mode === "hidden") return t = zu(e, l), e.lanes = 536870912, ui(null, t);
                if (Ar(e), (t = Bt) ? (t = am(t, He), t = t !== null && t.data === "&" ? t : null, t !== null && (e.memoizedState = {
                        dehydrated: t,
                        treeContext: Cn !== null ? {
                            id: ke,
                            overflow: Pe
                        } : null,
                        retryLane: 536870912,
                        hydrationErrors: null
                    }, n = Of(t), n.return = e, e.child = n, ie = e, Bt = null)) : t = null, t === null) throw Dn(e);
                return e.lanes = 536870912, null
            }
            return zu(e, l)
        }
        var o = t.memoizedState;
        if (o !== null) {
            var d = o.dehydrated;
            if (Ar(e), s)
                if (e.flags & 256) e.flags &= -257, e = Zd(t, e, n);
                else if (e.memoizedState !== null) e.child = t.child, e.flags |= 128, e = null;
            else throw Error(r(558));
            else if (kt || nl(t, e, n, !1), s = (n & t.childLanes) !== 0, kt || s) {
                if (l = Lt, l !== null && (d = Uc(l, n), d !== 0 && d !== o.retryLane)) throw o.retryLane = d, ma(t, d), Se(l, t, d), Kr;
                Yu(), e = Zd(t, e, n)
            } else t = o.treeContext, Bt = Ye(d.nextSibling), ie = e, gt = !0, wn = null, He = !1, t !== null && wf(e, t), e = zu(e, l), e.flags |= 4096;
            return e
        }
        return t = sn(t.child, {
            mode: l.mode,
            children: l.children
        }), t.ref = e.ref, e.child = t, t.return = e, t
    }

    function Cu(t, e) {
        var n = e.ref;
        if (n === null) t !== null && t.ref !== null && (e.flags |= 4194816);
        else {
            if (typeof n != "function" && typeof n != "object") throw Error(r(284));
            (t === null || t.ref !== n) && (e.flags |= 4194816)
        }
    }

    function Jr(t, e, n, l, s) {
        return ga(e), n = Mr(t, e, n, l, void 0, s), l = Or(), t !== null && !kt ? (zr(t, e, s), hn(t, e, s)) : (gt && l && rr(e), e.flags |= 1, se(t, e, n, s), e.child)
    }

    function Kd(t, e, n, l, s, o) {
        return ga(e), e.updateQueue = null, n = Pf(e, l, n, s), kf(t), l = Or(), t !== null && !kt ? (zr(t, e, o), hn(t, e, o)) : (gt && l && rr(e), e.flags |= 1, se(t, e, n, o), e.child)
    }

    function Jd(t, e, n, l, s) {
        if (ga(e), e.stateNode === null) {
            var o = Wa,
                d = n.contextType;
            typeof d == "object" && d !== null && (o = ue(d)), o = new n(l, o), e.memoizedState = o.state !== null && o.state !== void 0 ? o.state : null, o.updater = Qr, e.stateNode = o, o._reactInternals = e, o = e.stateNode, o.props = l, o.state = e.memoizedState, o.refs = {}, Sr(e), d = n.contextType, o.context = typeof d == "object" && d !== null ? ue(d) : Wa, o.state = e.memoizedState, d = n.getDerivedStateFromProps, typeof d == "function" && (Vr(e, n, d, l), o.state = e.memoizedState), typeof n.getDerivedStateFromProps == "function" || typeof o.getSnapshotBeforeUpdate == "function" || typeof o.UNSAFE_componentWillMount != "function" && typeof o.componentWillMount != "function" || (d = o.state, typeof o.componentWillMount == "function" && o.componentWillMount(), typeof o.UNSAFE_componentWillMount == "function" && o.UNSAFE_componentWillMount(), d !== o.state && Qr.enqueueReplaceState(o, o.state, null), ei(e, l, o, s), ti(), o.state = e.memoizedState), typeof o.componentDidMount == "function" && (e.flags |= 4194308), l = !0
        } else if (t === null) {
            o = e.stateNode;
            var v = e.memoizedProps,
                R = Ta(n, v);
            o.props = R;
            var L = o.context,
                j = n.contextType;
            d = Wa, typeof j == "object" && j !== null && (d = ue(j));
            var G = n.getDerivedStateFromProps;
            j = typeof G == "function" || typeof o.getSnapshotBeforeUpdate == "function", v = e.pendingProps !== v, j || typeof o.UNSAFE_componentWillReceiveProps != "function" && typeof o.componentWillReceiveProps != "function" || (v || L !== d) && Ld(e, o, l, d), Un = !1;
            var U = e.memoizedState;
            o.state = U, ei(e, l, o, s), ti(), L = e.memoizedState, v || U !== L || Un ? (typeof G == "function" && (Vr(e, n, G, l), L = e.memoizedState), (R = Un || Dd(e, n, R, l, U, L, d)) ? (j || typeof o.UNSAFE_componentWillMount != "function" && typeof o.componentWillMount != "function" || (typeof o.componentWillMount == "function" && o.componentWillMount(), typeof o.UNSAFE_componentWillMount == "function" && o.UNSAFE_componentWillMount()), typeof o.componentDidMount == "function" && (e.flags |= 4194308)) : (typeof o.componentDidMount == "function" && (e.flags |= 4194308), e.memoizedProps = l, e.memoizedState = L), o.props = l, o.state = L, o.context = d, l = R) : (typeof o.componentDidMount == "function" && (e.flags |= 4194308), l = !1)
        } else {
            o = e.stateNode, br(t, e), d = e.memoizedProps, j = Ta(n, d), o.props = j, G = e.pendingProps, U = o.context, L = n.contextType, R = Wa, typeof L == "object" && L !== null && (R = ue(L)), v = n.getDerivedStateFromProps, (L = typeof v == "function" || typeof o.getSnapshotBeforeUpdate == "function") || typeof o.UNSAFE_componentWillReceiveProps != "function" && typeof o.componentWillReceiveProps != "function" || (d !== G || U !== R) && Ld(e, o, l, R), Un = !1, U = e.memoizedState, o.state = U, ei(e, l, o, s), ti();
            var N = e.memoizedState;
            d !== G || U !== N || Un || t !== null && t.dependencies !== null && fu(t.dependencies) ? (typeof v == "function" && (Vr(e, n, v, l), N = e.memoizedState), (j = Un || Dd(e, n, j, l, U, N, R) || t !== null && t.dependencies !== null && fu(t.dependencies)) ? (L || typeof o.UNSAFE_componentWillUpdate != "function" && typeof o.componentWillUpdate != "function" || (typeof o.componentWillUpdate == "function" && o.componentWillUpdate(l, N, R), typeof o.UNSAFE_componentWillUpdate == "function" && o.UNSAFE_componentWillUpdate(l, N, R)), typeof o.componentDidUpdate == "function" && (e.flags |= 4), typeof o.getSnapshotBeforeUpdate == "function" && (e.flags |= 1024)) : (typeof o.componentDidUpdate != "function" || d === t.memoizedProps && U === t.memoizedState || (e.flags |= 4), typeof o.getSnapshotBeforeUpdate != "function" || d === t.memoizedProps && U === t.memoizedState || (e.flags |= 1024), e.memoizedProps = l, e.memoizedState = N), o.props = l, o.state = N, o.context = R, l = j) : (typeof o.componentDidUpdate != "function" || d === t.memoizedProps && U === t.memoizedState || (e.flags |= 4), typeof o.getSnapshotBeforeUpdate != "function" || d === t.memoizedProps && U === t.memoizedState || (e.flags |= 1024), l = !1)
        }
        return o = l, Cu(t, e), l = (e.flags & 128) !== 0, o || l ? (o = e.stateNode, n = l && typeof n.getDerivedStateFromError != "function" ? null : o.render(), e.flags |= 1, t !== null && l ? (e.child = Ea(e, t.child, null, s), e.child = Ea(e, null, n, s)) : se(t, e, n, s), e.memoizedState = o.state, t = e.child) : t = hn(t, e, s), t
    }

    function kd(t, e, n, l) {
        return pa(), e.flags |= 256, se(t, e, n, l), e.child
    }
    var kr = {
        dehydrated: null,
        treeContext: null,
        retryLane: 0,
        hydrationErrors: null
    };

    function Pr(t) {
        return {
            baseLanes: t,
            cachePool: jf()
        }
    }

    function Fr(t, e, n) {
        return t = t !== null ? t.childLanes & ~n : 0, e && (t |= Ce), t
    }

    function Pd(t, e, n) {
        var l = e.pendingProps,
            s = !1,
            o = (e.flags & 128) !== 0,
            d;
        if ((d = o) || (d = t !== null && t.memoizedState === null ? !1 : (Qt.current & 2) !== 0), d && (s = !0, e.flags &= -129), d = (e.flags & 32) !== 0, e.flags &= -33, t === null) {
            if (gt) {
                if (s ? jn(e) : Hn(), (t = Bt) ? (t = am(t, He), t = t !== null && t.data !== "&" ? t : null, t !== null && (e.memoizedState = {
                        dehydrated: t,
                        treeContext: Cn !== null ? {
                            id: ke,
                            overflow: Pe
                        } : null,
                        retryLane: 536870912,
                        hydrationErrors: null
                    }, n = Of(t), n.return = e, e.child = n, ie = e, Bt = null)) : t = null, t === null) throw Dn(e);
                return Lo(t) ? e.lanes = 32 : e.lanes = 536870912, null
            }
            var v = l.children;
            return l = l.fallback, s ? (Hn(), s = e.mode, v = wu({
                mode: "hidden",
                children: v
            }, s), l = ya(l, s, n, null), v.return = e, l.return = e, v.sibling = l, e.child = v, l = e.child, l.memoizedState = Pr(n), l.childLanes = Fr(t, d, n), e.memoizedState = kr, ui(null, l)) : (jn(e), Ir(e, v))
        }
        var R = t.memoizedState;
        if (R !== null && (v = R.dehydrated, v !== null)) {
            if (o) e.flags & 256 ? (jn(e), e.flags &= -257, e = Wr(t, e, n)) : e.memoizedState !== null ? (Hn(), e.child = t.child, e.flags |= 128, e = null) : (Hn(), v = l.fallback, s = e.mode, l = wu({
                mode: "visible",
                children: l.children
            }, s), v = ya(v, s, n, null), v.flags |= 2, l.return = e, v.return = e, l.sibling = v, e.child = l, Ea(e, t.child, null, n), l = e.child, l.memoizedState = Pr(n), l.childLanes = Fr(t, d, n), e.memoizedState = kr, e = ui(null, l));
            else if (jn(e), Lo(v)) {
                if (d = v.nextSibling && v.nextSibling.dataset, d) var L = d.dgst;
                d = L, l = Error(r(419)), l.stack = "", l.digest = d, kl({
                    value: l,
                    source: null,
                    stack: null
                }), e = Wr(t, e, n)
            } else if (kt || nl(t, e, n, !1), d = (n & t.childLanes) !== 0, kt || d) {
                if (d = Lt, d !== null && (l = Uc(d, n), l !== 0 && l !== R.retryLane)) throw R.retryLane = l, ma(t, l), Se(d, t, l), Kr;
                Do(v) || Yu(), e = Wr(t, e, n)
            } else Do(v) ? (e.flags |= 192, e.child = t.child, e = null) : (t = R.treeContext, Bt = Ye(v.nextSibling), ie = e, gt = !0, wn = null, He = !1, t !== null && wf(e, t), e = Ir(e, l.children), e.flags |= 4096);
            return e
        }
        return s ? (Hn(), v = l.fallback, s = e.mode, R = t.child, L = R.sibling, l = sn(R, {
            mode: "hidden",
            children: l.children
        }), l.subtreeFlags = R.subtreeFlags & 65011712, L !== null ? v = sn(L, v) : (v = ya(v, s, n, null), v.flags |= 2), v.return = e, l.return = e, l.sibling = v, e.child = l, ui(null, l), l = e.child, v = t.child.memoizedState, v === null ? v = Pr(n) : (s = v.cachePool, s !== null ? (R = Kt._currentValue, s = s.parent !== R ? {
            parent: R,
            pool: R
        } : s) : s = jf(), v = {
            baseLanes: v.baseLanes | n,
            cachePool: s
        }), l.memoizedState = v, l.childLanes = Fr(t, d, n), e.memoizedState = kr, ui(t.child, l)) : (jn(e), n = t.child, t = n.sibling, n = sn(n, {
            mode: "visible",
            children: l.children
        }), n.return = e, n.sibling = null, t !== null && (d = e.deletions, d === null ? (e.deletions = [t], e.flags |= 16) : d.push(t)), e.child = n, e.memoizedState = null, n)
    }

    function Ir(t, e) {
        return e = wu({
            mode: "visible",
            children: e
        }, t.mode), e.return = t, t.child = e
    }

    function wu(t, e) {
        return t = xe(22, t, null, e), t.lanes = 0, t
    }

    function Wr(t, e, n) {
        return Ea(e, t.child, null, n), t = Ir(e, e.pendingProps.children), t.flags |= 2, e.memoizedState = null, t
    }

    function Fd(t, e, n) {
        t.lanes |= e;
        var l = t.alternate;
        l !== null && (l.lanes |= e), hr(t.return, e, n)
    }

    function $r(t, e, n, l, s, o) {
        var d = t.memoizedState;
        d === null ? t.memoizedState = {
            isBackwards: e,
            rendering: null,
            renderingStartTime: 0,
            last: l,
            tail: n,
            tailMode: s,
            treeForkCount: o
        } : (d.isBackwards = e, d.rendering = null, d.renderingStartTime = 0, d.last = l, d.tail = n, d.tailMode = s, d.treeForkCount = o)
    }

    function Id(t, e, n) {
        var l = e.pendingProps,
            s = l.revealOrder,
            o = l.tail;
        l = l.children;
        var d = Qt.current,
            v = (d & 2) !== 0;
        if (v ? (d = d & 1 | 2, e.flags |= 128) : d &= 1, k(Qt, d), se(t, e, l, n), l = gt ? Jl : 0, !v && t !== null && (t.flags & 128) !== 0) t: for (t = e.child; t !== null;) {
            if (t.tag === 13) t.memoizedState !== null && Fd(t, n, e);
            else if (t.tag === 19) Fd(t, n, e);
            else if (t.child !== null) {
                t.child.return = t, t = t.child;
                continue
            }
            if (t === e) break t;
            for (; t.sibling === null;) {
                if (t.return === null || t.return === e) break t;
                t = t.return
            }
            t.sibling.return = t.return, t = t.sibling
        }
        switch (s) {
            case "forwards":
                for (n = e.child, s = null; n !== null;) t = n.alternate, t !== null && Su(t) === null && (s = n), n = n.sibling;
                n = s, n === null ? (s = e.child, e.child = null) : (s = n.sibling, n.sibling = null), $r(e, !1, s, n, o, l);
                break;
            case "backwards":
            case "unstable_legacy-backwards":
                for (n = null, s = e.child, e.child = null; s !== null;) {
                    if (t = s.alternate, t !== null && Su(t) === null) {
                        e.child = s;
                        break
                    }
                    t = s.sibling, s.sibling = n, n = s, s = t
                }
                $r(e, !0, n, null, o, l);
                break;
            case "together":
                $r(e, !1, null, null, void 0, l);
                break;
            default:
                e.memoizedState = null
        }
        return e.child
    }

    function hn(t, e, n) {
        if (t !== null && (e.dependencies = t.dependencies), Gn |= e.lanes, (n & e.childLanes) === 0)
            if (t !== null) {
                if (nl(t, e, n, !1), (n & e.childLanes) === 0) return null
            } else return null;
        if (t !== null && e.child !== t.child) throw Error(r(153));
        if (e.child !== null) {
            for (t = e.child, n = sn(t, t.pendingProps), e.child = n, n.return = e; t.sibling !== null;) t = t.sibling, n = n.sibling = sn(t, t.pendingProps), n.return = e;
            n.sibling = null
        }
        return e.child
    }

    function to(t, e) {
        return (t.lanes & e) !== 0 ? !0 : (t = t.dependencies, !!(t !== null && fu(t)))
    }

    function lg(t, e, n) {
        switch (e.tag) {
            case 3:
                Vt(e, e.stateNode.containerInfo), Ln(e, Kt, t.memoizedState.cache), pa();
                break;
            case 27:
            case 5:
                tn(e);
                break;
            case 4:
                Vt(e, e.stateNode.containerInfo);
                break;
            case 10:
                Ln(e, e.type, e.memoizedProps.value);
                break;
            case 31:
                if (e.memoizedState !== null) return e.flags |= 128, Ar(e), null;
                break;
            case 13:
                var l = e.memoizedState;
                if (l !== null) return l.dehydrated !== null ? (jn(e), e.flags |= 128, null) : (n & e.child.childLanes) !== 0 ? Pd(t, e, n) : (jn(e), t = hn(t, e, n), t !== null ? t.sibling : null);
                jn(e);
                break;
            case 19:
                var s = (t.flags & 128) !== 0;
                if (l = (n & e.childLanes) !== 0, l || (nl(t, e, n, !1), l = (n & e.childLanes) !== 0), s) {
                    if (l) return Id(t, e, n);
                    e.flags |= 128
                }
                if (s = e.memoizedState, s !== null && (s.rendering = null, s.tail = null, s.lastEffect = null), k(Qt, Qt.current), l) break;
                return null;
            case 22:
                return e.lanes = 0, Vd(t, e, n, e.pendingProps);
            case 24:
                Ln(e, Kt, t.memoizedState.cache)
        }
        return hn(t, e, n)
    }

    function Wd(t, e, n) {
        if (t !== null)
            if (t.memoizedProps !== e.pendingProps) kt = !0;
            else {
                if (!to(t, n) && (e.flags & 128) === 0) return kt = !1, lg(t, e, n);
                kt = (t.flags & 131072) !== 0
            }
        else kt = !1, gt && (e.flags & 1048576) !== 0 && Cf(e, Jl, e.index);
        switch (e.lanes = 0, e.tag) {
            case 16:
                t: {
                    var l = e.pendingProps;
                    if (t = ba(e.elementType), e.type = t, typeof t == "function") ir(t) ? (l = Ta(t, l), e.tag = 1, e = Jd(null, e, t, l, n)) : (e.tag = 0, e = Jr(null, e, t, l, n));
                    else {
                        if (t != null) {
                            var s = t.$$typeof;
                            if (s === H) {
                                e.tag = 11, e = Yd(null, e, t, l, n);
                                break t
                            } else if (s === V) {
                                e.tag = 14, e = Gd(null, e, t, l, n);
                                break t
                            }
                        }
                        throw e = Yt(t) || t, Error(r(306, e, ""))
                    }
                }
                return e;
            case 0:
                return Jr(t, e, e.type, e.pendingProps, n);
            case 1:
                return l = e.type, s = Ta(l, e.pendingProps), Jd(t, e, l, s, n);
            case 3:
                t: {
                    if (Vt(e, e.stateNode.containerInfo), t === null) throw Error(r(387));l = e.pendingProps;
                    var o = e.memoizedState;s = o.element,
                    br(t, e),
                    ei(e, l, null, n);
                    var d = e.memoizedState;
                    if (l = d.cache, Ln(e, Kt, l), l !== o.cache && mr(e, [Kt], n, !0), ti(), l = d.element, o.isDehydrated)
                        if (o = {
                                element: l,
                                isDehydrated: !1,
                                cache: d.cache
                            }, e.updateQueue.baseState = o, e.memoizedState = o, e.flags & 256) {
                            e = kd(t, e, l, n);
                            break t
                        } else if (l !== s) {
                        s = Ne(Error(r(424)), e), kl(s), e = kd(t, e, l, n);
                        break t
                    } else
                        for (t = e.stateNode.containerInfo, t.nodeType === 9 ? t = t.body : t = t.nodeName === "HTML" ? t.ownerDocument.body : t, Bt = Ye(t.firstChild), ie = e, gt = !0, wn = null, He = !0, n = Vf(e, null, l, n), e.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling;
                    else {
                        if (pa(), l === s) {
                            e = hn(t, e, n);
                            break t
                        }
                        se(t, e, l, n)
                    }
                    e = e.child
                }
                return e;
            case 26:
                return Cu(t, e), t === null ? (n = om(e.type, null, e.pendingProps, null)) ? e.memoizedState = n : gt || (n = e.type, t = e.pendingProps, l = Ju(ft.current).createElement(n), l[le] = e, l[he] = t, re(l, n, t), te(l), e.stateNode = l) : e.memoizedState = om(e.type, t.memoizedProps, e.pendingProps, t.memoizedState), null;
            case 27:
                return tn(e), t === null && gt && (l = e.stateNode = um(e.type, e.pendingProps, ft.current), ie = e, He = !0, s = Bt, Kn(e.type) ? (Uo = s, Bt = Ye(l.firstChild)) : Bt = s), se(t, e, e.pendingProps.children, n), Cu(t, e), t === null && (e.flags |= 4194304), e.child;
            case 5:
                return t === null && gt && ((s = l = Bt) && (l = Ug(l, e.type, e.pendingProps, He), l !== null ? (e.stateNode = l, ie = e, Bt = Ye(l.firstChild), He = !1, s = !0) : s = !1), s || Dn(e)), tn(e), s = e.type, o = e.pendingProps, d = t !== null ? t.memoizedProps : null, l = o.children, zo(s, o) ? l = null : d !== null && zo(s, d) && (e.flags |= 32), e.memoizedState !== null && (s = Mr(t, e, Pv, null, null, n), _i._currentValue = s), Cu(t, e), se(t, e, l, n), e.child;
            case 6:
                return t === null && gt && ((t = n = Bt) && (n = Ng(n, e.pendingProps, He), n !== null ? (e.stateNode = n, ie = e, Bt = null, t = !0) : t = !1), t || Dn(e)), null;
            case 13:
                return Pd(t, e, n);
            case 4:
                return Vt(e, e.stateNode.containerInfo), l = e.pendingProps, t === null ? e.child = Ea(e, null, l, n) : se(t, e, l, n), e.child;
            case 11:
                return Yd(t, e, e.type, e.pendingProps, n);
            case 7:
                return se(t, e, e.pendingProps, n), e.child;
            case 8:
                return se(t, e, e.pendingProps.children, n), e.child;
            case 12:
                return se(t, e, e.pendingProps.children, n), e.child;
            case 10:
                return l = e.pendingProps, Ln(e, e.type, l.value), se(t, e, l.children, n), e.child;
            case 9:
                return s = e.type._context, l = e.pendingProps.children, ga(e), s = ue(s), l = l(s), e.flags |= 1, se(t, e, l, n), e.child;
            case 14:
                return Gd(t, e, e.type, e.pendingProps, n);
            case 15:
                return Xd(t, e, e.type, e.pendingProps, n);
            case 19:
                return Id(t, e, n);
            case 31:
                return ag(t, e, n);
            case 22:
                return Vd(t, e, n, e.pendingProps);
            case 24:
                return ga(e), l = ue(Kt), t === null ? (s = vr(), s === null && (s = Lt, o = yr(), s.pooledCache = o, o.refCount++, o !== null && (s.pooledCacheLanes |= n), s = o), e.memoizedState = {
                    parent: l,
                    cache: s
                }, Sr(e), Ln(e, Kt, s)) : ((t.lanes & n) !== 0 && (br(t, e), ei(e, null, null, n), ti()), s = t.memoizedState, o = e.memoizedState, s.parent !== l ? (s = {
                    parent: l,
                    cache: l
                }, e.memoizedState = s, e.lanes === 0 && (e.memoizedState = e.updateQueue.baseState = s), Ln(e, Kt, l)) : (l = o.cache, Ln(e, Kt, l), l !== s.cache && mr(e, [Kt], n, !0))), se(t, e, e.pendingProps.children, n), e.child;
            case 29:
                throw e.pendingProps
        }
        throw Error(r(156, e.tag))
    }

    function mn(t) {
        t.flags |= 4
    }

    function eo(t, e, n, l, s) {
        if ((e = (t.mode & 32) !== 0) && (e = !1), e) {
            if (t.flags |= 16777216, (s & 335544128) === s)
                if (t.stateNode.complete) t.flags |= 8192;
                else if (Ah()) t.flags |= 8192;
            else throw _a = yu, gr
        } else t.flags &= -16777217
    }

    function $d(t, e) {
        if (e.type !== "stylesheet" || (e.state.loading & 4) !== 0) t.flags &= -16777217;
        else if (t.flags |= 16777216, !mm(e))
            if (Ah()) t.flags |= 8192;
            else throw _a = yu, gr
    }

    function Du(t, e) {
        e !== null && (t.flags |= 4), t.flags & 16384 && (e = t.tag !== 22 ? wc() : 536870912, t.lanes |= e, ml |= e)
    }

    function si(t, e) {
        if (!gt) switch (t.tailMode) {
            case "hidden":
                e = t.tail;
                for (var n = null; e !== null;) e.alternate !== null && (n = e), e = e.sibling;
                n === null ? t.tail = null : n.sibling = null;
                break;
            case "collapsed":
                n = t.tail;
                for (var l = null; n !== null;) n.alternate !== null && (l = n), n = n.sibling;
                l === null ? e || t.tail === null ? t.tail = null : t.tail.sibling = null : l.sibling = null
        }
    }

    function jt(t) {
        var e = t.alternate !== null && t.alternate.child === t.child,
            n = 0,
            l = 0;
        if (e)
            for (var s = t.child; s !== null;) n |= s.lanes | s.childLanes, l |= s.subtreeFlags & 65011712, l |= s.flags & 65011712, s.return = t, s = s.sibling;
        else
            for (s = t.child; s !== null;) n |= s.lanes | s.childLanes, l |= s.subtreeFlags, l |= s.flags, s.return = t, s = s.sibling;
        return t.subtreeFlags |= l, t.childLanes = n, e
    }

    function ig(t, e, n) {
        var l = e.pendingProps;
        switch (or(e), e.tag) {
            case 16:
            case 15:
            case 0:
            case 11:
            case 7:
            case 8:
            case 12:
            case 9:
            case 14:
                return jt(e), null;
            case 1:
                return jt(e), null;
            case 3:
                return n = e.stateNode, l = null, t !== null && (l = t.memoizedState.cache), e.memoizedState.cache !== l && (e.flags |= 2048), cn(Kt), Dt(), n.pendingContext && (n.context = n.pendingContext, n.pendingContext = null), (t === null || t.child === null) && (el(e) ? mn(e) : t === null || t.memoizedState.isDehydrated && (e.flags & 256) === 0 || (e.flags |= 1024, fr())), jt(e), null;
            case 26:
                var s = e.type,
                    o = e.memoizedState;
                return t === null ? (mn(e), o !== null ? (jt(e), $d(e, o)) : (jt(e), eo(e, s, null, l, n))) : o ? o !== t.memoizedState ? (mn(e), jt(e), $d(e, o)) : (jt(e), e.flags &= -16777217) : (t = t.memoizedProps, t !== l && mn(e), jt(e), eo(e, s, t, l, n)), null;
            case 27:
                if (en(e), n = ft.current, s = e.type, t !== null && e.stateNode != null) t.memoizedProps !== l && mn(e);
                else {
                    if (!l) {
                        if (e.stateNode === null) throw Error(r(166));
                        return jt(e), null
                    }
                    t = I.current, el(e) ? Df(e) : (t = um(s, l, n), e.stateNode = t, mn(e))
                }
                return jt(e), null;
            case 5:
                if (en(e), s = e.type, t !== null && e.stateNode != null) t.memoizedProps !== l && mn(e);
                else {
                    if (!l) {
                        if (e.stateNode === null) throw Error(r(166));
                        return jt(e), null
                    }
                    if (o = I.current, el(e)) Df(e);
                    else {
                        var d = Ju(ft.current);
                        switch (o) {
                            case 1:
                                o = d.createElementNS("http://www.w3.org/2000/svg", s);
                                break;
                            case 2:
                                o = d.createElementNS("http://www.w3.org/1998/Math/MathML", s);
                                break;
                            default:
                                switch (s) {
                                    case "svg":
                                        o = d.createElementNS("http://www.w3.org/2000/svg", s);
                                        break;
                                    case "math":
                                        o = d.createElementNS("http://www.w3.org/1998/Math/MathML", s);
                                        break;
                                    case "script":
                                        o = d.createElement("div"), o.innerHTML = "<script><\/script>", o = o.removeChild(o.firstChild);
                                        break;
                                    case "select":
                                        o = typeof l.is == "string" ? d.createElement("select", {
                                            is: l.is
                                        }) : d.createElement("select"), l.multiple ? o.multiple = !0 : l.size && (o.size = l.size);
                                        break;
                                    default:
                                        o = typeof l.is == "string" ? d.createElement(s, {
                                            is: l.is
                                        }) : d.createElement(s)
                                }
                        }
                        o[le] = e, o[he] = l;
                        t: for (d = e.child; d !== null;) {
                            if (d.tag === 5 || d.tag === 6) o.appendChild(d.stateNode);
                            else if (d.tag !== 4 && d.tag !== 27 && d.child !== null) {
                                d.child.return = d, d = d.child;
                                continue
                            }
                            if (d === e) break t;
                            for (; d.sibling === null;) {
                                if (d.return === null || d.return === e) break t;
                                d = d.return
                            }
                            d.sibling.return = d.return, d = d.sibling
                        }
                        e.stateNode = o;
                        t: switch (re(o, s, l), s) {
                            case "button":
                            case "input":
                            case "select":
                            case "textarea":
                                l = !!l.autoFocus;
                                break t;
                            case "img":
                                l = !0;
                                break t;
                            default:
                                l = !1
                        }
                        l && mn(e)
                    }
                }
                return jt(e), eo(e, e.type, t === null ? null : t.memoizedProps, e.pendingProps, n), null;
            case 6:
                if (t && e.stateNode != null) t.memoizedProps !== l && mn(e);
                else {
                    if (typeof l != "string" && e.stateNode === null) throw Error(r(166));
                    if (t = ft.current, el(e)) {
                        if (t = e.stateNode, n = e.memoizedProps, l = null, s = ie, s !== null) switch (s.tag) {
                            case 27:
                            case 5:
                                l = s.memoizedProps
                        }
                        t[le] = e, t = !!(t.nodeValue === n || l !== null && l.suppressHydrationWarning === !0 || Ph(t.nodeValue, n)), t || Dn(e, !0)
                    } else t = Ju(t).createTextNode(l), t[le] = e, e.stateNode = t
                }
                return jt(e), null;
            case 31:
                if (n = e.memoizedState, t === null || t.memoizedState !== null) {
                    if (l = el(e), n !== null) {
                        if (t === null) {
                            if (!l) throw Error(r(318));
                            if (t = e.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(r(557));
                            t[le] = e
                        } else pa(), (e.flags & 128) === 0 && (e.memoizedState = null), e.flags |= 4;
                        jt(e), t = !1
                    } else n = fr(), t !== null && t.memoizedState !== null && (t.memoizedState.hydrationErrors = n), t = !0;
                    if (!t) return e.flags & 256 ? (Oe(e), e) : (Oe(e), null);
                    if ((e.flags & 128) !== 0) throw Error(r(558))
                }
                return jt(e), null;
            case 13:
                if (l = e.memoizedState, t === null || t.memoizedState !== null && t.memoizedState.dehydrated !== null) {
                    if (s = el(e), l !== null && l.dehydrated !== null) {
                        if (t === null) {
                            if (!s) throw Error(r(318));
                            if (s = e.memoizedState, s = s !== null ? s.dehydrated : null, !s) throw Error(r(317));
                            s[le] = e
                        } else pa(), (e.flags & 128) === 0 && (e.memoizedState = null), e.flags |= 4;
                        jt(e), s = !1
                    } else s = fr(), t !== null && t.memoizedState !== null && (t.memoizedState.hydrationErrors = s), s = !0;
                    if (!s) return e.flags & 256 ? (Oe(e), e) : (Oe(e), null)
                }
                return Oe(e), (e.flags & 128) !== 0 ? (e.lanes = n, e) : (n = l !== null, t = t !== null && t.memoizedState !== null, n && (l = e.child, s = null, l.alternate !== null && l.alternate.memoizedState !== null && l.alternate.memoizedState.cachePool !== null && (s = l.alternate.memoizedState.cachePool.pool), o = null, l.memoizedState !== null && l.memoizedState.cachePool !== null && (o = l.memoizedState.cachePool.pool), o !== s && (l.flags |= 2048)), n !== t && n && (e.child.flags |= 8192), Du(e, e.updateQueue), jt(e), null);
            case 4:
                return Dt(), t === null && To(e.stateNode.containerInfo), jt(e), null;
            case 10:
                return cn(e.type), jt(e), null;
            case 19:
                if (Y(Qt), l = e.memoizedState, l === null) return jt(e), null;
                if (s = (e.flags & 128) !== 0, o = l.rendering, o === null)
                    if (s) si(l, !1);
                    else {
                        if (Xt !== 0 || t !== null && (t.flags & 128) !== 0)
                            for (t = e.child; t !== null;) {
                                if (o = Su(t), o !== null) {
                                    for (e.flags |= 128, si(l, !1), t = o.updateQueue, e.updateQueue = t, Du(e, t), e.subtreeFlags = 0, t = n, n = e.child; n !== null;) Mf(n, t), n = n.sibling;
                                    return k(Qt, Qt.current & 1 | 2), gt && rn(e, l.treeForkCount), e.child
                                }
                                t = t.sibling
                            }
                        l.tail !== null && oe() > ju && (e.flags |= 128, s = !0, si(l, !1), e.lanes = 4194304)
                    }
                else {
                    if (!s)
                        if (t = Su(o), t !== null) {
                            if (e.flags |= 128, s = !0, t = t.updateQueue, e.updateQueue = t, Du(e, t), si(l, !0), l.tail === null && l.tailMode === "hidden" && !o.alternate && !gt) return jt(e), null
                        } else 2 * oe() - l.renderingStartTime > ju && n !== 536870912 && (e.flags |= 128, s = !0, si(l, !1), e.lanes = 4194304);
                    l.isBackwards ? (o.sibling = e.child, e.child = o) : (t = l.last, t !== null ? t.sibling = o : e.child = o, l.last = o)
                }
                return l.tail !== null ? (t = l.tail, l.rendering = t, l.tail = t.sibling, l.renderingStartTime = oe(), t.sibling = null, n = Qt.current, k(Qt, s ? n & 1 | 2 : n & 1), gt && rn(e, l.treeForkCount), t) : (jt(e), null);
            case 22:
            case 23:
                return Oe(e), Tr(), l = e.memoizedState !== null, t !== null ? t.memoizedState !== null !== l && (e.flags |= 8192) : l && (e.flags |= 8192), l ? (n & 536870912) !== 0 && (e.flags & 128) === 0 && (jt(e), e.subtreeFlags & 6 && (e.flags |= 8192)) : jt(e), n = e.updateQueue, n !== null && Du(e, n.retryQueue), n = null, t !== null && t.memoizedState !== null && t.memoizedState.cachePool !== null && (n = t.memoizedState.cachePool.pool), l = null, e.memoizedState !== null && e.memoizedState.cachePool !== null && (l = e.memoizedState.cachePool.pool), l !== n && (e.flags |= 2048), t !== null && Y(Sa), null;
            case 24:
                return n = null, t !== null && (n = t.memoizedState.cache), e.memoizedState.cache !== n && (e.flags |= 2048), cn(Kt), jt(e), null;
            case 25:
                return null;
            case 30:
                return null
        }
        throw Error(r(156, e.tag))
    }

    function ug(t, e) {
        switch (or(e), e.tag) {
            case 1:
                return t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
            case 3:
                return cn(Kt), Dt(), t = e.flags, (t & 65536) !== 0 && (t & 128) === 0 ? (e.flags = t & -65537 | 128, e) : null;
            case 26:
            case 27:
            case 5:
                return en(e), null;
            case 31:
                if (e.memoizedState !== null) {
                    if (Oe(e), e.alternate === null) throw Error(r(340));
                    pa()
                }
                return t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
            case 13:
                if (Oe(e), t = e.memoizedState, t !== null && t.dehydrated !== null) {
                    if (e.alternate === null) throw Error(r(340));
                    pa()
                }
                return t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
            case 19:
                return Y(Qt), null;
            case 4:
                return Dt(), null;
            case 10:
                return cn(e.type), null;
            case 22:
            case 23:
                return Oe(e), Tr(), t !== null && Y(Sa), t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
            case 24:
                return cn(Kt), null;
            case 25:
                return null;
            default:
                return null
        }
    }

    function th(t, e) {
        switch (or(e), e.tag) {
            case 3:
                cn(Kt), Dt();
                break;
            case 26:
            case 27:
            case 5:
                en(e);
                break;
            case 4:
                Dt();
                break;
            case 31:
                e.memoizedState !== null && Oe(e);
                break;
            case 13:
                Oe(e);
                break;
            case 19:
                Y(Qt);
                break;
            case 10:
                cn(e.type);
                break;
            case 22:
            case 23:
                Oe(e), Tr(), t !== null && Y(Sa);
                break;
            case 24:
                cn(Kt)
        }
    }

    function ri(t, e) {
        try {
            var n = e.updateQueue,
                l = n !== null ? n.lastEffect : null;
            if (l !== null) {
                var s = l.next;
                n = s;
                do {
                    if ((n.tag & t) === t) {
                        l = void 0;
                        var o = n.create,
                            d = n.inst;
                        l = o(), d.destroy = l
                    }
                    n = n.next
                } while (n !== s)
            }
        } catch (v) {
            Mt(e, e.return, v)
        }
    }

    function qn(t, e, n) {
        try {
            var l = e.updateQueue,
                s = l !== null ? l.lastEffect : null;
            if (s !== null) {
                var o = s.next;
                l = o;
                do {
                    if ((l.tag & t) === t) {
                        var d = l.inst,
                            v = d.destroy;
                        if (v !== void 0) {
                            d.destroy = void 0, s = e;
                            var R = n,
                                L = v;
                            try {
                                L()
                            } catch (j) {
                                Mt(s, R, j)
                            }
                        }
                    }
                    l = l.next
                } while (l !== o)
            }
        } catch (j) {
            Mt(e, e.return, j)
        }
    }

    function eh(t) {
        var e = t.updateQueue;
        if (e !== null) {
            var n = t.stateNode;
            try {
                Zf(e, n)
            } catch (l) {
                Mt(t, t.return, l)
            }
        }
    }

    function nh(t, e, n) {
        n.props = Ta(t.type, t.memoizedProps), n.state = t.memoizedState;
        try {
            n.componentWillUnmount()
        } catch (l) {
            Mt(t, e, l)
        }
    }

    function oi(t, e) {
        try {
            var n = t.ref;
            if (n !== null) {
                switch (t.tag) {
                    case 26:
                    case 27:
                    case 5:
                        var l = t.stateNode;
                        break;
                    case 30:
                        l = t.stateNode;
                        break;
                    default:
                        l = t.stateNode
                }
                typeof n == "function" ? t.refCleanup = n(l) : n.current = l
            }
        } catch (s) {
            Mt(t, e, s)
        }
    }

    function Fe(t, e) {
        var n = t.ref,
            l = t.refCleanup;
        if (n !== null)
            if (typeof l == "function") try {
                l()
            } catch (s) {
                Mt(t, e, s)
            } finally {
                t.refCleanup = null, t = t.alternate, t != null && (t.refCleanup = null)
            } else if (typeof n == "function") try {
                n(null)
            } catch (s) {
                Mt(t, e, s)
            } else n.current = null
    }

    function ah(t) {
        var e = t.type,
            n = t.memoizedProps,
            l = t.stateNode;
        try {
            t: switch (e) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                    n.autoFocus && l.focus();
                    break t;
                case "img":
                    n.src ? l.src = n.src : n.srcSet && (l.srcset = n.srcSet)
            }
        }
        catch (s) {
            Mt(t, t.return, s)
        }
    }

    function no(t, e, n) {
        try {
            var l = t.stateNode;
            Og(l, t.type, n, e), l[he] = e
        } catch (s) {
            Mt(t, t.return, s)
        }
    }

    function lh(t) {
        return t.tag === 5 || t.tag === 3 || t.tag === 26 || t.tag === 27 && Kn(t.type) || t.tag === 4
    }

    function ao(t) {
        t: for (;;) {
            for (; t.sibling === null;) {
                if (t.return === null || lh(t.return)) return null;
                t = t.return
            }
            for (t.sibling.return = t.return, t = t.sibling; t.tag !== 5 && t.tag !== 6 && t.tag !== 18;) {
                if (t.tag === 27 && Kn(t.type) || t.flags & 2 || t.child === null || t.tag === 4) continue t;
                t.child.return = t, t = t.child
            }
            if (!(t.flags & 2)) return t.stateNode
        }
    }

    function lo(t, e, n) {
        var l = t.tag;
        if (l === 5 || l === 6) t = t.stateNode, e ? (n.nodeType === 9 ? n.body : n.nodeName === "HTML" ? n.ownerDocument.body : n).insertBefore(t, e) : (e = n.nodeType === 9 ? n.body : n.nodeName === "HTML" ? n.ownerDocument.body : n, e.appendChild(t), n = n._reactRootContainer, n != null || e.onclick !== null || (e.onclick = ln));
        else if (l !== 4 && (l === 27 && Kn(t.type) && (n = t.stateNode, e = null), t = t.child, t !== null))
            for (lo(t, e, n), t = t.sibling; t !== null;) lo(t, e, n), t = t.sibling
    }

    function Lu(t, e, n) {
        var l = t.tag;
        if (l === 5 || l === 6) t = t.stateNode, e ? n.insertBefore(t, e) : n.appendChild(t);
        else if (l !== 4 && (l === 27 && Kn(t.type) && (n = t.stateNode), t = t.child, t !== null))
            for (Lu(t, e, n), t = t.sibling; t !== null;) Lu(t, e, n), t = t.sibling
    }

    function ih(t) {
        var e = t.stateNode,
            n = t.memoizedProps;
        try {
            for (var l = t.type, s = e.attributes; s.length;) e.removeAttributeNode(s[0]);
            re(e, l, n), e[le] = t, e[he] = n
        } catch (o) {
            Mt(t, t.return, o)
        }
    }
    var yn = !1,
        Pt = !1,
        io = !1,
        uh = typeof WeakSet == "function" ? WeakSet : Set,
        ee = null;

    function sg(t, e) {
        if (t = t.containerInfo, Mo = ts, t = gf(t), Ws(t)) {
            if ("selectionStart" in t) var n = {
                start: t.selectionStart,
                end: t.selectionEnd
            };
            else t: {
                n = (n = t.ownerDocument) && n.defaultView || window;
                var l = n.getSelection && n.getSelection();
                if (l && l.rangeCount !== 0) {
                    n = l.anchorNode;
                    var s = l.anchorOffset,
                        o = l.focusNode;
                    l = l.focusOffset;
                    try {
                        n.nodeType, o.nodeType
                    } catch {
                        n = null;
                        break t
                    }
                    var d = 0,
                        v = -1,
                        R = -1,
                        L = 0,
                        j = 0,
                        G = t,
                        U = null;
                    e: for (;;) {
                        for (var N; G !== n || s !== 0 && G.nodeType !== 3 || (v = d + s), G !== o || l !== 0 && G.nodeType !== 3 || (R = d + l), G.nodeType === 3 && (d += G.nodeValue.length), (N = G.firstChild) !== null;) U = G, G = N;
                        for (;;) {
                            if (G === t) break e;
                            if (U === n && ++L === s && (v = d), U === o && ++j === l && (R = d), (N = G.nextSibling) !== null) break;
                            G = U, U = G.parentNode
                        }
                        G = N
                    }
                    n = v === -1 || R === -1 ? null : {
                        start: v,
                        end: R
                    }
                } else n = null
            }
            n = n || {
                start: 0,
                end: 0
            }
        } else n = null;
        for (Oo = {
                focusedElem: t,
                selectionRange: n
            }, ts = !1, ee = e; ee !== null;)
            if (e = ee, t = e.child, (e.subtreeFlags & 1028) !== 0 && t !== null) t.return = e, ee = t;
            else
                for (; ee !== null;) {
                    switch (e = ee, o = e.alternate, t = e.flags, e.tag) {
                        case 0:
                            if ((t & 4) !== 0 && (t = e.updateQueue, t = t !== null ? t.events : null, t !== null))
                                for (n = 0; n < t.length; n++) s = t[n], s.ref.impl = s.nextImpl;
                            break;
                        case 11:
                        case 15:
                            break;
                        case 1:
                            if ((t & 1024) !== 0 && o !== null) {
                                t = void 0, n = e, s = o.memoizedProps, o = o.memoizedState, l = n.stateNode;
                                try {
                                    var $ = Ta(n.type, s);
                                    t = l.getSnapshotBeforeUpdate($, o), l.__reactInternalSnapshotBeforeUpdate = t
                                } catch (st) {
                                    Mt(n, n.return, st)
                                }
                            }
                            break;
                        case 3:
                            if ((t & 1024) !== 0) {
                                if (t = e.stateNode.containerInfo, n = t.nodeType, n === 9) wo(t);
                                else if (n === 1) switch (t.nodeName) {
                                    case "HEAD":
                                    case "HTML":
                                    case "BODY":
                                        wo(t);
                                        break;
                                    default:
                                        t.textContent = ""
                                }
                            }
                            break;
                        case 5:
                        case 26:
                        case 27:
                        case 6:
                        case 4:
                        case 17:
                            break;
                        default:
                            if ((t & 1024) !== 0) throw Error(r(163))
                    }
                    if (t = e.sibling, t !== null) {
                        t.return = e.return, ee = t;
                        break
                    }
                    ee = e.return
                }
    }

    function sh(t, e, n) {
        var l = n.flags;
        switch (n.tag) {
            case 0:
            case 11:
            case 15:
                vn(t, n), l & 4 && ri(5, n);
                break;
            case 1:
                if (vn(t, n), l & 4)
                    if (t = n.stateNode, e === null) try {
                        t.componentDidMount()
                    } catch (d) {
                        Mt(n, n.return, d)
                    } else {
                        var s = Ta(n.type, e.memoizedProps);
                        e = e.memoizedState;
                        try {
                            t.componentDidUpdate(s, e, t.__reactInternalSnapshotBeforeUpdate)
                        } catch (d) {
                            Mt(n, n.return, d)
                        }
                    }
                l & 64 && eh(n), l & 512 && oi(n, n.return);
                break;
            case 3:
                if (vn(t, n), l & 64 && (t = n.updateQueue, t !== null)) {
                    if (e = null, n.child !== null) switch (n.child.tag) {
                        case 27:
                        case 5:
                            e = n.child.stateNode;
                            break;
                        case 1:
                            e = n.child.stateNode
                    }
                    try {
                        Zf(t, e)
                    } catch (d) {
                        Mt(n, n.return, d)
                    }
                }
                break;
            case 27:
                e === null && l & 4 && ih(n);
            case 26:
            case 5:
                vn(t, n), e === null && l & 4 && ah(n), l & 512 && oi(n, n.return);
                break;
            case 12:
                vn(t, n);
                break;
            case 31:
                vn(t, n), l & 4 && ch(t, n);
                break;
            case 13:
                vn(t, n), l & 4 && fh(t, n), l & 64 && (t = n.memoizedState, t !== null && (t = t.dehydrated, t !== null && (n = pg.bind(null, n), Bg(t, n))));
                break;
            case 22:
                if (l = n.memoizedState !== null || yn, !l) {
                    e = e !== null && e.memoizedState !== null || Pt, s = yn;
                    var o = Pt;
                    yn = l, (Pt = e) && !o ? gn(t, n, (n.subtreeFlags & 8772) !== 0) : vn(t, n), yn = s, Pt = o
                }
                break;
            case 30:
                break;
            default:
                vn(t, n)
        }
    }

    function rh(t) {
        var e = t.alternate;
        e !== null && (t.alternate = null, rh(e)), t.child = null, t.deletions = null, t.sibling = null, t.tag === 5 && (e = t.stateNode, e !== null && Ns(e)), t.stateNode = null, t.return = null, t.dependencies = null, t.memoizedProps = null, t.memoizedState = null, t.pendingProps = null, t.stateNode = null, t.updateQueue = null
    }
    var Ht = null,
        ye = !1;

    function pn(t, e, n) {
        for (n = n.child; n !== null;) oh(t, e, n), n = n.sibling
    }

    function oh(t, e, n) {
        if (Re && typeof Re.onCommitFiberUnmount == "function") try {
            Re.onCommitFiberUnmount(Ll, n)
        } catch {}
        switch (n.tag) {
            case 26:
                Pt || Fe(n, e), pn(t, e, n), n.memoizedState ? n.memoizedState.count-- : n.stateNode && (n = n.stateNode, n.parentNode.removeChild(n));
                break;
            case 27:
                Pt || Fe(n, e);
                var l = Ht,
                    s = ye;
                Kn(n.type) && (Ht = n.stateNode, ye = !1), pn(t, e, n), gi(n.stateNode), Ht = l, ye = s;
                break;
            case 5:
                Pt || Fe(n, e);
            case 6:
                if (l = Ht, s = ye, Ht = null, pn(t, e, n), Ht = l, ye = s, Ht !== null)
                    if (ye) try {
                        (Ht.nodeType === 9 ? Ht.body : Ht.nodeName === "HTML" ? Ht.ownerDocument.body : Ht).removeChild(n.stateNode)
                    } catch (o) {
                        Mt(n, e, o)
                    } else try {
                        Ht.removeChild(n.stateNode)
                    } catch (o) {
                        Mt(n, e, o)
                    }
                break;
            case 18:
                Ht !== null && (ye ? (t = Ht, em(t.nodeType === 9 ? t.body : t.nodeName === "HTML" ? t.ownerDocument.body : t, n.stateNode), El(t)) : em(Ht, n.stateNode));
                break;
            case 4:
                l = Ht, s = ye, Ht = n.stateNode.containerInfo, ye = !0, pn(t, e, n), Ht = l, ye = s;
                break;
            case 0:
            case 11:
            case 14:
            case 15:
                qn(2, n, e), Pt || qn(4, n, e), pn(t, e, n);
                break;
            case 1:
                Pt || (Fe(n, e), l = n.stateNode, typeof l.componentWillUnmount == "function" && nh(n, e, l)), pn(t, e, n);
                break;
            case 21:
                pn(t, e, n);
                break;
            case 22:
                Pt = (l = Pt) || n.memoizedState !== null, pn(t, e, n), Pt = l;
                break;
            default:
                pn(t, e, n)
        }
    }

    function ch(t, e) {
        if (e.memoizedState === null && (t = e.alternate, t !== null && (t = t.memoizedState, t !== null))) {
            t = t.dehydrated;
            try {
                El(t)
            } catch (n) {
                Mt(e, e.return, n)
            }
        }
    }

    function fh(t, e) {
        if (e.memoizedState === null && (t = e.alternate, t !== null && (t = t.memoizedState, t !== null && (t = t.dehydrated, t !== null)))) try {
            El(t)
        } catch (n) {
            Mt(e, e.return, n)
        }
    }

    function rg(t) {
        switch (t.tag) {
            case 31:
            case 13:
            case 19:
                var e = t.stateNode;
                return e === null && (e = t.stateNode = new uh), e;
            case 22:
                return t = t.stateNode, e = t._retryCache, e === null && (e = t._retryCache = new uh), e;
            default:
                throw Error(r(435, t.tag))
        }
    }

    function Uu(t, e) {
        var n = rg(t);
        e.forEach(function(l) {
            if (!n.has(l)) {
                n.add(l);
                var s = vg.bind(null, t, l);
                l.then(s, s)
            }
        })
    }

    function pe(t, e) {
        var n = e.deletions;
        if (n !== null)
            for (var l = 0; l < n.length; l++) {
                var s = n[l],
                    o = t,
                    d = e,
                    v = d;
                t: for (; v !== null;) {
                    switch (v.tag) {
                        case 27:
                            if (Kn(v.type)) {
                                Ht = v.stateNode, ye = !1;
                                break t
                            }
                            break;
                        case 5:
                            Ht = v.stateNode, ye = !1;
                            break t;
                        case 3:
                        case 4:
                            Ht = v.stateNode.containerInfo, ye = !0;
                            break t
                    }
                    v = v.return
                }
                if (Ht === null) throw Error(r(160));
                oh(o, d, s), Ht = null, ye = !1, o = s.alternate, o !== null && (o.return = null), s.return = null
            }
        if (e.subtreeFlags & 13886)
            for (e = e.child; e !== null;) dh(e, t), e = e.sibling
    }
    var Qe = null;

    function dh(t, e) {
        var n = t.alternate,
            l = t.flags;
        switch (t.tag) {
            case 0:
            case 11:
            case 14:
            case 15:
                pe(e, t), ve(t), l & 4 && (qn(3, t, t.return), ri(3, t), qn(5, t, t.return));
                break;
            case 1:
                pe(e, t), ve(t), l & 512 && (Pt || n === null || Fe(n, n.return)), l & 64 && yn && (t = t.updateQueue, t !== null && (l = t.callbacks, l !== null && (n = t.shared.hiddenCallbacks, t.shared.hiddenCallbacks = n === null ? l : n.concat(l))));
                break;
            case 26:
                var s = Qe;
                if (pe(e, t), ve(t), l & 512 && (Pt || n === null || Fe(n, n.return)), l & 4) {
                    var o = n !== null ? n.memoizedState : null;
                    if (l = t.memoizedState, n === null)
                        if (l === null)
                            if (t.stateNode === null) {
                                t: {
                                    l = t.type,
                                    n = t.memoizedProps,
                                    s = s.ownerDocument || s;e: switch (l) {
                                        case "title":
                                            o = s.getElementsByTagName("title")[0], (!o || o[Bl] || o[le] || o.namespaceURI === "http://www.w3.org/2000/svg" || o.hasAttribute("itemprop")) && (o = s.createElement(l), s.head.insertBefore(o, s.querySelector("head > title"))), re(o, l, n), o[le] = t, te(o), l = o;
                                            break t;
                                        case "link":
                                            var d = dm("link", "href", s).get(l + (n.href || ""));
                                            if (d) {
                                                for (var v = 0; v < d.length; v++)
                                                    if (o = d[v], o.getAttribute("href") === (n.href == null || n.href === "" ? null : n.href) && o.getAttribute("rel") === (n.rel == null ? null : n.rel) && o.getAttribute("title") === (n.title == null ? null : n.title) && o.getAttribute("crossorigin") === (n.crossOrigin == null ? null : n.crossOrigin)) {
                                                        d.splice(v, 1);
                                                        break e
                                                    }
                                            }
                                            o = s.createElement(l), re(o, l, n), s.head.appendChild(o);
                                            break;
                                        case "meta":
                                            if (d = dm("meta", "content", s).get(l + (n.content || ""))) {
                                                for (v = 0; v < d.length; v++)
                                                    if (o = d[v], o.getAttribute("content") === (n.content == null ? null : "" + n.content) && o.getAttribute("name") === (n.name == null ? null : n.name) && o.getAttribute("property") === (n.property == null ? null : n.property) && o.getAttribute("http-equiv") === (n.httpEquiv == null ? null : n.httpEquiv) && o.getAttribute("charset") === (n.charSet == null ? null : n.charSet)) {
                                                        d.splice(v, 1);
                                                        break e
                                                    }
                                            }
                                            o = s.createElement(l), re(o, l, n), s.head.appendChild(o);
                                            break;
                                        default:
                                            throw Error(r(468, l))
                                    }
                                    o[le] = t,
                                    te(o),
                                    l = o
                                }
                                t.stateNode = l
                            }
                    else hm(s, t.type, t.stateNode);
                    else t.stateNode = fm(s, l, t.memoizedProps);
                    else o !== l ? (o === null ? n.stateNode !== null && (n = n.stateNode, n.parentNode.removeChild(n)) : o.count--, l === null ? hm(s, t.type, t.stateNode) : fm(s, l, t.memoizedProps)) : l === null && t.stateNode !== null && no(t, t.memoizedProps, n.memoizedProps)
                }
                break;
            case 27:
                pe(e, t), ve(t), l & 512 && (Pt || n === null || Fe(n, n.return)), n !== null && l & 4 && no(t, t.memoizedProps, n.memoizedProps);
                break;
            case 5:
                if (pe(e, t), ve(t), l & 512 && (Pt || n === null || Fe(n, n.return)), t.flags & 32) {
                    s = t.stateNode;
                    try {
                        Za(s, "")
                    } catch ($) {
                        Mt(t, t.return, $)
                    }
                }
                l & 4 && t.stateNode != null && (s = t.memoizedProps, no(t, s, n !== null ? n.memoizedProps : s)), l & 1024 && (io = !0);
                break;
            case 6:
                if (pe(e, t), ve(t), l & 4) {
                    if (t.stateNode === null) throw Error(r(162));
                    l = t.memoizedProps, n = t.stateNode;
                    try {
                        n.nodeValue = l
                    } catch ($) {
                        Mt(t, t.return, $)
                    }
                }
                break;
            case 3:
                if (Fu = null, s = Qe, Qe = ku(e.containerInfo), pe(e, t), Qe = s, ve(t), l & 4 && n !== null && n.memoizedState.isDehydrated) try {
                    El(e.containerInfo)
                } catch ($) {
                    Mt(t, t.return, $)
                }
                io && (io = !1, hh(t));
                break;
            case 4:
                l = Qe, Qe = ku(t.stateNode.containerInfo), pe(e, t), ve(t), Qe = l;
                break;
            case 12:
                pe(e, t), ve(t);
                break;
            case 31:
                pe(e, t), ve(t), l & 4 && (l = t.updateQueue, l !== null && (t.updateQueue = null, Uu(t, l)));
                break;
            case 13:
                pe(e, t), ve(t), t.child.flags & 8192 && t.memoizedState !== null != (n !== null && n.memoizedState !== null) && (Bu = oe()), l & 4 && (l = t.updateQueue, l !== null && (t.updateQueue = null, Uu(t, l)));
                break;
            case 22:
                s = t.memoizedState !== null;
                var R = n !== null && n.memoizedState !== null,
                    L = yn,
                    j = Pt;
                if (yn = L || s, Pt = j || R, pe(e, t), Pt = j, yn = L, ve(t), l & 8192) t: for (e = t.stateNode, e._visibility = s ? e._visibility & -2 : e._visibility | 1, s && (n === null || R || yn || Pt || Aa(t)), n = null, e = t;;) {
                    if (e.tag === 5 || e.tag === 26) {
                        if (n === null) {
                            R = n = e;
                            try {
                                if (o = R.stateNode, s) d = o.style, typeof d.setProperty == "function" ? d.setProperty("display", "none", "important") : d.display = "none";
                                else {
                                    v = R.stateNode;
                                    var G = R.memoizedProps.style,
                                        U = G != null && G.hasOwnProperty("display") ? G.display : null;
                                    v.style.display = U == null || typeof U == "boolean" ? "" : ("" + U).trim()
                                }
                            } catch ($) {
                                Mt(R, R.return, $)
                            }
                        }
                    } else if (e.tag === 6) {
                        if (n === null) {
                            R = e;
                            try {
                                R.stateNode.nodeValue = s ? "" : R.memoizedProps
                            } catch ($) {
                                Mt(R, R.return, $)
                            }
                        }
                    } else if (e.tag === 18) {
                        if (n === null) {
                            R = e;
                            try {
                                var N = R.stateNode;
                                s ? nm(N, !0) : nm(R.stateNode, !1)
                            } catch ($) {
                                Mt(R, R.return, $)
                            }
                        }
                    } else if ((e.tag !== 22 && e.tag !== 23 || e.memoizedState === null || e === t) && e.child !== null) {
                        e.child.return = e, e = e.child;
                        continue
                    }
                    if (e === t) break t;
                    for (; e.sibling === null;) {
                        if (e.return === null || e.return === t) break t;
                        n === e && (n = null), e = e.return
                    }
                    n === e && (n = null), e.sibling.return = e.return, e = e.sibling
                }
                l & 4 && (l = t.updateQueue, l !== null && (n = l.retryQueue, n !== null && (l.retryQueue = null, Uu(t, n))));
                break;
            case 19:
                pe(e, t), ve(t), l & 4 && (l = t.updateQueue, l !== null && (t.updateQueue = null, Uu(t, l)));
                break;
            case 30:
                break;
            case 21:
                break;
            default:
                pe(e, t), ve(t)
        }
    }

    function ve(t) {
        var e = t.flags;
        if (e & 2) {
            try {
                for (var n, l = t.return; l !== null;) {
                    if (lh(l)) {
                        n = l;
                        break
                    }
                    l = l.return
                }
                if (n == null) throw Error(r(160));
                switch (n.tag) {
                    case 27:
                        var s = n.stateNode,
                            o = ao(t);
                        Lu(t, o, s);
                        break;
                    case 5:
                        var d = n.stateNode;
                        n.flags & 32 && (Za(d, ""), n.flags &= -33);
                        var v = ao(t);
                        Lu(t, v, d);
                        break;
                    case 3:
                    case 4:
                        var R = n.stateNode.containerInfo,
                            L = ao(t);
                        lo(t, L, R);
                        break;
                    default:
                        throw Error(r(161))
                }
            } catch (j) {
                Mt(t, t.return, j)
            }
            t.flags &= -3
        }
        e & 4096 && (t.flags &= -4097)
    }

    function hh(t) {
        if (t.subtreeFlags & 1024)
            for (t = t.child; t !== null;) {
                var e = t;
                hh(e), e.tag === 5 && e.flags & 1024 && e.stateNode.reset(), t = t.sibling
            }
    }

    function vn(t, e) {
        if (e.subtreeFlags & 8772)
            for (e = e.child; e !== null;) sh(t, e.alternate, e), e = e.sibling
    }

    function Aa(t) {
        for (t = t.child; t !== null;) {
            var e = t;
            switch (e.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                    qn(4, e, e.return), Aa(e);
                    break;
                case 1:
                    Fe(e, e.return);
                    var n = e.stateNode;
                    typeof n.componentWillUnmount == "function" && nh(e, e.return, n), Aa(e);
                    break;
                case 27:
                    gi(e.stateNode);
                case 26:
                case 5:
                    Fe(e, e.return), Aa(e);
                    break;
                case 22:
                    e.memoizedState === null && Aa(e);
                    break;
                case 30:
                    Aa(e);
                    break;
                default:
                    Aa(e)
            }
            t = t.sibling
        }
    }

    function gn(t, e, n) {
        for (n = n && (e.subtreeFlags & 8772) !== 0, e = e.child; e !== null;) {
            var l = e.alternate,
                s = t,
                o = e,
                d = o.flags;
            switch (o.tag) {
                case 0:
                case 11:
                case 15:
                    gn(s, o, n), ri(4, o);
                    break;
                case 1:
                    if (gn(s, o, n), l = o, s = l.stateNode, typeof s.componentDidMount == "function") try {
                        s.componentDidMount()
                    } catch (L) {
                        Mt(l, l.return, L)
                    }
                    if (l = o, s = l.updateQueue, s !== null) {
                        var v = l.stateNode;
                        try {
                            var R = s.shared.hiddenCallbacks;
                            if (R !== null)
                                for (s.shared.hiddenCallbacks = null, s = 0; s < R.length; s++) Qf(R[s], v)
                        } catch (L) {
                            Mt(l, l.return, L)
                        }
                    }
                    n && d & 64 && eh(o), oi(o, o.return);
                    break;
                case 27:
                    ih(o);
                case 26:
                case 5:
                    gn(s, o, n), n && l === null && d & 4 && ah(o), oi(o, o.return);
                    break;
                case 12:
                    gn(s, o, n);
                    break;
                case 31:
                    gn(s, o, n), n && d & 4 && ch(s, o);
                    break;
                case 13:
                    gn(s, o, n), n && d & 4 && fh(s, o);
                    break;
                case 22:
                    o.memoizedState === null && gn(s, o, n), oi(o, o.return);
                    break;
                case 30:
                    break;
                default:
                    gn(s, o, n)
            }
            e = e.sibling
        }
    }

    function uo(t, e) {
        var n = null;
        t !== null && t.memoizedState !== null && t.memoizedState.cachePool !== null && (n = t.memoizedState.cachePool.pool), t = null, e.memoizedState !== null && e.memoizedState.cachePool !== null && (t = e.memoizedState.cachePool.pool), t !== n && (t != null && t.refCount++, n != null && Pl(n))
    }

    function so(t, e) {
        t = null, e.alternate !== null && (t = e.alternate.memoizedState.cache), e = e.memoizedState.cache, e !== t && (e.refCount++, t != null && Pl(t))
    }

    function Ze(t, e, n, l) {
        if (e.subtreeFlags & 10256)
            for (e = e.child; e !== null;) mh(t, e, n, l), e = e.sibling
    }

    function mh(t, e, n, l) {
        var s = e.flags;
        switch (e.tag) {
            case 0:
            case 11:
            case 15:
                Ze(t, e, n, l), s & 2048 && ri(9, e);
                break;
            case 1:
                Ze(t, e, n, l);
                break;
            case 3:
                Ze(t, e, n, l), s & 2048 && (t = null, e.alternate !== null && (t = e.alternate.memoizedState.cache), e = e.memoizedState.cache, e !== t && (e.refCount++, t != null && Pl(t)));
                break;
            case 12:
                if (s & 2048) {
                    Ze(t, e, n, l), t = e.stateNode;
                    try {
                        var o = e.memoizedProps,
                            d = o.id,
                            v = o.onPostCommit;
                        typeof v == "function" && v(d, e.alternate === null ? "mount" : "update", t.passiveEffectDuration, -0)
                    } catch (R) {
                        Mt(e, e.return, R)
                    }
                } else Ze(t, e, n, l);
                break;
            case 31:
                Ze(t, e, n, l);
                break;
            case 13:
                Ze(t, e, n, l);
                break;
            case 23:
                break;
            case 22:
                o = e.stateNode, d = e.alternate, e.memoizedState !== null ? o._visibility & 2 ? Ze(t, e, n, l) : ci(t, e) : o._visibility & 2 ? Ze(t, e, n, l) : (o._visibility |= 2, fl(t, e, n, l, (e.subtreeFlags & 10256) !== 0 || !1)), s & 2048 && uo(d, e);
                break;
            case 24:
                Ze(t, e, n, l), s & 2048 && so(e.alternate, e);
                break;
            default:
                Ze(t, e, n, l)
        }
    }

    function fl(t, e, n, l, s) {
        for (s = s && ((e.subtreeFlags & 10256) !== 0 || !1), e = e.child; e !== null;) {
            var o = t,
                d = e,
                v = n,
                R = l,
                L = d.flags;
            switch (d.tag) {
                case 0:
                case 11:
                case 15:
                    fl(o, d, v, R, s), ri(8, d);
                    break;
                case 23:
                    break;
                case 22:
                    var j = d.stateNode;
                    d.memoizedState !== null ? j._visibility & 2 ? fl(o, d, v, R, s) : ci(o, d) : (j._visibility |= 2, fl(o, d, v, R, s)), s && L & 2048 && uo(d.alternate, d);
                    break;
                case 24:
                    fl(o, d, v, R, s), s && L & 2048 && so(d.alternate, d);
                    break;
                default:
                    fl(o, d, v, R, s)
            }
            e = e.sibling
        }
    }

    function ci(t, e) {
        if (e.subtreeFlags & 10256)
            for (e = e.child; e !== null;) {
                var n = t,
                    l = e,
                    s = l.flags;
                switch (l.tag) {
                    case 22:
                        ci(n, l), s & 2048 && uo(l.alternate, l);
                        break;
                    case 24:
                        ci(n, l), s & 2048 && so(l.alternate, l);
                        break;
                    default:
                        ci(n, l)
                }
                e = e.sibling
            }
    }
    var fi = 8192;

    function dl(t, e, n) {
        if (t.subtreeFlags & fi)
            for (t = t.child; t !== null;) yh(t, e, n), t = t.sibling
    }

    function yh(t, e, n) {
        switch (t.tag) {
            case 26:
                dl(t, e, n), t.flags & fi && t.memoizedState !== null && kg(n, Qe, t.memoizedState, t.memoizedProps);
                break;
            case 5:
                dl(t, e, n);
                break;
            case 3:
            case 4:
                var l = Qe;
                Qe = ku(t.stateNode.containerInfo), dl(t, e, n), Qe = l;
                break;
            case 22:
                t.memoizedState === null && (l = t.alternate, l !== null && l.memoizedState !== null ? (l = fi, fi = 16777216, dl(t, e, n), fi = l) : dl(t, e, n));
                break;
            default:
                dl(t, e, n)
        }
    }

    function ph(t) {
        var e = t.alternate;
        if (e !== null && (t = e.child, t !== null)) {
            e.child = null;
            do e = t.sibling, t.sibling = null, t = e; while (t !== null)
        }
    }

    function di(t) {
        var e = t.deletions;
        if ((t.flags & 16) !== 0) {
            if (e !== null)
                for (var n = 0; n < e.length; n++) {
                    var l = e[n];
                    ee = l, gh(l, t)
                }
            ph(t)
        }
        if (t.subtreeFlags & 10256)
            for (t = t.child; t !== null;) vh(t), t = t.sibling
    }

    function vh(t) {
        switch (t.tag) {
            case 0:
            case 11:
            case 15:
                di(t), t.flags & 2048 && qn(9, t, t.return);
                break;
            case 3:
                di(t);
                break;
            case 12:
                di(t);
                break;
            case 22:
                var e = t.stateNode;
                t.memoizedState !== null && e._visibility & 2 && (t.return === null || t.return.tag !== 13) ? (e._visibility &= -3, Nu(t)) : di(t);
                break;
            default:
                di(t)
        }
    }

    function Nu(t) {
        var e = t.deletions;
        if ((t.flags & 16) !== 0) {
            if (e !== null)
                for (var n = 0; n < e.length; n++) {
                    var l = e[n];
                    ee = l, gh(l, t)
                }
            ph(t)
        }
        for (t = t.child; t !== null;) {
            switch (e = t, e.tag) {
                case 0:
                case 11:
                case 15:
                    qn(8, e, e.return), Nu(e);
                    break;
                case 22:
                    n = e.stateNode, n._visibility & 2 && (n._visibility &= -3, Nu(e));
                    break;
                default:
                    Nu(e)
            }
            t = t.sibling
        }
    }

    function gh(t, e) {
        for (; ee !== null;) {
            var n = ee;
            switch (n.tag) {
                case 0:
                case 11:
                case 15:
                    qn(8, n, e);
                    break;
                case 23:
                case 22:
                    if (n.memoizedState !== null && n.memoizedState.cachePool !== null) {
                        var l = n.memoizedState.cachePool.pool;
                        l != null && l.refCount++
                    }
                    break;
                case 24:
                    Pl(n.memoizedState.cache)
            }
            if (l = n.child, l !== null) l.return = n, ee = l;
            else t: for (n = t; ee !== null;) {
                l = ee;
                var s = l.sibling,
                    o = l.return;
                if (rh(l), l === n) {
                    ee = null;
                    break t
                }
                if (s !== null) {
                    s.return = o, ee = s;
                    break t
                }
                ee = o
            }
        }
    }
    var og = {
            getCacheForType: function(t) {
                var e = ue(Kt),
                    n = e.data.get(t);
                return n === void 0 && (n = t(), e.data.set(t, n)), n
            },
            cacheSignal: function() {
                return ue(Kt).controller.signal
            }
        },
        cg = typeof WeakMap == "function" ? WeakMap : Map,
        Tt = 0,
        Lt = null,
        ht = null,
        yt = 0,
        xt = 0,
        ze = null,
        Yn = !1,
        hl = !1,
        ro = !1,
        Sn = 0,
        Xt = 0,
        Gn = 0,
        xa = 0,
        oo = 0,
        Ce = 0,
        ml = 0,
        hi = null,
        ge = null,
        co = !1,
        Bu = 0,
        Sh = 0,
        ju = 1 / 0,
        Hu = null,
        Xn = null,
        It = 0,
        Vn = null,
        yl = null,
        bn = 0,
        fo = 0,
        ho = null,
        bh = null,
        mi = 0,
        mo = null;

    function we() {
        return (Tt & 2) !== 0 && yt !== 0 ? yt & -yt : B.T !== null ? bo() : Nc()
    }

    function _h() {
        if (Ce === 0)
            if ((yt & 536870912) === 0 || gt) {
                var t = Ki;
                Ki <<= 1, (Ki & 3932160) === 0 && (Ki = 262144), Ce = t
            } else Ce = 536870912;
        return t = Me.current, t !== null && (t.flags |= 32), Ce
    }

    function Se(t, e, n) {
        (t === Lt && (xt === 2 || xt === 9) || t.cancelPendingCommit !== null) && (pl(t, 0), Qn(t, yt, Ce, !1)), Nl(t, n), ((Tt & 2) === 0 || t !== Lt) && (t === Lt && ((Tt & 2) === 0 && (xa |= n), Xt === 4 && Qn(t, yt, Ce, !1)), Ie(t))
    }

    function Eh(t, e, n) {
        if ((Tt & 6) !== 0) throw Error(r(327));
        var l = !n && (e & 127) === 0 && (e & t.expiredLanes) === 0 || Ul(t, e),
            s = l ? hg(t, e) : po(t, e, !0),
            o = l;
        do {
            if (s === 0) {
                hl && !l && Qn(t, e, 0, !1);
                break
            } else {
                if (n = t.current.alternate, o && !fg(n)) {
                    s = po(t, e, !1), o = !1;
                    continue
                }
                if (s === 2) {
                    if (o = e, t.errorRecoveryDisabledLanes & o) var d = 0;
                    else d = t.pendingLanes & -536870913, d = d !== 0 ? d : d & 536870912 ? 536870912 : 0;
                    if (d !== 0) {
                        e = d;
                        t: {
                            var v = t;s = hi;
                            var R = v.current.memoizedState.isDehydrated;
                            if (R && (pl(v, d).flags |= 256), d = po(v, d, !1), d !== 2) {
                                if (ro && !R) {
                                    v.errorRecoveryDisabledLanes |= o, xa |= o, s = 4;
                                    break t
                                }
                                o = ge, ge = s, o !== null && (ge === null ? ge = o : ge.push.apply(ge, o))
                            }
                            s = d
                        }
                        if (o = !1, s !== 2) continue
                    }
                }
                if (s === 1) {
                    pl(t, 0), Qn(t, e, 0, !0);
                    break
                }
                t: {
                    switch (l = t, o = s, o) {
                        case 0:
                        case 1:
                            throw Error(r(345));
                        case 4:
                            if ((e & 4194048) !== e) break;
                        case 6:
                            Qn(l, e, Ce, !Yn);
                            break t;
                        case 2:
                            ge = null;
                            break;
                        case 3:
                        case 5:
                            break;
                        default:
                            throw Error(r(329))
                    }
                    if ((e & 62914560) === e && (s = Bu + 300 - oe(), 10 < s)) {
                        if (Qn(l, e, Ce, !Yn), ki(l, 0, !0) !== 0) break t;
                        bn = e, l.timeoutHandle = $h(Rh.bind(null, l, n, ge, Hu, co, e, Ce, xa, ml, Yn, o, "Throttled", -0, 0), s);
                        break t
                    }
                    Rh(l, n, ge, Hu, co, e, Ce, xa, ml, Yn, o, null, -0, 0)
                }
            }
            break
        } while (!0);
        Ie(t)
    }

    function Rh(t, e, n, l, s, o, d, v, R, L, j, G, U, N) {
        if (t.timeoutHandle = -1, G = e.subtreeFlags, G & 8192 || (G & 16785408) === 16785408) {
            G = {
                stylesheets: null,
                count: 0,
                imgCount: 0,
                imgBytes: 0,
                suspenseyImages: [],
                waitingForImages: !0,
                waitingForViewTransition: !1,
                unsuspend: ln
            }, yh(e, o, G);
            var $ = (o & 62914560) === o ? Bu - oe() : (o & 4194048) === o ? Sh - oe() : 0;
            if ($ = Pg(G, $), $ !== null) {
                bn = o, t.cancelPendingCommit = $(wh.bind(null, t, e, o, n, l, s, d, v, R, j, G, null, U, N)), Qn(t, o, d, !L);
                return
            }
        }
        wh(t, e, o, n, l, s, d, v, R)
    }

    function fg(t) {
        for (var e = t;;) {
            var n = e.tag;
            if ((n === 0 || n === 11 || n === 15) && e.flags & 16384 && (n = e.updateQueue, n !== null && (n = n.stores, n !== null)))
                for (var l = 0; l < n.length; l++) {
                    var s = n[l],
                        o = s.getSnapshot;
                    s = s.value;
                    try {
                        if (!Ae(o(), s)) return !1
                    } catch {
                        return !1
                    }
                }
            if (n = e.child, e.subtreeFlags & 16384 && n !== null) n.return = e, e = n;
            else {
                if (e === t) break;
                for (; e.sibling === null;) {
                    if (e.return === null || e.return === t) return !0;
                    e = e.return
                }
                e.sibling.return = e.return, e = e.sibling
            }
        }
        return !0
    }

    function Qn(t, e, n, l) {
        e &= ~oo, e &= ~xa, t.suspendedLanes |= e, t.pingedLanes &= ~e, l && (t.warmLanes |= e), l = t.expirationTimes;
        for (var s = e; 0 < s;) {
            var o = 31 - Te(s),
                d = 1 << o;
            l[o] = -1, s &= ~d
        }
        n !== 0 && Dc(t, n, e)
    }

    function qu() {
        return (Tt & 6) === 0 ? (yi(0), !1) : !0
    }

    function yo() {
        if (ht !== null) {
            if (xt === 0) var t = ht.return;
            else t = ht, on = va = null, Cr(t), ul = null, Il = 0, t = ht;
            for (; t !== null;) th(t.alternate, t), t = t.return;
            ht = null
        }
    }

    function pl(t, e) {
        var n = t.timeoutHandle;
        n !== -1 && (t.timeoutHandle = -1, wg(n)), n = t.cancelPendingCommit, n !== null && (t.cancelPendingCommit = null, n()), bn = 0, yo(), Lt = t, ht = n = sn(t.current, null), yt = e, xt = 0, ze = null, Yn = !1, hl = Ul(t, e), ro = !1, ml = Ce = oo = xa = Gn = Xt = 0, ge = hi = null, co = !1, (e & 8) !== 0 && (e |= e & 32);
        var l = t.entangledLanes;
        if (l !== 0)
            for (t = t.entanglements, l &= e; 0 < l;) {
                var s = 31 - Te(l),
                    o = 1 << s;
                e |= t[s], l &= ~o
            }
        return Sn = e, uu(), n
    }

    function Th(t, e) {
        ot = null, B.H = ii, e === il || e === mu ? (e = Yf(), xt = 3) : e === gr ? (e = Yf(), xt = 4) : xt = e === Kr ? 8 : e !== null && typeof e == "object" && typeof e.then == "function" ? 6 : 1, ze = e, ht === null && (Xt = 1, Ou(t, Ne(e, t.current)))
    }

    function Ah() {
        var t = Me.current;
        return t === null ? !0 : (yt & 4194048) === yt ? qe === null : (yt & 62914560) === yt || (yt & 536870912) !== 0 ? t === qe : !1
    }

    function xh() {
        var t = B.H;
        return B.H = ii, t === null ? ii : t
    }

    function Mh() {
        var t = B.A;
        return B.A = og, t
    }

    function Yu() {
        Xt = 4, Yn || (yt & 4194048) !== yt && Me.current !== null || (hl = !0), (Gn & 134217727) === 0 && (xa & 134217727) === 0 || Lt === null || Qn(Lt, yt, Ce, !1)
    }

    function po(t, e, n) {
        var l = Tt;
        Tt |= 2;
        var s = xh(),
            o = Mh();
        (Lt !== t || yt !== e) && (Hu = null, pl(t, e)), e = !1;
        var d = Xt;
        t: do try {
                if (xt !== 0 && ht !== null) {
                    var v = ht,
                        R = ze;
                    switch (xt) {
                        case 8:
                            yo(), d = 6;
                            break t;
                        case 3:
                        case 2:
                        case 9:
                        case 6:
                            Me.current === null && (e = !0);
                            var L = xt;
                            if (xt = 0, ze = null, vl(t, v, R, L), n && hl) {
                                d = 0;
                                break t
                            }
                            break;
                        default:
                            L = xt, xt = 0, ze = null, vl(t, v, R, L)
                    }
                }
                dg(), d = Xt;
                break
            } catch (j) {
                Th(t, j)
            }
            while (!0);
            return e && t.shellSuspendCounter++, on = va = null, Tt = l, B.H = s, B.A = o, ht === null && (Lt = null, yt = 0, uu()), d
    }

    function dg() {
        for (; ht !== null;) Oh(ht)
    }

    function hg(t, e) {
        var n = Tt;
        Tt |= 2;
        var l = xh(),
            s = Mh();
        Lt !== t || yt !== e ? (Hu = null, ju = oe() + 500, pl(t, e)) : hl = Ul(t, e);
        t: do try {
                if (xt !== 0 && ht !== null) {
                    e = ht;
                    var o = ze;
                    e: switch (xt) {
                        case 1:
                            xt = 0, ze = null, vl(t, e, o, 1);
                            break;
                        case 2:
                        case 9:
                            if (Hf(o)) {
                                xt = 0, ze = null, zh(e);
                                break
                            }
                            e = function() {
                                xt !== 2 && xt !== 9 || Lt !== t || (xt = 7), Ie(t)
                            }, o.then(e, e);
                            break t;
                        case 3:
                            xt = 7;
                            break t;
                        case 4:
                            xt = 5;
                            break t;
                        case 7:
                            Hf(o) ? (xt = 0, ze = null, zh(e)) : (xt = 0, ze = null, vl(t, e, o, 7));
                            break;
                        case 5:
                            var d = null;
                            switch (ht.tag) {
                                case 26:
                                    d = ht.memoizedState;
                                case 5:
                                case 27:
                                    var v = ht;
                                    if (d ? mm(d) : v.stateNode.complete) {
                                        xt = 0, ze = null;
                                        var R = v.sibling;
                                        if (R !== null) ht = R;
                                        else {
                                            var L = v.return;
                                            L !== null ? (ht = L, Gu(L)) : ht = null
                                        }
                                        break e
                                    }
                            }
                            xt = 0, ze = null, vl(t, e, o, 5);
                            break;
                        case 6:
                            xt = 0, ze = null, vl(t, e, o, 6);
                            break;
                        case 8:
                            yo(), Xt = 6;
                            break t;
                        default:
                            throw Error(r(462))
                    }
                }
                mg();
                break
            } catch (j) {
                Th(t, j)
            }
            while (!0);
            return on = va = null, B.H = l, B.A = s, Tt = n, ht !== null ? 0 : (Lt = null, yt = 0, uu(), Xt)
    }

    function mg() {
        for (; ht !== null && !Qi();) Oh(ht)
    }

    function Oh(t) {
        var e = Wd(t.alternate, t, Sn);
        t.memoizedProps = t.pendingProps, e === null ? Gu(t) : ht = e
    }

    function zh(t) {
        var e = t,
            n = e.alternate;
        switch (e.tag) {
            case 15:
            case 0:
                e = Kd(n, e, e.pendingProps, e.type, void 0, yt);
                break;
            case 11:
                e = Kd(n, e, e.pendingProps, e.type.render, e.ref, yt);
                break;
            case 5:
                Cr(e);
            default:
                th(n, e), e = ht = Mf(e, Sn), e = Wd(n, e, Sn)
        }
        t.memoizedProps = t.pendingProps, e === null ? Gu(t) : ht = e
    }

    function vl(t, e, n, l) {
        on = va = null, Cr(e), ul = null, Il = 0;
        var s = e.return;
        try {
            if (ng(t, s, e, n, yt)) {
                Xt = 1, Ou(t, Ne(n, t.current)), ht = null;
                return
            }
        } catch (o) {
            if (s !== null) throw ht = s, o;
            Xt = 1, Ou(t, Ne(n, t.current)), ht = null;
            return
        }
        e.flags & 32768 ? (gt || l === 1 ? t = !0 : hl || (yt & 536870912) !== 0 ? t = !1 : (Yn = t = !0, (l === 2 || l === 9 || l === 3 || l === 6) && (l = Me.current, l !== null && l.tag === 13 && (l.flags |= 16384))), Ch(e, t)) : Gu(e)
    }

    function Gu(t) {
        var e = t;
        do {
            if ((e.flags & 32768) !== 0) {
                Ch(e, Yn);
                return
            }
            t = e.return;
            var n = ig(e.alternate, e, Sn);
            if (n !== null) {
                ht = n;
                return
            }
            if (e = e.sibling, e !== null) {
                ht = e;
                return
            }
            ht = e = t
        } while (e !== null);
        Xt === 0 && (Xt = 5)
    }

    function Ch(t, e) {
        do {
            var n = ug(t.alternate, t);
            if (n !== null) {
                n.flags &= 32767, ht = n;
                return
            }
            if (n = t.return, n !== null && (n.flags |= 32768, n.subtreeFlags = 0, n.deletions = null), !e && (t = t.sibling, t !== null)) {
                ht = t;
                return
            }
            ht = t = n
        } while (t !== null);
        Xt = 6, ht = null
    }

    function wh(t, e, n, l, s, o, d, v, R) {
        t.cancelPendingCommit = null;
        do Xu(); while (It !== 0);
        if ((Tt & 6) !== 0) throw Error(r(327));
        if (e !== null) {
            if (e === t.current) throw Error(r(177));
            if (o = e.lanes | e.childLanes, o |= ar, Jp(t, n, o, d, v, R), t === Lt && (ht = Lt = null, yt = 0), yl = e, Vn = t, bn = n, fo = o, ho = s, bh = l, (e.subtreeFlags & 10256) !== 0 || (e.flags & 10256) !== 0 ? (t.callbackNode = null, t.callbackPriority = 0, gg(Ha, function() {
                    return Bh(), null
                })) : (t.callbackNode = null, t.callbackPriority = 0), l = (e.flags & 13878) !== 0, (e.subtreeFlags & 13878) !== 0 || l) {
                l = B.T, B.T = null, s = K.p, K.p = 2, d = Tt, Tt |= 4;
                try {
                    sg(t, e, n)
                } finally {
                    Tt = d, K.p = s, B.T = l
                }
            }
            It = 1, Dh(), Lh(), Uh()
        }
    }

    function Dh() {
        if (It === 1) {
            It = 0;
            var t = Vn,
                e = yl,
                n = (e.flags & 13878) !== 0;
            if ((e.subtreeFlags & 13878) !== 0 || n) {
                n = B.T, B.T = null;
                var l = K.p;
                K.p = 2;
                var s = Tt;
                Tt |= 4;
                try {
                    dh(e, t);
                    var o = Oo,
                        d = gf(t.containerInfo),
                        v = o.focusedElem,
                        R = o.selectionRange;
                    if (d !== v && v && v.ownerDocument && vf(v.ownerDocument.documentElement, v)) {
                        if (R !== null && Ws(v)) {
                            var L = R.start,
                                j = R.end;
                            if (j === void 0 && (j = L), "selectionStart" in v) v.selectionStart = L, v.selectionEnd = Math.min(j, v.value.length);
                            else {
                                var G = v.ownerDocument || document,
                                    U = G && G.defaultView || window;
                                if (U.getSelection) {
                                    var N = U.getSelection(),
                                        $ = v.textContent.length,
                                        st = Math.min(R.start, $),
                                        wt = R.end === void 0 ? st : Math.min(R.end, $);
                                    !N.extend && st > wt && (d = wt, wt = st, st = d);
                                    var C = pf(v, st),
                                        x = pf(v, wt);
                                    if (C && x && (N.rangeCount !== 1 || N.anchorNode !== C.node || N.anchorOffset !== C.offset || N.focusNode !== x.node || N.focusOffset !== x.offset)) {
                                        var D = G.createRange();
                                        D.setStart(C.node, C.offset), N.removeAllRanges(), st > wt ? (N.addRange(D), N.extend(x.node, x.offset)) : (D.setEnd(x.node, x.offset), N.addRange(D))
                                    }
                                }
                            }
                        }
                        for (G = [], N = v; N = N.parentNode;) N.nodeType === 1 && G.push({
                            element: N,
                            left: N.scrollLeft,
                            top: N.scrollTop
                        });
                        for (typeof v.focus == "function" && v.focus(), v = 0; v < G.length; v++) {
                            var q = G[v];
                            q.element.scrollLeft = q.left, q.element.scrollTop = q.top
                        }
                    }
                    ts = !!Mo, Oo = Mo = null
                } finally {
                    Tt = s, K.p = l, B.T = n
                }
            }
            t.current = e, It = 2
        }
    }

    function Lh() {
        if (It === 2) {
            It = 0;
            var t = Vn,
                e = yl,
                n = (e.flags & 8772) !== 0;
            if ((e.subtreeFlags & 8772) !== 0 || n) {
                n = B.T, B.T = null;
                var l = K.p;
                K.p = 2;
                var s = Tt;
                Tt |= 4;
                try {
                    sh(t, e.alternate, e)
                } finally {
                    Tt = s, K.p = l, B.T = n
                }
            }
            It = 3
        }
    }

    function Uh() {
        if (It === 4 || It === 3) {
            It = 0, Cs();
            var t = Vn,
                e = yl,
                n = bn,
                l = bh;
            (e.subtreeFlags & 10256) !== 0 || (e.flags & 10256) !== 0 ? It = 5 : (It = 0, yl = Vn = null, Nh(t, t.pendingLanes));
            var s = t.pendingLanes;
            if (s === 0 && (Xn = null), Ls(n), e = e.stateNode, Re && typeof Re.onCommitFiberRoot == "function") try {
                Re.onCommitFiberRoot(Ll, e, void 0, (e.current.flags & 128) === 128)
            } catch {}
            if (l !== null) {
                e = B.T, s = K.p, K.p = 2, B.T = null;
                try {
                    for (var o = t.onRecoverableError, d = 0; d < l.length; d++) {
                        var v = l[d];
                        o(v.value, {
                            componentStack: v.stack
                        })
                    }
                } finally {
                    B.T = e, K.p = s
                }
            }(bn & 3) !== 0 && Xu(), Ie(t), s = t.pendingLanes, (n & 261930) !== 0 && (s & 42) !== 0 ? t === mo ? mi++ : (mi = 0, mo = t) : mi = 0, yi(0)
        }
    }

    function Nh(t, e) {
        (t.pooledCacheLanes &= e) === 0 && (e = t.pooledCache, e != null && (t.pooledCache = null, Pl(e)))
    }

    function Xu() {
        return Dh(), Lh(), Uh(), Bh()
    }

    function Bh() {
        if (It !== 5) return !1;
        var t = Vn,
            e = fo;
        fo = 0;
        var n = Ls(bn),
            l = B.T,
            s = K.p;
        try {
            K.p = 32 > n ? 32 : n, B.T = null, n = ho, ho = null;
            var o = Vn,
                d = bn;
            if (It = 0, yl = Vn = null, bn = 0, (Tt & 6) !== 0) throw Error(r(331));
            var v = Tt;
            if (Tt |= 4, vh(o.current), mh(o, o.current, d, n), Tt = v, yi(0, !1), Re && typeof Re.onPostCommitFiberRoot == "function") try {
                Re.onPostCommitFiberRoot(Ll, o)
            } catch {}
            return !0
        } finally {
            K.p = s, B.T = l, Nh(t, e)
        }
    }

    function jh(t, e, n) {
        e = Ne(n, e), e = Zr(t.stateNode, e, 2), t = Bn(t, e, 2), t !== null && (Nl(t, 2), Ie(t))
    }

    function Mt(t, e, n) {
        if (t.tag === 3) jh(t, t, n);
        else
            for (; e !== null;) {
                if (e.tag === 3) {
                    jh(e, t, n);
                    break
                } else if (e.tag === 1) {
                    var l = e.stateNode;
                    if (typeof e.type.getDerivedStateFromError == "function" || typeof l.componentDidCatch == "function" && (Xn === null || !Xn.has(l))) {
                        t = Ne(n, t), n = Hd(2), l = Bn(e, n, 2), l !== null && (qd(n, l, e, t), Nl(l, 2), Ie(l));
                        break
                    }
                }
                e = e.return
            }
    }

    function vo(t, e, n) {
        var l = t.pingCache;
        if (l === null) {
            l = t.pingCache = new cg;
            var s = new Set;
            l.set(e, s)
        } else s = l.get(e), s === void 0 && (s = new Set, l.set(e, s));
        s.has(n) || (ro = !0, s.add(n), t = yg.bind(null, t, e, n), e.then(t, t))
    }

    function yg(t, e, n) {
        var l = t.pingCache;
        l !== null && l.delete(e), t.pingedLanes |= t.suspendedLanes & n, t.warmLanes &= ~n, Lt === t && (yt & n) === n && (Xt === 4 || Xt === 3 && (yt & 62914560) === yt && 300 > oe() - Bu ? (Tt & 2) === 0 && pl(t, 0) : oo |= n, ml === yt && (ml = 0)), Ie(t)
    }

    function Hh(t, e) {
        e === 0 && (e = wc()), t = ma(t, e), t !== null && (Nl(t, e), Ie(t))
    }

    function pg(t) {
        var e = t.memoizedState,
            n = 0;
        e !== null && (n = e.retryLane), Hh(t, n)
    }

    function vg(t, e) {
        var n = 0;
        switch (t.tag) {
            case 31:
            case 13:
                var l = t.stateNode,
                    s = t.memoizedState;
                s !== null && (n = s.retryLane);
                break;
            case 19:
                l = t.stateNode;
                break;
            case 22:
                l = t.stateNode._retryCache;
                break;
            default:
                throw Error(r(314))
        }
        l !== null && l.delete(e), Hh(t, n)
    }

    function gg(t, e) {
        return Xe(t, e)
    }
    var Vu = null,
        gl = null,
        go = !1,
        Qu = !1,
        So = !1,
        Zn = 0;

    function Ie(t) {
        t !== gl && t.next === null && (gl === null ? Vu = gl = t : gl = gl.next = t), Qu = !0, go || (go = !0, bg())
    }

    function yi(t, e) {
        if (!So && Qu) {
            So = !0;
            do
                for (var n = !1, l = Vu; l !== null;) {
                    if (t !== 0) {
                        var s = l.pendingLanes;
                        if (s === 0) var o = 0;
                        else {
                            var d = l.suspendedLanes,
                                v = l.pingedLanes;
                            o = (1 << 31 - Te(42 | t) + 1) - 1, o &= s & ~(d & ~v), o = o & 201326741 ? o & 201326741 | 1 : o ? o | 2 : 0
                        }
                        o !== 0 && (n = !0, Xh(l, o))
                    } else o = yt, o = ki(l, l === Lt ? o : 0, l.cancelPendingCommit !== null || l.timeoutHandle !== -1), (o & 3) === 0 || Ul(l, o) || (n = !0, Xh(l, o));
                    l = l.next
                }
            while (n);
            So = !1
        }
    }

    function Sg() {
        qh()
    }

    function qh() {
        Qu = go = !1;
        var t = 0;
        Zn !== 0 && Cg() && (t = Zn);
        for (var e = oe(), n = null, l = Vu; l !== null;) {
            var s = l.next,
                o = Yh(l, e);
            o === 0 ? (l.next = null, n === null ? Vu = s : n.next = s, s === null && (gl = n)) : (n = l, (t !== 0 || (o & 3) !== 0) && (Qu = !0)), l = s
        }
        It !== 0 && It !== 5 || yi(t), Zn !== 0 && (Zn = 0)
    }

    function Yh(t, e) {
        for (var n = t.suspendedLanes, l = t.pingedLanes, s = t.expirationTimes, o = t.pendingLanes & -62914561; 0 < o;) {
            var d = 31 - Te(o),
                v = 1 << d,
                R = s[d];
            R === -1 ? ((v & n) === 0 || (v & l) !== 0) && (s[d] = Kp(v, e)) : R <= e && (t.expiredLanes |= v), o &= ~v
        }
        if (e = Lt, n = yt, n = ki(t, t === e ? n : 0, t.cancelPendingCommit !== null || t.timeoutHandle !== -1), l = t.callbackNode, n === 0 || t === e && (xt === 2 || xt === 9) || t.cancelPendingCommit !== null) return l !== null && l !== null && Dl(l), t.callbackNode = null, t.callbackPriority = 0;
        if ((n & 3) === 0 || Ul(t, n)) {
            if (e = n & -n, e === t.callbackPriority) return e;
            switch (l !== null && Dl(l), Ls(n)) {
                case 2:
                case 8:
                    n = Je;
                    break;
                case 32:
                    n = Ha;
                    break;
                case 268435456:
                    n = Cc;
                    break;
                default:
                    n = Ha
            }
            return l = Gh.bind(null, t), n = Xe(n, l), t.callbackPriority = e, t.callbackNode = n, e
        }
        return l !== null && l !== null && Dl(l), t.callbackPriority = 2, t.callbackNode = null, 2
    }

    function Gh(t, e) {
        if (It !== 0 && It !== 5) return t.callbackNode = null, t.callbackPriority = 0, null;
        var n = t.callbackNode;
        if (Xu() && t.callbackNode !== n) return null;
        var l = yt;
        return l = ki(t, t === Lt ? l : 0, t.cancelPendingCommit !== null || t.timeoutHandle !== -1), l === 0 ? null : (Eh(t, l, e), Yh(t, oe()), t.callbackNode != null && t.callbackNode === n ? Gh.bind(null, t) : null)
    }

    function Xh(t, e) {
        if (Xu()) return null;
        Eh(t, e, !0)
    }

    function bg() {
        Dg(function() {
            (Tt & 6) !== 0 ? Xe(ae, Sg) : qh()
        })
    }

    function bo() {
        if (Zn === 0) {
            var t = al;
            t === 0 && (t = Zi, Zi <<= 1, (Zi & 261888) === 0 && (Zi = 256)), Zn = t
        }
        return Zn
    }

    function Vh(t) {
        return t == null || typeof t == "symbol" || typeof t == "boolean" ? null : typeof t == "function" ? t : Wi("" + t)
    }

    function Qh(t, e) {
        var n = e.ownerDocument.createElement("input");
        return n.name = e.name, n.value = e.value, t.id && n.setAttribute("form", t.id), e.parentNode.insertBefore(n, e), t = new FormData(t), n.parentNode.removeChild(n), t
    }

    function _g(t, e, n, l, s) {
        if (e === "submit" && n && n.stateNode === s) {
            var o = Vh((s[he] || null).action),
                d = l.submitter;
            d && (e = (e = d[he] || null) ? Vh(e.formAction) : d.getAttribute("formAction"), e !== null && (o = e, d = null));
            var v = new nu("action", "action", null, l, s);
            t.push({
                event: v,
                listeners: [{
                    instance: null,
                    listener: function() {
                        if (l.defaultPrevented) {
                            if (Zn !== 0) {
                                var R = d ? Qh(s, d) : new FormData(s);
                                qr(n, {
                                    pending: !0,
                                    data: R,
                                    method: s.method,
                                    action: o
                                }, null, R)
                            }
                        } else typeof o == "function" && (v.preventDefault(), R = d ? Qh(s, d) : new FormData(s), qr(n, {
                            pending: !0,
                            data: R,
                            method: s.method,
                            action: o
                        }, o, R))
                    },
                    currentTarget: s
                }]
            })
        }
    }
    for (var _o = 0; _o < nr.length; _o++) {
        var Eo = nr[_o],
            Eg = Eo.toLowerCase(),
            Rg = Eo[0].toUpperCase() + Eo.slice(1);
        Ve(Eg, "on" + Rg)
    }
    Ve(_f, "onAnimationEnd"), Ve(Ef, "onAnimationIteration"), Ve(Rf, "onAnimationStart"), Ve("dblclick", "onDoubleClick"), Ve("focusin", "onFocus"), Ve("focusout", "onBlur"), Ve(qv, "onTransitionRun"), Ve(Yv, "onTransitionStart"), Ve(Gv, "onTransitionCancel"), Ve(Tf, "onTransitionEnd"), Va("onMouseEnter", ["mouseout", "mouseover"]), Va("onMouseLeave", ["mouseout", "mouseover"]), Va("onPointerEnter", ["pointerout", "pointerover"]), Va("onPointerLeave", ["pointerout", "pointerover"]), ca("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), ca("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), ca("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]), ca("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), ca("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), ca("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
    var pi = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
        Tg = new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(pi));

    function Zh(t, e) {
        e = (e & 4) !== 0;
        for (var n = 0; n < t.length; n++) {
            var l = t[n],
                s = l.event;
            l = l.listeners;
            t: {
                var o = void 0;
                if (e)
                    for (var d = l.length - 1; 0 <= d; d--) {
                        var v = l[d],
                            R = v.instance,
                            L = v.currentTarget;
                        if (v = v.listener, R !== o && s.isPropagationStopped()) break t;
                        o = v, s.currentTarget = L;
                        try {
                            o(s)
                        } catch (j) {
                            iu(j)
                        }
                        s.currentTarget = null, o = R
                    } else
                        for (d = 0; d < l.length; d++) {
                            if (v = l[d], R = v.instance, L = v.currentTarget, v = v.listener, R !== o && s.isPropagationStopped()) break t;
                            o = v, s.currentTarget = L;
                            try {
                                o(s)
                            } catch (j) {
                                iu(j)
                            }
                            s.currentTarget = null, o = R
                        }
            }
        }
    }

    function mt(t, e) {
        var n = e[Us];
        n === void 0 && (n = e[Us] = new Set);
        var l = t + "__bubble";
        n.has(l) || (Kh(e, t, 2, !1), n.add(l))
    }

    function Ro(t, e, n) {
        var l = 0;
        e && (l |= 4), Kh(n, t, l, e)
    }
    var Zu = "_reactListening" + Math.random().toString(36).slice(2);

    function To(t) {
        if (!t[Zu]) {
            t[Zu] = !0, Hc.forEach(function(n) {
                n !== "selectionchange" && (Tg.has(n) || Ro(n, !1, t), Ro(n, !0, t))
            });
            var e = t.nodeType === 9 ? t : t.ownerDocument;
            e === null || e[Zu] || (e[Zu] = !0, Ro("selectionchange", !1, e))
        }
    }

    function Kh(t, e, n, l) {
        switch (_m(e)) {
            case 2:
                var s = Wg;
                break;
            case 8:
                s = $g;
                break;
            default:
                s = qo
        }
        n = s.bind(null, e, n, t), s = void 0, !Vs || e !== "touchstart" && e !== "touchmove" && e !== "wheel" || (s = !0), l ? s !== void 0 ? t.addEventListener(e, n, {
            capture: !0,
            passive: s
        }) : t.addEventListener(e, n, !0) : s !== void 0 ? t.addEventListener(e, n, {
            passive: s
        }) : t.addEventListener(e, n, !1)
    }

    function Ao(t, e, n, l, s) {
        var o = l;
        if ((e & 1) === 0 && (e & 2) === 0 && l !== null) t: for (;;) {
            if (l === null) return;
            var d = l.tag;
            if (d === 3 || d === 4) {
                var v = l.stateNode.containerInfo;
                if (v === s) break;
                if (d === 4)
                    for (d = l.return; d !== null;) {
                        var R = d.tag;
                        if ((R === 3 || R === 4) && d.stateNode.containerInfo === s) return;
                        d = d.return
                    }
                for (; v !== null;) {
                    if (d = Ya(v), d === null) return;
                    if (R = d.tag, R === 5 || R === 6 || R === 26 || R === 27) {
                        l = o = d;
                        continue t
                    }
                    v = v.parentNode
                }
            }
            l = l.return
        }
        Fc(function() {
            var L = o,
                j = Gs(n),
                G = [];
            t: {
                var U = Af.get(t);
                if (U !== void 0) {
                    var N = nu,
                        $ = t;
                    switch (t) {
                        case "keypress":
                            if (tu(n) === 0) break t;
                        case "keydown":
                        case "keyup":
                            N = vv;
                            break;
                        case "focusin":
                            $ = "focus", N = Js;
                            break;
                        case "focusout":
                            $ = "blur", N = Js;
                            break;
                        case "beforeblur":
                        case "afterblur":
                            N = Js;
                            break;
                        case "click":
                            if (n.button === 2) break t;
                        case "auxclick":
                        case "dblclick":
                        case "mousedown":
                        case "mousemove":
                        case "mouseup":
                        case "mouseout":
                        case "mouseover":
                        case "contextmenu":
                            N = $c;
                            break;
                        case "drag":
                        case "dragend":
                        case "dragenter":
                        case "dragexit":
                        case "dragleave":
                        case "dragover":
                        case "dragstart":
                        case "drop":
                            N = iv;
                            break;
                        case "touchcancel":
                        case "touchend":
                        case "touchmove":
                        case "touchstart":
                            N = bv;
                            break;
                        case _f:
                        case Ef:
                        case Rf:
                            N = rv;
                            break;
                        case Tf:
                            N = Ev;
                            break;
                        case "scroll":
                        case "scrollend":
                            N = av;
                            break;
                        case "wheel":
                            N = Tv;
                            break;
                        case "copy":
                        case "cut":
                        case "paste":
                            N = cv;
                            break;
                        case "gotpointercapture":
                        case "lostpointercapture":
                        case "pointercancel":
                        case "pointerdown":
                        case "pointermove":
                        case "pointerout":
                        case "pointerover":
                        case "pointerup":
                            N = ef;
                            break;
                        case "toggle":
                        case "beforetoggle":
                            N = xv
                    }
                    var st = (e & 4) !== 0,
                        wt = !st && (t === "scroll" || t === "scrollend"),
                        C = st ? U !== null ? U + "Capture" : null : U;
                    st = [];
                    for (var x = L, D; x !== null;) {
                        var q = x;
                        if (D = q.stateNode, q = q.tag, q !== 5 && q !== 26 && q !== 27 || D === null || C === null || (q = Hl(x, C), q != null && st.push(vi(x, q, D))), wt) break;
                        x = x.return
                    }
                    0 < st.length && (U = new N(U, $, null, n, j), G.push({
                        event: U,
                        listeners: st
                    }))
                }
            }
            if ((e & 7) === 0) {
                t: {
                    if (U = t === "mouseover" || t === "pointerover", N = t === "mouseout" || t === "pointerout", U && n !== Ys && ($ = n.relatedTarget || n.fromElement) && (Ya($) || $[qa])) break t;
                    if ((N || U) && (U = j.window === j ? j : (U = j.ownerDocument) ? U.defaultView || U.parentWindow : window, N ? ($ = n.relatedTarget || n.toElement, N = L, $ = $ ? Ya($) : null, $ !== null && (wt = f($), st = $.tag, $ !== wt || st !== 5 && st !== 27 && st !== 6) && ($ = null)) : (N = null, $ = L), N !== $)) {
                        if (st = $c, q = "onMouseLeave", C = "onMouseEnter", x = "mouse", (t === "pointerout" || t === "pointerover") && (st = ef, q = "onPointerLeave", C = "onPointerEnter", x = "pointer"), wt = N == null ? U : jl(N), D = $ == null ? U : jl($), U = new st(q, x + "leave", N, n, j), U.target = wt, U.relatedTarget = D, q = null, Ya(j) === L && (st = new st(C, x + "enter", $, n, j), st.target = D, st.relatedTarget = wt, q = st), wt = q, N && $) e: {
                            for (st = Ag, C = N, x = $, D = 0, q = C; q; q = st(q)) D++;q = 0;
                            for (var lt = x; lt; lt = st(lt)) q++;
                            for (; 0 < D - q;) C = st(C),
                            D--;
                            for (; 0 < q - D;) x = st(x),
                            q--;
                            for (; D--;) {
                                if (C === x || x !== null && C === x.alternate) {
                                    st = C;
                                    break e
                                }
                                C = st(C), x = st(x)
                            }
                            st = null
                        }
                        else st = null;
                        N !== null && Jh(G, U, N, st, !1), $ !== null && wt !== null && Jh(G, wt, $, st, !0)
                    }
                }
                t: {
                    if (U = L ? jl(L) : window, N = U.nodeName && U.nodeName.toLowerCase(), N === "select" || N === "input" && U.type === "file") var bt = cf;
                    else if (rf(U))
                        if (ff) bt = Bv;
                        else {
                            bt = Uv;
                            var nt = Lv
                        }
                    else N = U.nodeName,
                    !N || N.toLowerCase() !== "input" || U.type !== "checkbox" && U.type !== "radio" ? L && qs(L.elementType) && (bt = cf) : bt = Nv;
                    if (bt && (bt = bt(t, L))) { of (G, bt, n, j);
                        break t
                    }
                    nt && nt(t, U, L),
                    t === "focusout" && L && U.type === "number" && L.memoizedProps.value != null && Hs(U, "number", U.value)
                }
                switch (nt = L ? jl(L) : window, t) {
                    case "focusin":
                        (rf(nt) || nt.contentEditable === "true") && (Pa = nt, $s = L, Kl = null);
                        break;
                    case "focusout":
                        Kl = $s = Pa = null;
                        break;
                    case "mousedown":
                        tr = !0;
                        break;
                    case "contextmenu":
                    case "mouseup":
                    case "dragend":
                        tr = !1, Sf(G, n, j);
                        break;
                    case "selectionchange":
                        if (Hv) break;
                    case "keydown":
                    case "keyup":
                        Sf(G, n, j)
                }
                var ct;
                if (Ps) t: {
                    switch (t) {
                        case "compositionstart":
                            var pt = "onCompositionStart";
                            break t;
                        case "compositionend":
                            pt = "onCompositionEnd";
                            break t;
                        case "compositionupdate":
                            pt = "onCompositionUpdate";
                            break t
                    }
                    pt = void 0
                }
                else ka ? uf(t, n) && (pt = "onCompositionEnd") : t === "keydown" && n.keyCode === 229 && (pt = "onCompositionStart");pt && (nf && n.locale !== "ko" && (ka || pt !== "onCompositionStart" ? pt === "onCompositionEnd" && ka && (ct = Ic()) : (zn = j, Qs = "value" in zn ? zn.value : zn.textContent, ka = !0)), nt = Ku(L, pt), 0 < nt.length && (pt = new tf(pt, t, null, n, j), G.push({
                    event: pt,
                    listeners: nt
                }), ct ? pt.data = ct : (ct = sf(n), ct !== null && (pt.data = ct)))),
                (ct = Ov ? zv(t, n) : Cv(t, n)) && (pt = Ku(L, "onBeforeInput"), 0 < pt.length && (nt = new tf("onBeforeInput", "beforeinput", null, n, j), G.push({
                    event: nt,
                    listeners: pt
                }), nt.data = ct)),
                _g(G, t, L, n, j)
            }
            Zh(G, e)
        })
    }

    function vi(t, e, n) {
        return {
            instance: t,
            listener: e,
            currentTarget: n
        }
    }

    function Ku(t, e) {
        for (var n = e + "Capture", l = []; t !== null;) {
            var s = t,
                o = s.stateNode;
            if (s = s.tag, s !== 5 && s !== 26 && s !== 27 || o === null || (s = Hl(t, n), s != null && l.unshift(vi(t, s, o)), s = Hl(t, e), s != null && l.push(vi(t, s, o))), t.tag === 3) return l;
            t = t.return
        }
        return []
    }

    function Ag(t) {
        if (t === null) return null;
        do t = t.return; while (t && t.tag !== 5 && t.tag !== 27);
        return t || null
    }

    function Jh(t, e, n, l, s) {
        for (var o = e._reactName, d = []; n !== null && n !== l;) {
            var v = n,
                R = v.alternate,
                L = v.stateNode;
            if (v = v.tag, R !== null && R === l) break;
            v !== 5 && v !== 26 && v !== 27 || L === null || (R = L, s ? (L = Hl(n, o), L != null && d.unshift(vi(n, L, R))) : s || (L = Hl(n, o), L != null && d.push(vi(n, L, R)))), n = n.return
        }
        d.length !== 0 && t.push({
            event: e,
            listeners: d
        })
    }
    var xg = /\r\n?/g,
        Mg = /\u0000|\uFFFD/g;

    function kh(t) {
        return (typeof t == "string" ? t : "" + t).replace(xg, `
`).replace(Mg, "")
    }

    function Ph(t, e) {
        return e = kh(e), kh(t) === e
    }

    function Ct(t, e, n, l, s, o) {
        switch (n) {
            case "children":
                typeof l == "string" ? e === "body" || e === "textarea" && l === "" || Za(t, l) : (typeof l == "number" || typeof l == "bigint") && e !== "body" && Za(t, "" + l);
                break;
            case "className":
                Fi(t, "class", l);
                break;
            case "tabIndex":
                Fi(t, "tabindex", l);
                break;
            case "dir":
            case "role":
            case "viewBox":
            case "width":
            case "height":
                Fi(t, n, l);
                break;
            case "style":
                kc(t, l, o);
                break;
            case "data":
                if (e !== "object") {
                    Fi(t, "data", l);
                    break
                }
            case "src":
            case "href":
                if (l === "" && (e !== "a" || n !== "href")) {
                    t.removeAttribute(n);
                    break
                }
                if (l == null || typeof l == "function" || typeof l == "symbol" || typeof l == "boolean") {
                    t.removeAttribute(n);
                    break
                }
                l = Wi("" + l), t.setAttribute(n, l);
                break;
            case "action":
            case "formAction":
                if (typeof l == "function") {
                    t.setAttribute(n, "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");
                    break
                } else typeof o == "function" && (n === "formAction" ? (e !== "input" && Ct(t, e, "name", s.name, s, null), Ct(t, e, "formEncType", s.formEncType, s, null), Ct(t, e, "formMethod", s.formMethod, s, null), Ct(t, e, "formTarget", s.formTarget, s, null)) : (Ct(t, e, "encType", s.encType, s, null), Ct(t, e, "method", s.method, s, null), Ct(t, e, "target", s.target, s, null)));
                if (l == null || typeof l == "symbol" || typeof l == "boolean") {
                    t.removeAttribute(n);
                    break
                }
                l = Wi("" + l), t.setAttribute(n, l);
                break;
            case "onClick":
                l != null && (t.onclick = ln);
                break;
            case "onScroll":
                l != null && mt("scroll", t);
                break;
            case "onScrollEnd":
                l != null && mt("scrollend", t);
                break;
            case "dangerouslySetInnerHTML":
                if (l != null) {
                    if (typeof l != "object" || !("__html" in l)) throw Error(r(61));
                    if (n = l.__html, n != null) {
                        if (s.children != null) throw Error(r(60));
                        t.innerHTML = n
                    }
                }
                break;
            case "multiple":
                t.multiple = l && typeof l != "function" && typeof l != "symbol";
                break;
            case "muted":
                t.muted = l && typeof l != "function" && typeof l != "symbol";
                break;
            case "suppressContentEditableWarning":
            case "suppressHydrationWarning":
            case "defaultValue":
            case "defaultChecked":
            case "innerHTML":
            case "ref":
                break;
            case "autoFocus":
                break;
            case "xlinkHref":
                if (l == null || typeof l == "function" || typeof l == "boolean" || typeof l == "symbol") {
                    t.removeAttribute("xlink:href");
                    break
                }
                n = Wi("" + l), t.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", n);
                break;
            case "contentEditable":
            case "spellCheck":
            case "draggable":
            case "value":
            case "autoReverse":
            case "externalResourcesRequired":
            case "focusable":
            case "preserveAlpha":
                l != null && typeof l != "function" && typeof l != "symbol" ? t.setAttribute(n, "" + l) : t.removeAttribute(n);
                break;
            case "inert":
            case "allowFullScreen":
            case "async":
            case "autoPlay":
            case "controls":
            case "default":
            case "defer":
            case "disabled":
            case "disablePictureInPicture":
            case "disableRemotePlayback":
            case "formNoValidate":
            case "hidden":
            case "loop":
            case "noModule":
            case "noValidate":
            case "open":
            case "playsInline":
            case "readOnly":
            case "required":
            case "reversed":
            case "scoped":
            case "seamless":
            case "itemScope":
                l && typeof l != "function" && typeof l != "symbol" ? t.setAttribute(n, "") : t.removeAttribute(n);
                break;
            case "capture":
            case "download":
                l === !0 ? t.setAttribute(n, "") : l !== !1 && l != null && typeof l != "function" && typeof l != "symbol" ? t.setAttribute(n, l) : t.removeAttribute(n);
                break;
            case "cols":
            case "rows":
            case "size":
            case "span":
                l != null && typeof l != "function" && typeof l != "symbol" && !isNaN(l) && 1 <= l ? t.setAttribute(n, l) : t.removeAttribute(n);
                break;
            case "rowSpan":
            case "start":
                l == null || typeof l == "function" || typeof l == "symbol" || isNaN(l) ? t.removeAttribute(n) : t.setAttribute(n, l);
                break;
            case "popover":
                mt("beforetoggle", t), mt("toggle", t), Pi(t, "popover", l);
                break;
            case "xlinkActuate":
                an(t, "http://www.w3.org/1999/xlink", "xlink:actuate", l);
                break;
            case "xlinkArcrole":
                an(t, "http://www.w3.org/1999/xlink", "xlink:arcrole", l);
                break;
            case "xlinkRole":
                an(t, "http://www.w3.org/1999/xlink", "xlink:role", l);
                break;
            case "xlinkShow":
                an(t, "http://www.w3.org/1999/xlink", "xlink:show", l);
                break;
            case "xlinkTitle":
                an(t, "http://www.w3.org/1999/xlink", "xlink:title", l);
                break;
            case "xlinkType":
                an(t, "http://www.w3.org/1999/xlink", "xlink:type", l);
                break;
            case "xmlBase":
                an(t, "http://www.w3.org/XML/1998/namespace", "xml:base", l);
                break;
            case "xmlLang":
                an(t, "http://www.w3.org/XML/1998/namespace", "xml:lang", l);
                break;
            case "xmlSpace":
                an(t, "http://www.w3.org/XML/1998/namespace", "xml:space", l);
                break;
            case "is":
                Pi(t, "is", l);
                break;
            case "innerText":
            case "textContent":
                break;
            default:
                (!(2 < n.length) || n[0] !== "o" && n[0] !== "O" || n[1] !== "n" && n[1] !== "N") && (n = ev.get(n) || n, Pi(t, n, l))
        }
    }

    function xo(t, e, n, l, s, o) {
        switch (n) {
            case "style":
                kc(t, l, o);
                break;
            case "dangerouslySetInnerHTML":
                if (l != null) {
                    if (typeof l != "object" || !("__html" in l)) throw Error(r(61));
                    if (n = l.__html, n != null) {
                        if (s.children != null) throw Error(r(60));
                        t.innerHTML = n
                    }
                }
                break;
            case "children":
                typeof l == "string" ? Za(t, l) : (typeof l == "number" || typeof l == "bigint") && Za(t, "" + l);
                break;
            case "onScroll":
                l != null && mt("scroll", t);
                break;
            case "onScrollEnd":
                l != null && mt("scrollend", t);
                break;
            case "onClick":
                l != null && (t.onclick = ln);
                break;
            case "suppressContentEditableWarning":
            case "suppressHydrationWarning":
            case "innerHTML":
            case "ref":
                break;
            case "innerText":
            case "textContent":
                break;
            default:
                if (!qc.hasOwnProperty(n)) t: {
                    if (n[0] === "o" && n[1] === "n" && (s = n.endsWith("Capture"), e = n.slice(2, s ? n.length - 7 : void 0), o = t[he] || null, o = o != null ? o[n] : null, typeof o == "function" && t.removeEventListener(e, o, s), typeof l == "function")) {
                        typeof o != "function" && o !== null && (n in t ? t[n] = null : t.hasAttribute(n) && t.removeAttribute(n)), t.addEventListener(e, l, s);
                        break t
                    }
                    n in t ? t[n] = l : l === !0 ? t.setAttribute(n, "") : Pi(t, n, l)
                }
        }
    }

    function re(t, e, n) {
        switch (e) {
            case "div":
            case "span":
            case "svg":
            case "path":
            case "a":
            case "g":
            case "p":
            case "li":
                break;
            case "img":
                mt("error", t), mt("load", t);
                var l = !1,
                    s = !1,
                    o;
                for (o in n)
                    if (n.hasOwnProperty(o)) {
                        var d = n[o];
                        if (d != null) switch (o) {
                            case "src":
                                l = !0;
                                break;
                            case "srcSet":
                                s = !0;
                                break;
                            case "children":
                            case "dangerouslySetInnerHTML":
                                throw Error(r(137, e));
                            default:
                                Ct(t, e, o, d, n, null)
                        }
                    }
                s && Ct(t, e, "srcSet", n.srcSet, n, null), l && Ct(t, e, "src", n.src, n, null);
                return;
            case "input":
                mt("invalid", t);
                var v = o = d = s = null,
                    R = null,
                    L = null;
                for (l in n)
                    if (n.hasOwnProperty(l)) {
                        var j = n[l];
                        if (j != null) switch (l) {
                            case "name":
                                s = j;
                                break;
                            case "type":
                                d = j;
                                break;
                            case "checked":
                                R = j;
                                break;
                            case "defaultChecked":
                                L = j;
                                break;
                            case "value":
                                o = j;
                                break;
                            case "defaultValue":
                                v = j;
                                break;
                            case "children":
                            case "dangerouslySetInnerHTML":
                                if (j != null) throw Error(r(137, e));
                                break;
                            default:
                                Ct(t, e, l, j, n, null)
                        }
                    }
                Qc(t, o, v, R, L, d, s, !1);
                return;
            case "select":
                mt("invalid", t), l = d = o = null;
                for (s in n)
                    if (n.hasOwnProperty(s) && (v = n[s], v != null)) switch (s) {
                        case "value":
                            o = v;
                            break;
                        case "defaultValue":
                            d = v;
                            break;
                        case "multiple":
                            l = v;
                        default:
                            Ct(t, e, s, v, n, null)
                    }
                e = o, n = d, t.multiple = !!l, e != null ? Qa(t, !!l, e, !1) : n != null && Qa(t, !!l, n, !0);
                return;
            case "textarea":
                mt("invalid", t), o = s = l = null;
                for (d in n)
                    if (n.hasOwnProperty(d) && (v = n[d], v != null)) switch (d) {
                        case "value":
                            l = v;
                            break;
                        case "defaultValue":
                            s = v;
                            break;
                        case "children":
                            o = v;
                            break;
                        case "dangerouslySetInnerHTML":
                            if (v != null) throw Error(r(91));
                            break;
                        default:
                            Ct(t, e, d, v, n, null)
                    }
                Kc(t, l, s, o);
                return;
            case "option":
                for (R in n) n.hasOwnProperty(R) && (l = n[R], l != null) && (R === "selected" ? t.selected = l && typeof l != "function" && typeof l != "symbol" : Ct(t, e, R, l, n, null));
                return;
            case "dialog":
                mt("beforetoggle", t), mt("toggle", t), mt("cancel", t), mt("close", t);
                break;
            case "iframe":
            case "object":
                mt("load", t);
                break;
            case "video":
            case "audio":
                for (l = 0; l < pi.length; l++) mt(pi[l], t);
                break;
            case "image":
                mt("error", t), mt("load", t);
                break;
            case "details":
                mt("toggle", t);
                break;
            case "embed":
            case "source":
            case "link":
                mt("error", t), mt("load", t);
            case "area":
            case "base":
            case "br":
            case "col":
            case "hr":
            case "keygen":
            case "meta":
            case "param":
            case "track":
            case "wbr":
            case "menuitem":
                for (L in n)
                    if (n.hasOwnProperty(L) && (l = n[L], l != null)) switch (L) {
                        case "children":
                        case "dangerouslySetInnerHTML":
                            throw Error(r(137, e));
                        default:
                            Ct(t, e, L, l, n, null)
                    }
                return;
            default:
                if (qs(e)) {
                    for (j in n) n.hasOwnProperty(j) && (l = n[j], l !== void 0 && xo(t, e, j, l, n, void 0));
                    return
                }
        }
        for (v in n) n.hasOwnProperty(v) && (l = n[v], l != null && Ct(t, e, v, l, n, null))
    }

    function Og(t, e, n, l) {
        switch (e) {
            case "div":
            case "span":
            case "svg":
            case "path":
            case "a":
            case "g":
            case "p":
            case "li":
                break;
            case "input":
                var s = null,
                    o = null,
                    d = null,
                    v = null,
                    R = null,
                    L = null,
                    j = null;
                for (N in n) {
                    var G = n[N];
                    if (n.hasOwnProperty(N) && G != null) switch (N) {
                        case "checked":
                            break;
                        case "value":
                            break;
                        case "defaultValue":
                            R = G;
                        default:
                            l.hasOwnProperty(N) || Ct(t, e, N, null, l, G)
                    }
                }
                for (var U in l) {
                    var N = l[U];
                    if (G = n[U], l.hasOwnProperty(U) && (N != null || G != null)) switch (U) {
                        case "type":
                            o = N;
                            break;
                        case "name":
                            s = N;
                            break;
                        case "checked":
                            L = N;
                            break;
                        case "defaultChecked":
                            j = N;
                            break;
                        case "value":
                            d = N;
                            break;
                        case "defaultValue":
                            v = N;
                            break;
                        case "children":
                        case "dangerouslySetInnerHTML":
                            if (N != null) throw Error(r(137, e));
                            break;
                        default:
                            N !== G && Ct(t, e, U, N, l, G)
                    }
                }
                js(t, d, v, R, L, j, o, s);
                return;
            case "select":
                N = d = v = U = null;
                for (o in n)
                    if (R = n[o], n.hasOwnProperty(o) && R != null) switch (o) {
                        case "value":
                            break;
                        case "multiple":
                            N = R;
                        default:
                            l.hasOwnProperty(o) || Ct(t, e, o, null, l, R)
                    }
                for (s in l)
                    if (o = l[s], R = n[s], l.hasOwnProperty(s) && (o != null || R != null)) switch (s) {
                        case "value":
                            U = o;
                            break;
                        case "defaultValue":
                            v = o;
                            break;
                        case "multiple":
                            d = o;
                        default:
                            o !== R && Ct(t, e, s, o, l, R)
                    }
                e = v, n = d, l = N, U != null ? Qa(t, !!n, U, !1) : !!l != !!n && (e != null ? Qa(t, !!n, e, !0) : Qa(t, !!n, n ? [] : "", !1));
                return;
            case "textarea":
                N = U = null;
                for (v in n)
                    if (s = n[v], n.hasOwnProperty(v) && s != null && !l.hasOwnProperty(v)) switch (v) {
                        case "value":
                            break;
                        case "children":
                            break;
                        default:
                            Ct(t, e, v, null, l, s)
                    }
                for (d in l)
                    if (s = l[d], o = n[d], l.hasOwnProperty(d) && (s != null || o != null)) switch (d) {
                        case "value":
                            U = s;
                            break;
                        case "defaultValue":
                            N = s;
                            break;
                        case "children":
                            break;
                        case "dangerouslySetInnerHTML":
                            if (s != null) throw Error(r(91));
                            break;
                        default:
                            s !== o && Ct(t, e, d, s, l, o)
                    }
                Zc(t, U, N);
                return;
            case "option":
                for (var $ in n) U = n[$], n.hasOwnProperty($) && U != null && !l.hasOwnProperty($) && ($ === "selected" ? t.selected = !1 : Ct(t, e, $, null, l, U));
                for (R in l) U = l[R], N = n[R], l.hasOwnProperty(R) && U !== N && (U != null || N != null) && (R === "selected" ? t.selected = U && typeof U != "function" && typeof U != "symbol" : Ct(t, e, R, U, l, N));
                return;
            case "img":
            case "link":
            case "area":
            case "base":
            case "br":
            case "col":
            case "embed":
            case "hr":
            case "keygen":
            case "meta":
            case "param":
            case "source":
            case "track":
            case "wbr":
            case "menuitem":
                for (var st in n) U = n[st], n.hasOwnProperty(st) && U != null && !l.hasOwnProperty(st) && Ct(t, e, st, null, l, U);
                for (L in l)
                    if (U = l[L], N = n[L], l.hasOwnProperty(L) && U !== N && (U != null || N != null)) switch (L) {
                        case "children":
                        case "dangerouslySetInnerHTML":
                            if (U != null) throw Error(r(137, e));
                            break;
                        default:
                            Ct(t, e, L, U, l, N)
                    }
                return;
            default:
                if (qs(e)) {
                    for (var wt in n) U = n[wt], n.hasOwnProperty(wt) && U !== void 0 && !l.hasOwnProperty(wt) && xo(t, e, wt, void 0, l, U);
                    for (j in l) U = l[j], N = n[j], !l.hasOwnProperty(j) || U === N || U === void 0 && N === void 0 || xo(t, e, j, U, l, N);
                    return
                }
        }
        for (var C in n) U = n[C], n.hasOwnProperty(C) && U != null && !l.hasOwnProperty(C) && Ct(t, e, C, null, l, U);
        for (G in l) U = l[G], N = n[G], !l.hasOwnProperty(G) || U === N || U == null && N == null || Ct(t, e, G, U, l, N)
    }

    function Fh(t) {
        switch (t) {
            case "css":
            case "script":
            case "font":
            case "img":
            case "image":
            case "input":
            case "link":
                return !0;
            default:
                return !1
        }
    }

    function zg() {
        if (typeof performance.getEntriesByType == "function") {
            for (var t = 0, e = 0, n = performance.getEntriesByType("resource"), l = 0; l < n.length; l++) {
                var s = n[l],
                    o = s.transferSize,
                    d = s.initiatorType,
                    v = s.duration;
                if (o && v && Fh(d)) {
                    for (d = 0, v = s.responseEnd, l += 1; l < n.length; l++) {
                        var R = n[l],
                            L = R.startTime;
                        if (L > v) break;
                        var j = R.transferSize,
                            G = R.initiatorType;
                        j && Fh(G) && (R = R.responseEnd, d += j * (R < v ? 1 : (v - L) / (R - L)))
                    }
                    if (--l, e += 8 * (o + d) / (s.duration / 1e3), t++, 10 < t) break
                }
            }
            if (0 < t) return e / t / 1e6
        }
        return navigator.connection && (t = navigator.connection.downlink, typeof t == "number") ? t : 5
    }
    var Mo = null,
        Oo = null;

    function Ju(t) {
        return t.nodeType === 9 ? t : t.ownerDocument
    }

    function Ih(t) {
        switch (t) {
            case "http://www.w3.org/2000/svg":
                return 1;
            case "http://www.w3.org/1998/Math/MathML":
                return 2;
            default:
                return 0
        }
    }

    function Wh(t, e) {
        if (t === 0) switch (e) {
            case "svg":
                return 1;
            case "math":
                return 2;
            default:
                return 0
        }
        return t === 1 && e === "foreignObject" ? 0 : t
    }

    function zo(t, e) {
        return t === "textarea" || t === "noscript" || typeof e.children == "string" || typeof e.children == "number" || typeof e.children == "bigint" || typeof e.dangerouslySetInnerHTML == "object" && e.dangerouslySetInnerHTML !== null && e.dangerouslySetInnerHTML.__html != null
    }
    var Co = null;

    function Cg() {
        var t = window.event;
        return t && t.type === "popstate" ? t === Co ? !1 : (Co = t, !0) : (Co = null, !1)
    }
    var $h = typeof setTimeout == "function" ? setTimeout : void 0,
        wg = typeof clearTimeout == "function" ? clearTimeout : void 0,
        tm = typeof Promise == "function" ? Promise : void 0,
        Dg = typeof queueMicrotask == "function" ? queueMicrotask : typeof tm < "u" ? function(t) {
            return tm.resolve(null).then(t).catch(Lg)
        } : $h;

    function Lg(t) {
        setTimeout(function() {
            throw t
        })
    }

    function Kn(t) {
        return t === "head"
    }

    function em(t, e) {
        var n = e,
            l = 0;
        do {
            var s = n.nextSibling;
            if (t.removeChild(n), s && s.nodeType === 8)
                if (n = s.data, n === "/$" || n === "/&") {
                    if (l === 0) {
                        t.removeChild(s), El(e);
                        return
                    }
                    l--
                } else if (n === "$" || n === "$?" || n === "$~" || n === "$!" || n === "&") l++;
            else if (n === "html") gi(t.ownerDocument.documentElement);
            else if (n === "head") {
                n = t.ownerDocument.head, gi(n);
                for (var o = n.firstChild; o;) {
                    var d = o.nextSibling,
                        v = o.nodeName;
                    o[Bl] || v === "SCRIPT" || v === "STYLE" || v === "LINK" && o.rel.toLowerCase() === "stylesheet" || n.removeChild(o), o = d
                }
            } else n === "body" && gi(t.ownerDocument.body);
            n = s
        } while (n);
        El(e)
    }

    function nm(t, e) {
        var n = t;
        t = 0;
        do {
            var l = n.nextSibling;
            if (n.nodeType === 1 ? e ? (n._stashedDisplay = n.style.display, n.style.display = "none") : (n.style.display = n._stashedDisplay || "", n.getAttribute("style") === "" && n.removeAttribute("style")) : n.nodeType === 3 && (e ? (n._stashedText = n.nodeValue, n.nodeValue = "") : n.nodeValue = n._stashedText || ""), l && l.nodeType === 8)
                if (n = l.data, n === "/$") {
                    if (t === 0) break;
                    t--
                } else n !== "$" && n !== "$?" && n !== "$~" && n !== "$!" || t++;
            n = l
        } while (n)
    }

    function wo(t) {
        var e = t.firstChild;
        for (e && e.nodeType === 10 && (e = e.nextSibling); e;) {
            var n = e;
            switch (e = e.nextSibling, n.nodeName) {
                case "HTML":
                case "HEAD":
                case "BODY":
                    wo(n), Ns(n);
                    continue;
                case "SCRIPT":
                case "STYLE":
                    continue;
                case "LINK":
                    if (n.rel.toLowerCase() === "stylesheet") continue
            }
            t.removeChild(n)
        }
    }

    function Ug(t, e, n, l) {
        for (; t.nodeType === 1;) {
            var s = n;
            if (t.nodeName.toLowerCase() !== e.toLowerCase()) {
                if (!l && (t.nodeName !== "INPUT" || t.type !== "hidden")) break
            } else if (l) {
                if (!t[Bl]) switch (e) {
                    case "meta":
                        if (!t.hasAttribute("itemprop")) break;
                        return t;
                    case "link":
                        if (o = t.getAttribute("rel"), o === "stylesheet" && t.hasAttribute("data-precedence")) break;
                        if (o !== s.rel || t.getAttribute("href") !== (s.href == null || s.href === "" ? null : s.href) || t.getAttribute("crossorigin") !== (s.crossOrigin == null ? null : s.crossOrigin) || t.getAttribute("title") !== (s.title == null ? null : s.title)) break;
                        return t;
                    case "style":
                        if (t.hasAttribute("data-precedence")) break;
                        return t;
                    case "script":
                        if (o = t.getAttribute("src"), (o !== (s.src == null ? null : s.src) || t.getAttribute("type") !== (s.type == null ? null : s.type) || t.getAttribute("crossorigin") !== (s.crossOrigin == null ? null : s.crossOrigin)) && o && t.hasAttribute("async") && !t.hasAttribute("itemprop")) break;
                        return t;
                    default:
                        return t
                }
            } else if (e === "input" && t.type === "hidden") {
                var o = s.name == null ? null : "" + s.name;
                if (s.type === "hidden" && t.getAttribute("name") === o) return t
            } else return t;
            if (t = Ye(t.nextSibling), t === null) break
        }
        return null
    }

    function Ng(t, e, n) {
        if (e === "") return null;
        for (; t.nodeType !== 3;)
            if ((t.nodeType !== 1 || t.nodeName !== "INPUT" || t.type !== "hidden") && !n || (t = Ye(t.nextSibling), t === null)) return null;
        return t
    }

    function am(t, e) {
        for (; t.nodeType !== 8;)
            if ((t.nodeType !== 1 || t.nodeName !== "INPUT" || t.type !== "hidden") && !e || (t = Ye(t.nextSibling), t === null)) return null;
        return t
    }

    function Do(t) {
        return t.data === "$?" || t.data === "$~"
    }

    function Lo(t) {
        return t.data === "$!" || t.data === "$?" && t.ownerDocument.readyState !== "loading"
    }

    function Bg(t, e) {
        var n = t.ownerDocument;
        if (t.data === "$~") t._reactRetry = e;
        else if (t.data !== "$?" || n.readyState !== "loading") e();
        else {
            var l = function() {
                e(), n.removeEventListener("DOMContentLoaded", l)
            };
            n.addEventListener("DOMContentLoaded", l), t._reactRetry = l
        }
    }

    function Ye(t) {
        for (; t != null; t = t.nextSibling) {
            var e = t.nodeType;
            if (e === 1 || e === 3) break;
            if (e === 8) {
                if (e = t.data, e === "$" || e === "$!" || e === "$?" || e === "$~" || e === "&" || e === "F!" || e === "F") break;
                if (e === "/$" || e === "/&") return null
            }
        }
        return t
    }
    var Uo = null;

    function lm(t) {
        t = t.nextSibling;
        for (var e = 0; t;) {
            if (t.nodeType === 8) {
                var n = t.data;
                if (n === "/$" || n === "/&") {
                    if (e === 0) return Ye(t.nextSibling);
                    e--
                } else n !== "$" && n !== "$!" && n !== "$?" && n !== "$~" && n !== "&" || e++
            }
            t = t.nextSibling
        }
        return null
    }

    function im(t) {
        t = t.previousSibling;
        for (var e = 0; t;) {
            if (t.nodeType === 8) {
                var n = t.data;
                if (n === "$" || n === "$!" || n === "$?" || n === "$~" || n === "&") {
                    if (e === 0) return t;
                    e--
                } else n !== "/$" && n !== "/&" || e++
            }
            t = t.previousSibling
        }
        return null
    }

    function um(t, e, n) {
        switch (e = Ju(n), t) {
            case "html":
                if (t = e.documentElement, !t) throw Error(r(452));
                return t;
            case "head":
                if (t = e.head, !t) throw Error(r(453));
                return t;
            case "body":
                if (t = e.body, !t) throw Error(r(454));
                return t;
            default:
                throw Error(r(451))
        }
    }

    function gi(t) {
        for (var e = t.attributes; e.length;) t.removeAttributeNode(e[0]);
        Ns(t)
    }
    var Ge = new Map,
        sm = new Set;

    function ku(t) {
        return typeof t.getRootNode == "function" ? t.getRootNode() : t.nodeType === 9 ? t : t.ownerDocument
    }
    var _n = K.d;
    K.d = {
        f: jg,
        r: Hg,
        D: qg,
        C: Yg,
        L: Gg,
        m: Xg,
        X: Qg,
        S: Vg,
        M: Zg
    };

    function jg() {
        var t = _n.f(),
            e = qu();
        return t || e
    }

    function Hg(t) {
        var e = Ga(t);
        e !== null && e.tag === 5 && e.type === "form" ? Td(e) : _n.r(t)
    }
    var Sl = typeof document > "u" ? null : document;

    function rm(t, e, n) {
        var l = Sl;
        if (l && typeof e == "string" && e) {
            var s = Le(e);
            s = 'link[rel="' + t + '"][href="' + s + '"]', typeof n == "string" && (s += '[crossorigin="' + n + '"]'), sm.has(s) || (sm.add(s), t = {
                rel: t,
                crossOrigin: n,
                href: e
            }, l.querySelector(s) === null && (e = l.createElement("link"), re(e, "link", t), te(e), l.head.appendChild(e)))
        }
    }

    function qg(t) {
        _n.D(t), rm("dns-prefetch", t, null)
    }

    function Yg(t, e) {
        _n.C(t, e), rm("preconnect", t, e)
    }

    function Gg(t, e, n) {
        _n.L(t, e, n);
        var l = Sl;
        if (l && t && e) {
            var s = 'link[rel="preload"][as="' + Le(e) + '"]';
            e === "image" && n && n.imageSrcSet ? (s += '[imagesrcset="' + Le(n.imageSrcSet) + '"]', typeof n.imageSizes == "string" && (s += '[imagesizes="' + Le(n.imageSizes) + '"]')) : s += '[href="' + Le(t) + '"]';
            var o = s;
            switch (e) {
                case "style":
                    o = bl(t);
                    break;
                case "script":
                    o = _l(t)
            }
            Ge.has(o) || (t = g({
                rel: "preload",
                href: e === "image" && n && n.imageSrcSet ? void 0 : t,
                as: e
            }, n), Ge.set(o, t), l.querySelector(s) !== null || e === "style" && l.querySelector(Si(o)) || e === "script" && l.querySelector(bi(o)) || (e = l.createElement("link"), re(e, "link", t), te(e), l.head.appendChild(e)))
        }
    }

    function Xg(t, e) {
        _n.m(t, e);
        var n = Sl;
        if (n && t) {
            var l = e && typeof e.as == "string" ? e.as : "script",
                s = 'link[rel="modulepreload"][as="' + Le(l) + '"][href="' + Le(t) + '"]',
                o = s;
            switch (l) {
                case "audioworklet":
                case "paintworklet":
                case "serviceworker":
                case "sharedworker":
                case "worker":
                case "script":
                    o = _l(t)
            }
            if (!Ge.has(o) && (t = g({
                    rel: "modulepreload",
                    href: t
                }, e), Ge.set(o, t), n.querySelector(s) === null)) {
                switch (l) {
                    case "audioworklet":
                    case "paintworklet":
                    case "serviceworker":
                    case "sharedworker":
                    case "worker":
                    case "script":
                        if (n.querySelector(bi(o))) return
                }
                l = n.createElement("link"), re(l, "link", t), te(l), n.head.appendChild(l)
            }
        }
    }

    function Vg(t, e, n) {
        _n.S(t, e, n);
        var l = Sl;
        if (l && t) {
            var s = Xa(l).hoistableStyles,
                o = bl(t);
            e = e || "default";
            var d = s.get(o);
            if (!d) {
                var v = {
                    loading: 0,
                    preload: null
                };
                if (d = l.querySelector(Si(o))) v.loading = 5;
                else {
                    t = g({
                        rel: "stylesheet",
                        href: t,
                        "data-precedence": e
                    }, n), (n = Ge.get(o)) && No(t, n);
                    var R = d = l.createElement("link");
                    te(R), re(R, "link", t), R._p = new Promise(function(L, j) {
                        R.onload = L, R.onerror = j
                    }), R.addEventListener("load", function() {
                        v.loading |= 1
                    }), R.addEventListener("error", function() {
                        v.loading |= 2
                    }), v.loading |= 4, Pu(d, e, l)
                }
                d = {
                    type: "stylesheet",
                    instance: d,
                    count: 1,
                    state: v
                }, s.set(o, d)
            }
        }
    }

    function Qg(t, e) {
        _n.X(t, e);
        var n = Sl;
        if (n && t) {
            var l = Xa(n).hoistableScripts,
                s = _l(t),
                o = l.get(s);
            o || (o = n.querySelector(bi(s)), o || (t = g({
                src: t,
                async: !0
            }, e), (e = Ge.get(s)) && Bo(t, e), o = n.createElement("script"), te(o), re(o, "link", t), n.head.appendChild(o)), o = {
                type: "script",
                instance: o,
                count: 1,
                state: null
            }, l.set(s, o))
        }
    }

    function Zg(t, e) {
        _n.M(t, e);
        var n = Sl;
        if (n && t) {
            var l = Xa(n).hoistableScripts,
                s = _l(t),
                o = l.get(s);
            o || (o = n.querySelector(bi(s)), o || (t = g({
                src: t,
                async: !0,
                type: "module"
            }, e), (e = Ge.get(s)) && Bo(t, e), o = n.createElement("script"), te(o), re(o, "link", t), n.head.appendChild(o)), o = {
                type: "script",
                instance: o,
                count: 1,
                state: null
            }, l.set(s, o))
        }
    }

    function om(t, e, n, l) {
        var s = (s = ft.current) ? ku(s) : null;
        if (!s) throw Error(r(446));
        switch (t) {
            case "meta":
            case "title":
                return null;
            case "style":
                return typeof n.precedence == "string" && typeof n.href == "string" ? (e = bl(n.href), n = Xa(s).hoistableStyles, l = n.get(e), l || (l = {
                    type: "style",
                    instance: null,
                    count: 0,
                    state: null
                }, n.set(e, l)), l) : {
                    type: "void",
                    instance: null,
                    count: 0,
                    state: null
                };
            case "link":
                if (n.rel === "stylesheet" && typeof n.href == "string" && typeof n.precedence == "string") {
                    t = bl(n.href);
                    var o = Xa(s).hoistableStyles,
                        d = o.get(t);
                    if (d || (s = s.ownerDocument || s, d = {
                            type: "stylesheet",
                            instance: null,
                            count: 0,
                            state: {
                                loading: 0,
                                preload: null
                            }
                        }, o.set(t, d), (o = s.querySelector(Si(t))) && !o._p && (d.instance = o, d.state.loading = 5), Ge.has(t) || (n = {
                            rel: "preload",
                            as: "style",
                            href: n.href,
                            crossOrigin: n.crossOrigin,
                            integrity: n.integrity,
                            media: n.media,
                            hrefLang: n.hrefLang,
                            referrerPolicy: n.referrerPolicy
                        }, Ge.set(t, n), o || Kg(s, t, n, d.state))), e && l === null) throw Error(r(528, ""));
                    return d
                }
                if (e && l !== null) throw Error(r(529, ""));
                return null;
            case "script":
                return e = n.async, n = n.src, typeof n == "string" && e && typeof e != "function" && typeof e != "symbol" ? (e = _l(n), n = Xa(s).hoistableScripts, l = n.get(e), l || (l = {
                    type: "script",
                    instance: null,
                    count: 0,
                    state: null
                }, n.set(e, l)), l) : {
                    type: "void",
                    instance: null,
                    count: 0,
                    state: null
                };
            default:
                throw Error(r(444, t))
        }
    }

    function bl(t) {
        return 'href="' + Le(t) + '"'
    }

    function Si(t) {
        return 'link[rel="stylesheet"][' + t + "]"
    }

    function cm(t) {
        return g({}, t, {
            "data-precedence": t.precedence,
            precedence: null
        })
    }

    function Kg(t, e, n, l) {
        t.querySelector('link[rel="preload"][as="style"][' + e + "]") ? l.loading = 1 : (e = t.createElement("link"), l.preload = e, e.addEventListener("load", function() {
            return l.loading |= 1
        }), e.addEventListener("error", function() {
            return l.loading |= 2
        }), re(e, "link", n), te(e), t.head.appendChild(e))
    }

    function _l(t) {
        return '[src="' + Le(t) + '"]'
    }

    function bi(t) {
        return "script[async]" + t
    }

    function fm(t, e, n) {
        if (e.count++, e.instance === null) switch (e.type) {
            case "style":
                var l = t.querySelector('style[data-href~="' + Le(n.href) + '"]');
                if (l) return e.instance = l, te(l), l;
                var s = g({}, n, {
                    "data-href": n.href,
                    "data-precedence": n.precedence,
                    href: null,
                    precedence: null
                });
                return l = (t.ownerDocument || t).createElement("style"), te(l), re(l, "style", s), Pu(l, n.precedence, t), e.instance = l;
            case "stylesheet":
                s = bl(n.href);
                var o = t.querySelector(Si(s));
                if (o) return e.state.loading |= 4, e.instance = o, te(o), o;
                l = cm(n), (s = Ge.get(s)) && No(l, s), o = (t.ownerDocument || t).createElement("link"), te(o);
                var d = o;
                return d._p = new Promise(function(v, R) {
                    d.onload = v, d.onerror = R
                }), re(o, "link", l), e.state.loading |= 4, Pu(o, n.precedence, t), e.instance = o;
            case "script":
                return o = _l(n.src), (s = t.querySelector(bi(o))) ? (e.instance = s, te(s), s) : (l = n, (s = Ge.get(o)) && (l = g({}, n), Bo(l, s)), t = t.ownerDocument || t, s = t.createElement("script"), te(s), re(s, "link", l), t.head.appendChild(s), e.instance = s);
            case "void":
                return null;
            default:
                throw Error(r(443, e.type))
        } else e.type === "stylesheet" && (e.state.loading & 4) === 0 && (l = e.instance, e.state.loading |= 4, Pu(l, n.precedence, t));
        return e.instance
    }

    function Pu(t, e, n) {
        for (var l = n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'), s = l.length ? l[l.length - 1] : null, o = s, d = 0; d < l.length; d++) {
            var v = l[d];
            if (v.dataset.precedence === e) o = v;
            else if (o !== s) break
        }
        o ? o.parentNode.insertBefore(t, o.nextSibling) : (e = n.nodeType === 9 ? n.head : n, e.insertBefore(t, e.firstChild))
    }

    function No(t, e) {
        t.crossOrigin == null && (t.crossOrigin = e.crossOrigin), t.referrerPolicy == null && (t.referrerPolicy = e.referrerPolicy), t.title == null && (t.title = e.title)
    }

    function Bo(t, e) {
        t.crossOrigin == null && (t.crossOrigin = e.crossOrigin), t.referrerPolicy == null && (t.referrerPolicy = e.referrerPolicy), t.integrity == null && (t.integrity = e.integrity)
    }
    var Fu = null;

    function dm(t, e, n) {
        if (Fu === null) {
            var l = new Map,
                s = Fu = new Map;
            s.set(n, l)
        } else s = Fu, l = s.get(n), l || (l = new Map, s.set(n, l));
        if (l.has(t)) return l;
        for (l.set(t, null), n = n.getElementsByTagName(t), s = 0; s < n.length; s++) {
            var o = n[s];
            if (!(o[Bl] || o[le] || t === "link" && o.getAttribute("rel") === "stylesheet") && o.namespaceURI !== "http://www.w3.org/2000/svg") {
                var d = o.getAttribute(e) || "";
                d = t + d;
                var v = l.get(d);
                v ? v.push(o) : l.set(d, [o])
            }
        }
        return l
    }

    function hm(t, e, n) {
        t = t.ownerDocument || t, t.head.insertBefore(n, e === "title" ? t.querySelector("head > title") : null)
    }

    function Jg(t, e, n) {
        if (n === 1 || e.itemProp != null) return !1;
        switch (t) {
            case "meta":
            case "title":
                return !0;
            case "style":
                if (typeof e.precedence != "string" || typeof e.href != "string" || e.href === "") break;
                return !0;
            case "link":
                if (typeof e.rel != "string" || typeof e.href != "string" || e.href === "" || e.onLoad || e.onError) break;
                return e.rel === "stylesheet" ? (t = e.disabled, typeof e.precedence == "string" && t == null) : !0;
            case "script":
                if (e.async && typeof e.async != "function" && typeof e.async != "symbol" && !e.onLoad && !e.onError && e.src && typeof e.src == "string") return !0
        }
        return !1
    }

    function mm(t) {
        return !(t.type === "stylesheet" && (t.state.loading & 3) === 0)
    }

    function kg(t, e, n, l) {
        if (n.type === "stylesheet" && (typeof l.media != "string" || matchMedia(l.media).matches !== !1) && (n.state.loading & 4) === 0) {
            if (n.instance === null) {
                var s = bl(l.href),
                    o = e.querySelector(Si(s));
                if (o) {
                    e = o._p, e !== null && typeof e == "object" && typeof e.then == "function" && (t.count++, t = Iu.bind(t), e.then(t, t)), n.state.loading |= 4, n.instance = o, te(o);
                    return
                }
                o = e.ownerDocument || e, l = cm(l), (s = Ge.get(s)) && No(l, s), o = o.createElement("link"), te(o);
                var d = o;
                d._p = new Promise(function(v, R) {
                    d.onload = v, d.onerror = R
                }), re(o, "link", l), n.instance = o
            }
            t.stylesheets === null && (t.stylesheets = new Map), t.stylesheets.set(n, e), (e = n.state.preload) && (n.state.loading & 3) === 0 && (t.count++, n = Iu.bind(t), e.addEventListener("load", n), e.addEventListener("error", n))
        }
    }
    var jo = 0;

    function Pg(t, e) {
        return t.stylesheets && t.count === 0 && $u(t, t.stylesheets), 0 < t.count || 0 < t.imgCount ? function(n) {
            var l = setTimeout(function() {
                if (t.stylesheets && $u(t, t.stylesheets), t.unsuspend) {
                    var o = t.unsuspend;
                    t.unsuspend = null, o()
                }
            }, 6e4 + e);
            0 < t.imgBytes && jo === 0 && (jo = 62500 * zg());
            var s = setTimeout(function() {
                if (t.waitingForImages = !1, t.count === 0 && (t.stylesheets && $u(t, t.stylesheets), t.unsuspend)) {
                    var o = t.unsuspend;
                    t.unsuspend = null, o()
                }
            }, (t.imgBytes > jo ? 50 : 800) + e);
            return t.unsuspend = n,
                function() {
                    t.unsuspend = null, clearTimeout(l), clearTimeout(s)
                }
        } : null
    }

    function Iu() {
        if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
            if (this.stylesheets) $u(this, this.stylesheets);
            else if (this.unsuspend) {
                var t = this.unsuspend;
                this.unsuspend = null, t()
            }
        }
    }
    var Wu = null;

    function $u(t, e) {
        t.stylesheets = null, t.unsuspend !== null && (t.count++, Wu = new Map, e.forEach(Fg, t), Wu = null, Iu.call(t))
    }

    function Fg(t, e) {
        if (!(e.state.loading & 4)) {
            var n = Wu.get(t);
            if (n) var l = n.get(null);
            else {
                n = new Map, Wu.set(t, n);
                for (var s = t.querySelectorAll("link[data-precedence],style[data-precedence]"), o = 0; o < s.length; o++) {
                    var d = s[o];
                    (d.nodeName === "LINK" || d.getAttribute("media") !== "not all") && (n.set(d.dataset.precedence, d), l = d)
                }
                l && n.set(null, l)
            }
            s = e.instance, d = s.getAttribute("data-precedence"), o = n.get(d) || l, o === l && n.set(null, s), n.set(d, s), this.count++, l = Iu.bind(this), s.addEventListener("load", l), s.addEventListener("error", l), o ? o.parentNode.insertBefore(s, o.nextSibling) : (t = t.nodeType === 9 ? t.head : t, t.insertBefore(s, t.firstChild)), e.state.loading |= 4
        }
    }
    var _i = {
        $$typeof: Q,
        Provider: null,
        Consumer: null,
        _currentValue: it,
        _currentValue2: it,
        _threadCount: 0
    };

    function Ig(t, e, n, l, s, o, d, v, R) {
        this.tag = 1, this.containerInfo = t, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = ws(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = ws(0), this.hiddenUpdates = ws(null), this.identifierPrefix = l, this.onUncaughtError = s, this.onCaughtError = o, this.onRecoverableError = d, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = R, this.incompleteTransitions = new Map
    }

    function ym(t, e, n, l, s, o, d, v, R, L, j, G) {
        return t = new Ig(t, e, n, d, R, L, j, G, v), e = 1, o === !0 && (e |= 24), o = xe(3, null, null, e), t.current = o, o.stateNode = t, e = yr(), e.refCount++, t.pooledCache = e, e.refCount++, o.memoizedState = {
            element: l,
            isDehydrated: n,
            cache: e
        }, Sr(o), t
    }

    function pm(t) {
        return t ? (t = Wa, t) : Wa
    }

    function vm(t, e, n, l, s, o) {
        s = pm(s), l.context === null ? l.context = s : l.pendingContext = s, l = Nn(e), l.payload = {
            element: n
        }, o = o === void 0 ? null : o, o !== null && (l.callback = o), n = Bn(t, l, e), n !== null && (Se(n, t, e), $l(n, t, e))
    }

    function gm(t, e) {
        if (t = t.memoizedState, t !== null && t.dehydrated !== null) {
            var n = t.retryLane;
            t.retryLane = n !== 0 && n < e ? n : e
        }
    }

    function Ho(t, e) {
        gm(t, e), (t = t.alternate) && gm(t, e)
    }

    function Sm(t) {
        if (t.tag === 13 || t.tag === 31) {
            var e = ma(t, 67108864);
            e !== null && Se(e, t, 67108864), Ho(t, 67108864)
        }
    }

    function bm(t) {
        if (t.tag === 13 || t.tag === 31) {
            var e = we();
            e = Ds(e);
            var n = ma(t, e);
            n !== null && Se(n, t, e), Ho(t, e)
        }
    }
    var ts = !0;

    function Wg(t, e, n, l) {
        var s = B.T;
        B.T = null;
        var o = K.p;
        try {
            K.p = 2, qo(t, e, n, l)
        } finally {
            K.p = o, B.T = s
        }
    }

    function $g(t, e, n, l) {
        var s = B.T;
        B.T = null;
        var o = K.p;
        try {
            K.p = 8, qo(t, e, n, l)
        } finally {
            K.p = o, B.T = s
        }
    }

    function qo(t, e, n, l) {
        if (ts) {
            var s = Yo(l);
            if (s === null) Ao(t, e, l, es, n), Em(t, l);
            else if (e0(s, t, e, n, l)) l.stopPropagation();
            else if (Em(t, l), e & 4 && -1 < t0.indexOf(t)) {
                for (; s !== null;) {
                    var o = Ga(s);
                    if (o !== null) switch (o.tag) {
                        case 3:
                            if (o = o.stateNode, o.current.memoizedState.isDehydrated) {
                                var d = oa(o.pendingLanes);
                                if (d !== 0) {
                                    var v = o;
                                    for (v.pendingLanes |= 2, v.entangledLanes |= 2; d;) {
                                        var R = 1 << 31 - Te(d);
                                        v.entanglements[1] |= R, d &= ~R
                                    }
                                    Ie(o), (Tt & 6) === 0 && (ju = oe() + 500, yi(0))
                                }
                            }
                            break;
                        case 31:
                        case 13:
                            v = ma(o, 2), v !== null && Se(v, o, 2), qu(), Ho(o, 2)
                    }
                    if (o = Yo(l), o === null && Ao(t, e, l, es, n), o === s) break;
                    s = o
                }
                s !== null && l.stopPropagation()
            } else Ao(t, e, l, null, n)
        }
    }

    function Yo(t) {
        return t = Gs(t), Go(t)
    }
    var es = null;

    function Go(t) {
        if (es = null, t = Ya(t), t !== null) {
            var e = f(t);
            if (e === null) t = null;
            else {
                var n = e.tag;
                if (n === 13) {
                    if (t = h(e), t !== null) return t;
                    t = null
                } else if (n === 31) {
                    if (t = y(e), t !== null) return t;
                    t = null
                } else if (n === 3) {
                    if (e.stateNode.current.memoizedState.isDehydrated) return e.tag === 3 ? e.stateNode.containerInfo : null;
                    t = null
                } else e !== t && (t = null)
            }
        }
        return es = t, null
    }

    function _m(t) {
        switch (t) {
            case "beforetoggle":
            case "cancel":
            case "click":
            case "close":
            case "contextmenu":
            case "copy":
            case "cut":
            case "auxclick":
            case "dblclick":
            case "dragend":
            case "dragstart":
            case "drop":
            case "focusin":
            case "focusout":
            case "input":
            case "invalid":
            case "keydown":
            case "keypress":
            case "keyup":
            case "mousedown":
            case "mouseup":
            case "paste":
            case "pause":
            case "play":
            case "pointercancel":
            case "pointerdown":
            case "pointerup":
            case "ratechange":
            case "reset":
            case "resize":
            case "seeked":
            case "submit":
            case "toggle":
            case "touchcancel":
            case "touchend":
            case "touchstart":
            case "volumechange":
            case "change":
            case "selectionchange":
            case "textInput":
            case "compositionstart":
            case "compositionend":
            case "compositionupdate":
            case "beforeblur":
            case "afterblur":
            case "beforeinput":
            case "blur":
            case "fullscreenchange":
            case "focus":
            case "hashchange":
            case "popstate":
            case "select":
            case "selectstart":
                return 2;
            case "drag":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "mousemove":
            case "mouseout":
            case "mouseover":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "scroll":
            case "touchmove":
            case "wheel":
            case "mouseenter":
            case "mouseleave":
            case "pointerenter":
            case "pointerleave":
                return 8;
            case "message":
                switch (Nt()) {
                    case ae:
                        return 2;
                    case Je:
                        return 8;
                    case Ha:
                    case Yp:
                        return 32;
                    case Cc:
                        return 268435456;
                    default:
                        return 32
                }
            default:
                return 32
        }
    }
    var Xo = !1,
        Jn = null,
        kn = null,
        Pn = null,
        Ei = new Map,
        Ri = new Map,
        Fn = [],
        t0 = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");

    function Em(t, e) {
        switch (t) {
            case "focusin":
            case "focusout":
                Jn = null;
                break;
            case "dragenter":
            case "dragleave":
                kn = null;
                break;
            case "mouseover":
            case "mouseout":
                Pn = null;
                break;
            case "pointerover":
            case "pointerout":
                Ei.delete(e.pointerId);
                break;
            case "gotpointercapture":
            case "lostpointercapture":
                Ri.delete(e.pointerId)
        }
    }

    function Ti(t, e, n, l, s, o) {
        return t === null || t.nativeEvent !== o ? (t = {
            blockedOn: e,
            domEventName: n,
            eventSystemFlags: l,
            nativeEvent: o,
            targetContainers: [s]
        }, e !== null && (e = Ga(e), e !== null && Sm(e)), t) : (t.eventSystemFlags |= l, e = t.targetContainers, s !== null && e.indexOf(s) === -1 && e.push(s), t)
    }

    function e0(t, e, n, l, s) {
        switch (e) {
            case "focusin":
                return Jn = Ti(Jn, t, e, n, l, s), !0;
            case "dragenter":
                return kn = Ti(kn, t, e, n, l, s), !0;
            case "mouseover":
                return Pn = Ti(Pn, t, e, n, l, s), !0;
            case "pointerover":
                var o = s.pointerId;
                return Ei.set(o, Ti(Ei.get(o) || null, t, e, n, l, s)), !0;
            case "gotpointercapture":
                return o = s.pointerId, Ri.set(o, Ti(Ri.get(o) || null, t, e, n, l, s)), !0
        }
        return !1
    }

    function Rm(t) {
        var e = Ya(t.target);
        if (e !== null) {
            var n = f(e);
            if (n !== null) {
                if (e = n.tag, e === 13) {
                    if (e = h(n), e !== null) {
                        t.blockedOn = e, Bc(t.priority, function() {
                            bm(n)
                        });
                        return
                    }
                } else if (e === 31) {
                    if (e = y(n), e !== null) {
                        t.blockedOn = e, Bc(t.priority, function() {
                            bm(n)
                        });
                        return
                    }
                } else if (e === 3 && n.stateNode.current.memoizedState.isDehydrated) {
                    t.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                    return
                }
            }
        }
        t.blockedOn = null
    }

    function ns(t) {
        if (t.blockedOn !== null) return !1;
        for (var e = t.targetContainers; 0 < e.length;) {
            var n = Yo(t.nativeEvent);
            if (n === null) {
                n = t.nativeEvent;
                var l = new n.constructor(n.type, n);
                Ys = l, n.target.dispatchEvent(l), Ys = null
            } else return e = Ga(n), e !== null && Sm(e), t.blockedOn = n, !1;
            e.shift()
        }
        return !0
    }

    function Tm(t, e, n) {
        ns(t) && n.delete(e)
    }

    function n0() {
        Xo = !1, Jn !== null && ns(Jn) && (Jn = null), kn !== null && ns(kn) && (kn = null), Pn !== null && ns(Pn) && (Pn = null), Ei.forEach(Tm), Ri.forEach(Tm)
    }

    function as(t, e) {
        t.blockedOn === e && (t.blockedOn = null, Xo || (Xo = !0, a.unstable_scheduleCallback(a.unstable_NormalPriority, n0)))
    }
    var ls = null;

    function Am(t) {
        ls !== t && (ls = t, a.unstable_scheduleCallback(a.unstable_NormalPriority, function() {
            ls === t && (ls = null);
            for (var e = 0; e < t.length; e += 3) {
                var n = t[e],
                    l = t[e + 1],
                    s = t[e + 2];
                if (typeof l != "function") {
                    if (Go(l || n) === null) continue;
                    break
                }
                var o = Ga(n);
                o !== null && (t.splice(e, 3), e -= 3, qr(o, {
                    pending: !0,
                    data: s,
                    method: n.method,
                    action: l
                }, l, s))
            }
        }))
    }

    function El(t) {
        function e(R) {
            return as(R, t)
        }
        Jn !== null && as(Jn, t), kn !== null && as(kn, t), Pn !== null && as(Pn, t), Ei.forEach(e), Ri.forEach(e);
        for (var n = 0; n < Fn.length; n++) {
            var l = Fn[n];
            l.blockedOn === t && (l.blockedOn = null)
        }
        for (; 0 < Fn.length && (n = Fn[0], n.blockedOn === null);) Rm(n), n.blockedOn === null && Fn.shift();
        if (n = (t.ownerDocument || t).$$reactFormReplay, n != null)
            for (l = 0; l < n.length; l += 3) {
                var s = n[l],
                    o = n[l + 1],
                    d = s[he] || null;
                if (typeof o == "function") d || Am(n);
                else if (d) {
                    var v = null;
                    if (o && o.hasAttribute("formAction")) {
                        if (s = o, d = o[he] || null) v = d.formAction;
                        else if (Go(s) !== null) continue
                    } else v = d.action;
                    typeof v == "function" ? n[l + 1] = v : (n.splice(l, 3), l -= 3), Am(n)
                }
            }
    }

    function xm() {
        function t(o) {
            o.canIntercept && o.info === "react-transition" && o.intercept({
                handler: function() {
                    return new Promise(function(d) {
                        return s = d
                    })
                },
                focusReset: "manual",
                scroll: "manual"
            })
        }

        function e() {
            s !== null && (s(), s = null), l || setTimeout(n, 20)
        }

        function n() {
            if (!l && !navigation.transition) {
                var o = navigation.currentEntry;
                o && o.url != null && navigation.navigate(o.url, {
                    state: o.getState(),
                    info: "react-transition",
                    history: "replace"
                })
            }
        }
        if (typeof navigation == "object") {
            var l = !1,
                s = null;
            return navigation.addEventListener("navigate", t), navigation.addEventListener("navigatesuccess", e), navigation.addEventListener("navigateerror", e), setTimeout(n, 100),
                function() {
                    l = !0, navigation.removeEventListener("navigate", t), navigation.removeEventListener("navigatesuccess", e), navigation.removeEventListener("navigateerror", e), s !== null && (s(), s = null)
                }
        }
    }

    function Vo(t) {
        this._internalRoot = t
    }
    is.prototype.render = Vo.prototype.render = function(t) {
        var e = this._internalRoot;
        if (e === null) throw Error(r(409));
        var n = e.current,
            l = we();
        vm(n, l, t, e, null, null)
    }, is.prototype.unmount = Vo.prototype.unmount = function() {
        var t = this._internalRoot;
        if (t !== null) {
            this._internalRoot = null;
            var e = t.containerInfo;
            vm(t.current, 2, null, t, null, null), qu(), e[qa] = null
        }
    };

    function is(t) {
        this._internalRoot = t
    }
    is.prototype.unstable_scheduleHydration = function(t) {
        if (t) {
            var e = Nc();
            t = {
                blockedOn: null,
                target: t,
                priority: e
            };
            for (var n = 0; n < Fn.length && e !== 0 && e < Fn[n].priority; n++);
            Fn.splice(n, 0, t), n === 0 && Rm(t)
        }
    };
    var Mm = i.version;
    if (Mm !== "19.2.5") throw Error(r(527, Mm, "19.2.5"));
    K.findDOMNode = function(t) {
        var e = t._reactInternals;
        if (e === void 0) throw typeof t.render == "function" ? Error(r(188)) : (t = Object.keys(t).join(","), Error(r(268, t)));
        return t = m(e), t = t !== null ? S(t) : null, t = t === null ? null : t.stateNode, t
    };
    var a0 = {
        bundleType: 0,
        version: "19.2.5",
        rendererPackageName: "react-dom",
        currentDispatcherRef: B,
        reconcilerVersion: "19.2.5"
    };
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
        var us = __REACT_DEVTOOLS_GLOBAL_HOOK__;
        if (!us.isDisabled && us.supportsFiber) try {
            Ll = us.inject(a0), Re = us
        } catch {}
    }
    return xi.createRoot = function(t, e) {
        if (!c(t)) throw Error(r(299));
        var n = !1,
            l = "",
            s = Ud,
            o = Nd,
            d = Bd;
        return e != null && (e.unstable_strictMode === !0 && (n = !0), e.identifierPrefix !== void 0 && (l = e.identifierPrefix), e.onUncaughtError !== void 0 && (s = e.onUncaughtError), e.onCaughtError !== void 0 && (o = e.onCaughtError), e.onRecoverableError !== void 0 && (d = e.onRecoverableError)), e = ym(t, 1, !1, null, null, n, l, null, s, o, d, xm), t[qa] = e.current, To(t), new Vo(e)
    }, xi.hydrateRoot = function(t, e, n) {
        if (!c(t)) throw Error(r(299));
        var l = !1,
            s = "",
            o = Ud,
            d = Nd,
            v = Bd,
            R = null;
        return n != null && (n.unstable_strictMode === !0 && (l = !0), n.identifierPrefix !== void 0 && (s = n.identifierPrefix), n.onUncaughtError !== void 0 && (o = n.onUncaughtError), n.onCaughtError !== void 0 && (d = n.onCaughtError), n.onRecoverableError !== void 0 && (v = n.onRecoverableError), n.formState !== void 0 && (R = n.formState)), e = ym(t, 1, !0, e, n ? ? null, l, s, R, o, d, v, xm), e.context = pm(null), n = e.current, l = we(), l = Ds(l), s = Nn(l), s.callback = null, Bn(n, s, l), n = l, e.current.lanes = n, Nl(e, n), Ie(e), t[qa] = e.current, To(t), new is(e)
    }, xi.version = "19.2.5", xi
}
var jm;

function h0() {
    if (jm) return Ko.exports;
    jm = 1;

    function a() {
        if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
            __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(a)
        } catch (i) {
            console.error(i)
        }
    }
    return a(), Ko.exports = d0(), Ko.exports
}
var m0 = h0(),
    y0 = "__TSS_CONTEXT",
    fc = Symbol.for("TSS_SERVER_FUNCTION"),
    p0 = "application/x-tss-framed",
    En = {
        JSON: 0,
        CHUNK: 1,
        END: 2,
        ERROR: 3
    },
    v0 = /;\s*v=(\d+)/;

function g0(a) {
    const i = a.match(v0);
    return i ? parseInt(i[1], 10) : void 0
}

function S0(a) {
    const i = g0(a);
    if (i !== void 0 && i !== 1) throw new Error(`Incompatible framed protocol version: server=${i}, client=1. Please ensure client and server are using compatible versions.`)
}
var My = () => window.__TSS_START_OPTIONS__,
    Oy = !1;

function Bi(a) {
    return a[a.length - 1]
}

function b0(a) {
    return typeof a == "function"
}

function ta(a, i) {
    return b0(a) ? a(i) : a
}
var _0 = Object.prototype.hasOwnProperty,
    Hm = Object.prototype.propertyIsEnumerable,
    E0 = () => Object.create(null),
    Ma = (a, i) => Oa(a, i, E0);

function Oa(a, i, u = () => ({}), r = 0) {
    if (a === i) return a;
    if (r > 500) return i;
    const c = i,
        f = Gm(a) && Gm(c);
    if (!f && !(zl(a) && zl(c))) return c;
    const h = f ? a : qm(a);
    if (!h) return c;
    const y = f ? c : qm(c);
    if (!y) return c;
    const p = h.length,
        m = y.length,
        S = f ? new Array(m) : u();
    let g = 0;
    for (let _ = 0; _ < m; _++) {
        const E = f ? _ : y[_],
            O = a[E],
            w = c[E];
        if (O === w) {
            S[E] = O, (f ? _ < p : _0.call(a, E)) && g++;
            continue
        }
        if (O === null || w === null || typeof O != "object" || typeof w != "object") {
            S[E] = w;
            continue
        }
        const A = Oa(O, w, u, r + 1);
        S[E] = A, A === O && g++
    }
    return p === m && g === p ? a : S
}

function qm(a) {
    const i = Object.getOwnPropertyNames(a);
    for (const c of i)
        if (!Hm.call(a, c)) return !1;
    const u = Object.getOwnPropertySymbols(a);
    if (u.length === 0) return i;
    const r = i;
    for (const c of u) {
        if (!Hm.call(a, c)) return !1;
        r.push(c)
    }
    return r
}

function zl(a) {
    if (!Ym(a)) return !1;
    const i = a.constructor;
    if (typeof i > "u") return !0;
    const u = i.prototype;
    return !(!Ym(u) || !u.hasOwnProperty("isPrototypeOf"))
}

function Ym(a) {
    return Object.prototype.toString.call(a) === "[object Object]"
}

function Gm(a) {
    return Array.isArray(a) && a.length === Object.keys(a).length
}

function be(a, i, u) {
    if (a === i) return !0;
    if (typeof a != typeof i) return !1;
    if (Array.isArray(a) && Array.isArray(i)) {
        if (a.length !== i.length) return !1;
        for (let r = 0, c = a.length; r < c; r++)
            if (!be(a[r], i[r], u)) return !1;
        return !0
    }
    if (zl(a) && zl(i)) {
        const r = u ? .ignoreUndefined ? ? !0;
        if (u ? .partial) {
            for (const h in i)
                if ((!r || i[h] !== void 0) && !be(a[h], i[h], u)) return !1;
            return !0
        }
        let c = 0;
        if (!r) c = Object.keys(a).length;
        else
            for (const h in a) a[h] !== void 0 && c++;
        let f = 0;
        for (const h in i)
            if ((!r || i[h] !== void 0) && (f++, f > c || !be(a[h], i[h], u))) return !1;
        return c === f
    }
    return !1
}

function Ua(a) {
    let i, u;
    const r = new Promise((c, f) => {
        i = c, u = f
    });
    return r.status = "pending", r.resolve = c => {
        r.status = "resolved", r.value = c, i(c), a ? .(c)
    }, r.reject = c => {
        r.status = "rejected", u(c)
    }, r
}

function R0(a) {
    return typeof a ? .message != "string" ? !1 : a.message.startsWith("Failed to fetch dynamically imported module") || a.message.startsWith("error loading dynamically imported module") || a.message.startsWith("Importing a module script failed")
}

function ji(a) {
    return !!(a && typeof a == "object" && typeof a.then == "function")
}

function T0(a) {
    return a.replace(/[\x00-\x1f\x7f]/g, "")
}

function Xm(a) {
    let i;
    try {
        i = decodeURI(a)
    } catch {
        i = a.replaceAll(/%[0-9A-F]{2}/gi, u => {
            try {
                return decodeURI(u)
            } catch {
                return u
            }
        })
    }
    return T0(i)
}
var A0 = ["http:", "https:", "mailto:", "tel:"];

function ys(a, i) {
    if (!a) return !1;
    try {
        const u = new URL(a);
        return !i.has(u.protocol)
    } catch {
        return !1
    }
}
var x0 = {
        "&": "\\u0026",
        ">": "\\u003e",
        "<": "\\u003c",
        "\u2028": "\\u2028",
        "\u2029": "\\u2029"
    },
    M0 = /[&><\u2028\u2029]/g;

function O0(a) {
    return a.replace(M0, i => x0[i])
}

function Mi(a) {
    if (!a) return {
        path: a,
        handledProtocolRelativeURL: !1
    };
    if (!/[%\\\x00-\x1f\x7f]/.test(a) && !a.startsWith("//")) return {
        path: a,
        handledProtocolRelativeURL: !1
    };
    const i = /%25|%5C/gi;
    let u = 0,
        r = "",
        c;
    for (;
        (c = i.exec(a)) !== null;) r += Xm(a.slice(u, c.index)) + c[0], u = i.lastIndex;
    r = r + Xm(u ? a.slice(u) : a);
    let f = !1;
    return r.startsWith("//") && (f = !0, r = "/" + r.replace(/^\/+/, "")), {
        path: r,
        handledProtocolRelativeURL: f
    }
}

function z0(a) {
    return /\s|[^\u0000-\u007F]/.test(a) ? a.replace(/\s|[^\u0000-\u007F]/gu, encodeURIComponent) : a
}

function C0(a, i) {
    if (a === i) return !0;
    if (a.length !== i.length) return !1;
    for (let u = 0; u < a.length; u++)
        if (a[u] !== i[u]) return !1;
    return !0
}

function Ee() {
    throw new Error("Invariant failed")
}

function Hi(a) {
    const i = new Map;
    let u, r;
    const c = f => {
        f.next && (f.prev ? (f.prev.next = f.next, f.next.prev = f.prev, f.next = void 0, r && (r.next = f, f.prev = r)) : (f.next.prev = void 0, u = f.next, f.next = void 0, r && (f.prev = r, r.next = f)), r = f)
    };
    return {
        get(f) {
            const h = i.get(f);
            if (h) return c(h), h.value
        },
        set(f, h) {
            if (i.size >= a && u) {
                const p = u;
                i.delete(p.key), p.next && (u = p.next, p.next.prev = void 0), p === r && (r = void 0)
            }
            const y = i.get(f);
            if (y) y.value = h, c(y);
            else {
                const p = {
                    key: f,
                    value: h,
                    prev: r
                };
                r && (r.next = p), r = p, u || (u = p), i.set(f, p)
            }
        },
        clear() {
            i.clear(), u = void 0, r = void 0
        }
    }
}
var za = 4,
    zy = 5;

function w0(a) {
    const i = a.indexOf("{");
    if (i === -1) return null;
    const u = a.indexOf("}", i);
    return u === -1 || i + 1 >= a.length ? null : [i, u]
}

function Sc(a, i, u = new Uint16Array(6)) {
    const r = a.indexOf("/", i),
        c = r === -1 ? a.length : r,
        f = a.substring(i, c);
    if (!f || !f.includes("$")) return u[0] = 0, u[1] = i, u[2] = i, u[3] = c, u[4] = c, u[5] = c, u;
    if (f === "$") {
        const y = a.length;
        return u[0] = 2, u[1] = i, u[2] = i, u[3] = y, u[4] = y, u[5] = y, u
    }
    if (f.charCodeAt(0) === 36) return u[0] = 1, u[1] = i, u[2] = i + 1, u[3] = c, u[4] = c, u[5] = c, u;
    const h = w0(f);
    if (h) {
        const [y, p] = h, m = f.charCodeAt(y + 1);
        if (m === 45) {
            if (y + 2 < f.length && f.charCodeAt(y + 2) === 36) {
                const S = y + 3,
                    g = p;
                if (S < g) return u[0] = 3, u[1] = i + y, u[2] = i + S, u[3] = i + g, u[4] = i + p + 1, u[5] = c, u
            }
        } else if (m === 36) {
            const S = y + 1,
                g = y + 2;
            return g === p ? (u[0] = 2, u[1] = i + y, u[2] = i + S, u[3] = i + g, u[4] = i + p + 1, u[5] = a.length, u) : (u[0] = 1, u[1] = i + y, u[2] = i + g, u[3] = i + p, u[4] = i + p + 1, u[5] = c, u)
        }
    }
    return u[0] = 0, u[1] = i, u[2] = i, u[3] = c, u[4] = c, u[5] = c, u
}

function Es(a, i, u, r, c, f, h) {
    h ? .(u);
    let y = r; {
        const p = u.fullPath ? ? u.from,
            m = p.length,
            S = u.options ? .caseSensitive ? ? a,
            g = !!(u.options ? .params ? .parse && u.options ? .skipRouteOnParseError ? .params);
        for (; y < m;) {
            const E = Sc(p, y, i);
            let O;
            const w = y,
                A = E[5];
            switch (y = A + 1, f++, E[0]) {
                case 0:
                    {
                        const z = p.substring(E[2], E[3]);
                        if (S) {
                            const X = c.static ? .get(z);
                            if (X) O = X;
                            else {
                                c.static ? ? = new Map;
                                const Q = Ca(u.fullPath ? ? u.from);
                                Q.parent = c, Q.depth = f, O = Q, c.static.set(z, Q)
                            }
                        } else {
                            const X = z.toLowerCase(),
                                Q = c.staticInsensitive ? .get(X);
                            if (Q) O = Q;
                            else {
                                c.staticInsensitive ? ? = new Map;
                                const H = Ca(u.fullPath ? ? u.from);
                                H.parent = c, H.depth = f, O = H, c.staticInsensitive.set(X, H)
                            }
                        }
                        break
                    }
                case 1:
                    {
                        const z = p.substring(w, E[1]),
                            X = p.substring(E[4], A),
                            Q = S && !!(z || X),
                            H = z ? Q ? z : z.toLowerCase() : void 0,
                            W = X ? Q ? X : X.toLowerCase() : void 0,
                            F = !g && c.dynamic ? .find(V => !V.skipOnParamError && V.caseSensitive === Q && V.prefix === H && V.suffix === W);
                        if (F) O = F;
                        else {
                            const V = Io(1, u.fullPath ? ? u.from, Q, H, W);
                            O = V, V.depth = f, V.parent = c, c.dynamic ? ? = [], c.dynamic.push(V)
                        }
                        break
                    }
                case 3:
                    {
                        const z = p.substring(w, E[1]),
                            X = p.substring(E[4], A),
                            Q = S && !!(z || X),
                            H = z ? Q ? z : z.toLowerCase() : void 0,
                            W = X ? Q ? X : X.toLowerCase() : void 0,
                            F = !g && c.optional ? .find(V => !V.skipOnParamError && V.caseSensitive === Q && V.prefix === H && V.suffix === W);
                        if (F) O = F;
                        else {
                            const V = Io(3, u.fullPath ? ? u.from, Q, H, W);
                            O = V, V.parent = c, V.depth = f, c.optional ? ? = [], c.optional.push(V)
                        }
                        break
                    }
                case 2:
                    {
                        const z = p.substring(w, E[1]),
                            X = p.substring(E[4], A),
                            Q = S && !!(z || X),
                            H = z ? Q ? z : z.toLowerCase() : void 0,
                            W = X ? Q ? X : X.toLowerCase() : void 0,
                            F = Io(2, u.fullPath ? ? u.from, Q, H, W);O = F,
                        F.parent = c,
                        F.depth = f,
                        c.wildcard ? ? = [],
                        c.wildcard.push(F)
                    }
            }
            c = O
        }
        if (g && u.children && !u.isRoot && u.id && u.id.charCodeAt(u.id.lastIndexOf("/") + 1) === 95) {
            const E = Ca(u.fullPath ? ? u.from);
            E.kind = zy, E.parent = c, f++, E.depth = f, c.pathless ? ? = [], c.pathless.push(E), c = E
        }
        const _ = (u.path || !u.children) && !u.isRoot;
        if (_ && p.endsWith("/")) {
            const E = Ca(u.fullPath ? ? u.from);
            E.kind = za, E.parent = c, f++, E.depth = f, c.index = E, c = E
        }
        c.parse = u.options ? .params ? .parse ? ? null, c.skipOnParamError = g, c.parsingPriority = u.options ? .skipRouteOnParseError ? .priority ? ? 0, _ && !c.route && (c.route = u, c.fullPath = u.fullPath ? ? u.from)
    }
    if (u.children)
        for (const p of u.children) Es(a, i, p, y, c, f, h)
}

function Fo(a, i) {
    if (a.skipOnParamError && !i.skipOnParamError) return -1;
    if (!a.skipOnParamError && i.skipOnParamError) return 1;
    if (a.skipOnParamError && i.skipOnParamError && (a.parsingPriority || i.parsingPriority)) return i.parsingPriority - a.parsingPriority;
    if (a.prefix && i.prefix && a.prefix !== i.prefix) {
        if (a.prefix.startsWith(i.prefix)) return -1;
        if (i.prefix.startsWith(a.prefix)) return 1
    }
    if (a.suffix && i.suffix && a.suffix !== i.suffix) {
        if (a.suffix.endsWith(i.suffix)) return -1;
        if (i.suffix.endsWith(a.suffix)) return 1
    }
    return a.prefix && !i.prefix ? -1 : !a.prefix && i.prefix ? 1 : a.suffix && !i.suffix ? -1 : !a.suffix && i.suffix ? 1 : a.caseSensitive && !i.caseSensitive ? -1 : !a.caseSensitive && i.caseSensitive ? 1 : 0
}

function Wn(a) {
    if (a.pathless)
        for (const i of a.pathless) Wn(i);
    if (a.static)
        for (const i of a.static.values()) Wn(i);
    if (a.staticInsensitive)
        for (const i of a.staticInsensitive.values()) Wn(i);
    if (a.dynamic ? .length) {
        a.dynamic.sort(Fo);
        for (const i of a.dynamic) Wn(i)
    }
    if (a.optional ? .length) {
        a.optional.sort(Fo);
        for (const i of a.optional) Wn(i)
    }
    if (a.wildcard ? .length) {
        a.wildcard.sort(Fo);
        for (const i of a.wildcard) Wn(i)
    }
}

function Ca(a) {
    return {
        kind: 0,
        depth: 0,
        pathless: null,
        index: null,
        static: null,
        staticInsensitive: null,
        dynamic: null,
        optional: null,
        wildcard: null,
        route: null,
        fullPath: a,
        parent: null,
        parse: null,
        skipOnParamError: !1,
        parsingPriority: 0
    }
}

function Io(a, i, u, r, c) {
    return {
        kind: a,
        depth: 0,
        pathless: null,
        index: null,
        static: null,
        staticInsensitive: null,
        dynamic: null,
        optional: null,
        wildcard: null,
        route: null,
        fullPath: i,
        parent: null,
        parse: null,
        skipOnParamError: !1,
        parsingPriority: 0,
        caseSensitive: u,
        prefix: r,
        suffix: c
    }
}

function D0(a, i) {
    const u = Ca("/"),
        r = new Uint16Array(6);
    for (const c of a) Es(!1, r, c, 1, u, 0);
    Wn(u), i.masksTree = u, i.flatCache = Hi(1e3)
}

function L0(a, i) {
    a || = "/";
    const u = i.flatCache.get(a);
    if (u) return u;
    const r = bc(a, i.masksTree);
    return i.flatCache.set(a, r), r
}

function U0(a, i, u, r, c) {
    a || = "/", r || = "/";
    const f = i ? `case\0${a}` : a;
    let h = c.singleCache.get(f);
    return h || (h = Ca("/"), Es(i, new Uint16Array(6), {
        from: a
    }, 1, h, 0), c.singleCache.set(f, h)), bc(r, h, u)
}

function N0(a, i, u = !1) {
    const r = u ? a : `nofuzz\0${a}`,
        c = i.matchCache.get(r);
    if (c !== void 0) return c;
    a || = "/";
    let f;
    try {
        f = bc(a, i.segmentTree, u)
    } catch (h) {
        if (h instanceof URIError) f = null;
        else throw h
    }
    return f && (f.branch = H0(f.route)), i.matchCache.set(r, f), f
}

function B0(a) {
    return a === "/" ? a : a.replace(/\/{1,}$/, "")
}

function j0(a, i = !1, u) {
    const r = Ca(a.fullPath),
        c = new Uint16Array(6),
        f = {},
        h = {};
    let y = 0;
    return Es(i, c, a, 1, r, 0, p => {
        if (u ? .(p, y), p.id in f && Ee(), f[p.id] = p, y !== 0 && p.path) {
            const m = B0(p.fullPath);
            (!h[m] || p.fullPath.endsWith("/")) && (h[m] = p)
        }
        y++
    }), Wn(r), {
        processedTree: {
            segmentTree: r,
            singleCache: Hi(1e3),
            matchCache: Hi(1e3),
            flatCache: null,
            masksTree: null
        },
        routesById: f,
        routesByPath: h
    }
}

function bc(a, i, u = !1) {
    const r = a.split("/"),
        c = Y0(a, r, i, u);
    if (!c) return null;
    const [f] = Cy(a, r, c);
    return {
        route: c.node.route,
        rawParams: f,
        parsedParams: c.parsedParams
    }
}

function Cy(a, i, u) {
    const r = q0(u.node);
    let c = null;
    const f = Object.create(null);
    let h = u.extract ? .part ? ? 0,
        y = u.extract ? .node ? ? 0,
        p = u.extract ? .path ? ? 0,
        m = u.extract ? .segment ? ? 0;
    for (; y < r.length; h++, y++, p++, m++) {
        const S = r[y];
        if (S.kind === za) break;
        if (S.kind === zy) {
            m--, h--, p--;
            continue
        }
        const g = i[h],
            _ = p;
        if (g && (p += g.length), S.kind === 1) {
            c ? ? = u.node.fullPath.split("/");
            const E = c[m],
                O = S.prefix ? .length ? ? 0;
            if (E.charCodeAt(O) === 123) {
                const w = S.suffix ? .length ? ? 0,
                    A = E.substring(O + 2, E.length - w - 1),
                    z = g.substring(O, g.length - w);
                f[A] = decodeURIComponent(z)
            } else {
                const w = E.substring(1);
                f[w] = decodeURIComponent(g)
            }
        } else if (S.kind === 3) {
            if (u.skipped & 1 << y) {
                h--, p = _ - 1;
                continue
            }
            c ? ? = u.node.fullPath.split("/");
            const E = c[m],
                O = S.prefix ? .length ? ? 0,
                w = S.suffix ? .length ? ? 0,
                A = E.substring(O + 3, E.length - w - 1),
                z = S.suffix || S.prefix ? g.substring(O, g.length - w) : g;
            z && (f[A] = decodeURIComponent(z))
        } else if (S.kind === 2) {
            const E = S,
                O = a.substring(_ + (E.prefix ? .length ? ? 0), a.length - (E.suffix ? .length ? ? 0)),
                w = decodeURIComponent(O);
            f["*"] = w, f._splat = w;
            break
        }
    }
    return u.rawParams && Object.assign(f, u.rawParams), [f, {
        part: h,
        node: y,
        path: p,
        segment: m
    }]
}

function H0(a) {
    const i = [a];
    for (; a.parentRoute;) a = a.parentRoute, i.push(a);
    return i.reverse(), i
}

function q0(a) {
    const i = Array(a.depth + 1);
    do i[a.depth] = a, a = a.parent; while (a);
    return i
}

function Y0(a, i, u, r) {
    if (a === "/" && u.index) return {
        node: u.index,
        skipped: 0
    };
    const c = !Bi(i),
        f = c && a !== "/",
        h = i.length - (c ? 1 : 0),
        y = [{
            node: u,
            index: 1,
            skipped: 0,
            depth: 1,
            statics: 1,
            dynamics: 0,
            optionals: 0
        }];
    let p = null,
        m = null,
        S = null;
    for (; y.length;) {
        const g = y.pop(),
            {
                node: _,
                index: E,
                skipped: O,
                depth: w,
                statics: A,
                dynamics: z,
                optionals: X
            } = g;
        let {
            extract: Q,
            rawParams: H,
            parsedParams: W
        } = g;
        if (_.skipOnParamError) {
            if (!Wo(a, i, g)) continue;
            H = g.rawParams, Q = g.extract, W = g.parsedParams
        }
        r && _.route && _.kind !== za && Oi(m, g) && (m = g);
        const F = E === h;
        if (F && (_.route && !f && Oi(S, g) && (S = g), !_.optional && !_.wildcard && !_.index && !_.pathless)) continue;
        const V = F ? void 0 : i[E];
        let J;
        if (F && _.index) {
            const P = {
                node: _.index,
                index: E,
                skipped: O,
                depth: w + 1,
                statics: A,
                dynamics: z,
                optionals: X,
                extract: Q,
                rawParams: H,
                parsedParams: W
            };
            let ut = !0;
            if (_.index.skipOnParamError && (Wo(a, i, P) || (ut = !1)), ut) {
                if (A === h && !z && !X && !O) return P;
                Oi(S, P) && (S = P)
            }
        }
        if (_.wildcard && Oi(p, g))
            for (const P of _.wildcard) {
                const {
                    prefix: ut,
                    suffix: tt
                } = P;
                if (ut && (F || !(P.caseSensitive ? V : J ? ? = V.toLowerCase()).startsWith(ut))) continue;
                if (tt) {
                    if (F) continue;
                    const vt = i.slice(E).join("/").slice(-tt.length);
                    if ((P.caseSensitive ? vt : vt.toLowerCase()) !== tt) continue
                }
                const dt = {
                    node: P,
                    index: h,
                    skipped: O,
                    depth: w,
                    statics: A,
                    dynamics: z,
                    optionals: X,
                    extract: Q,
                    rawParams: H,
                    parsedParams: W
                };
                if (!(P.skipOnParamError && !Wo(a, i, dt))) {
                    p = dt;
                    break
                }
            }
        if (_.optional) {
            const P = O | 1 << w,
                ut = w + 1;
            for (let tt = _.optional.length - 1; tt >= 0; tt--) {
                const dt = _.optional[tt];
                y.push({
                    node: dt,
                    index: E,
                    skipped: P,
                    depth: ut,
                    statics: A,
                    dynamics: z,
                    optionals: X,
                    extract: Q,
                    rawParams: H,
                    parsedParams: W
                })
            }
            if (!F)
                for (let tt = _.optional.length - 1; tt >= 0; tt--) {
                    const dt = _.optional[tt],
                        {
                            prefix: vt,
                            suffix: Yt
                        } = dt;
                    if (vt || Yt) {
                        const Ot = dt.caseSensitive ? V : J ? ? = V.toLowerCase();
                        if (vt && !Ot.startsWith(vt) || Yt && !Ot.endsWith(Yt)) continue
                    }
                    y.push({
                        node: dt,
                        index: E + 1,
                        skipped: O,
                        depth: ut,
                        statics: A,
                        dynamics: z,
                        optionals: X + 1,
                        extract: Q,
                        rawParams: H,
                        parsedParams: W
                    })
                }
        }
        if (!F && _.dynamic && V)
            for (let P = _.dynamic.length - 1; P >= 0; P--) {
                const ut = _.dynamic[P],
                    {
                        prefix: tt,
                        suffix: dt
                    } = ut;
                if (tt || dt) {
                    const vt = ut.caseSensitive ? V : J ? ? = V.toLowerCase();
                    if (tt && !vt.startsWith(tt) || dt && !vt.endsWith(dt)) continue
                }
                y.push({
                    node: ut,
                    index: E + 1,
                    skipped: O,
                    depth: w + 1,
                    statics: A,
                    dynamics: z + 1,
                    optionals: X,
                    extract: Q,
                    rawParams: H,
                    parsedParams: W
                })
            }
        if (!F && _.staticInsensitive) {
            const P = _.staticInsensitive.get(J ? ? = V.toLowerCase());
            P && y.push({
                node: P,
                index: E + 1,
                skipped: O,
                depth: w + 1,
                statics: A + 1,
                dynamics: z,
                optionals: X,
                extract: Q,
                rawParams: H,
                parsedParams: W
            })
        }
        if (!F && _.static) {
            const P = _.static.get(V);
            P && y.push({
                node: P,
                index: E + 1,
                skipped: O,
                depth: w + 1,
                statics: A + 1,
                dynamics: z,
                optionals: X,
                extract: Q,
                rawParams: H,
                parsedParams: W
            })
        }
        if (_.pathless) {
            const P = w + 1;
            for (let ut = _.pathless.length - 1; ut >= 0; ut--) {
                const tt = _.pathless[ut];
                y.push({
                    node: tt,
                    index: E,
                    skipped: O,
                    depth: P,
                    statics: A,
                    dynamics: z,
                    optionals: X,
                    extract: Q,
                    rawParams: H,
                    parsedParams: W
                })
            }
        }
    }
    if (S && p) return Oi(p, S) ? S : p;
    if (S) return S;
    if (p) return p;
    if (r && m) {
        let g = m.index;
        for (let E = 0; E < m.index; E++) g += i[E].length;
        const _ = g === a.length ? "/" : a.slice(g);
        return m.rawParams ? ? = Object.create(null), m.rawParams["**"] = decodeURIComponent(_), m
    }
    return null
}

function Wo(a, i, u) {
    try {
        const [r, c] = Cy(a, i, u);
        u.rawParams = r, u.extract = c;
        const f = u.node.parse(r);
        return u.parsedParams = Object.assign(Object.create(null), u.parsedParams, f), !0
    } catch {
        return null
    }
}

function Oi(a, i) {
    return a ? i.statics > a.statics || i.statics === a.statics && (i.dynamics > a.dynamics || i.dynamics === a.dynamics && (i.optionals > a.optionals || i.optionals === a.optionals && ((i.node.kind === za) > (a.node.kind === za) || i.node.kind === za == (a.node.kind === za) && i.depth > a.depth))) : !0
}

function cs(a) {
    return _c(a.filter(i => i !== void 0).join("/"))
}

function _c(a) {
    return a.replace(/\/{2,}/g, "/")
}

function wy(a) {
    return a === "/" ? a : a.replace(/^\/{1,}/, "")
}

function na(a) {
    const i = a.length;
    return i > 1 && a[i - 1] === "/" ? a.replace(/\/{1,}$/, "") : a
}

function Dy(a) {
    return na(wy(a))
}

function ps(a, i) {
    return a ? .endsWith("/") && a !== "/" && a !== `${i}/` ? a.slice(0, -1) : a
}

function G0(a, i, u) {
    return ps(a, u) === ps(i, u)
}

function X0({
    base: a,
    to: i,
    trailingSlash: u = "never",
    cache: r
}) {
    const c = i.startsWith("/"),
        f = !c && i === ".";
    let h;
    if (r) {
        h = c ? i : f ? a : a + "\0" + i;
        const g = r.get(h);
        if (g) return g
    }
    let y;
    if (f) y = a.split("/");
    else if (c) y = i.split("/");
    else {
        for (y = a.split("/"); y.length > 1 && Bi(y) === "";) y.pop();
        const g = i.split("/");
        for (let _ = 0, E = g.length; _ < E; _++) {
            const O = g[_];
            O === "" ? _ ? _ === E - 1 && y.push(O) : y = [O] : O === ".." ? y.pop() : O === "." || y.push(O)
        }
    }
    y.length > 1 && (Bi(y) === "" ? u === "never" && y.pop() : u === "always" && y.push(""));
    let p, m = "";
    for (let g = 0; g < y.length; g++) {
        g > 0 && (m += "/");
        const _ = y[g];
        if (!_) continue;
        p = Sc(_, 0, p);
        const E = p[0];
        if (E === 0) {
            m += _;
            continue
        }
        const O = p[5],
            w = _.substring(0, p[1]),
            A = _.substring(p[4], O),
            z = _.substring(p[2], p[3]);
        E === 1 ? m += w || A ? `${w}{$${z}}${A}` : `$${z}` : E === 2 ? m += w || A ? `${w}{$}${A}` : "$" : m += `${w}{-$${z}}${A}`
    }
    m = _c(m);
    const S = m || "/";
    return h && r && r.set(h, S), S
}

function V0(a) {
    const i = new Map(a.map(c => [encodeURIComponent(c), c])),
        u = Array.from(i.keys()).map(c => c.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|"),
        r = new RegExp(u, "g");
    return c => c.replace(r, f => i.get(f) ? ? f)
}

function $o(a, i, u) {
    const r = i[a];
    return typeof r != "string" ? r : a === "_splat" ? /^[a-zA-Z0-9\-._~!/]*$/.test(r) ? r : r.split("/").map(c => Qm(c, u)).join("/") : Qm(r, u)
}

function Vm({
    path: a,
    params: i,
    decoder: u,
    ...r
}) {
    let c = !1;
    const f = Object.create(null);
    if (!a || a === "/") return {
        interpolatedPath: "/",
        usedParams: f,
        isMissingParams: c
    };
    if (!a.includes("$")) return {
        interpolatedPath: a,
        usedParams: f,
        isMissingParams: c
    };
    const h = a.length;
    let y = 0,
        p, m = "";
    for (; y < h;) {
        const S = y;
        p = Sc(a, S, p);
        const g = p[5];
        if (y = g + 1, S === g) continue;
        const _ = p[0];
        if (_ === 0) {
            m += "/" + a.substring(S, g);
            continue
        }
        if (_ === 2) {
            const E = i._splat;
            f._splat = E, f["*"] = E;
            const O = a.substring(S, p[1]),
                w = a.substring(p[4], g);
            if (!E) {
                c = !0, (O || w) && (m += "/" + O + w);
                continue
            }
            const A = $o("_splat", i, u);
            m += "/" + O + A + w;
            continue
        }
        if (_ === 1) {
            const E = a.substring(p[2], p[3]);
            !c && !(E in i) && (c = !0), f[E] = i[E];
            const O = a.substring(S, p[1]),
                w = a.substring(p[4], g),
                A = $o(E, i, u) ? ? "undefined";
            m += "/" + O + A + w;
            continue
        }
        if (_ === 3) {
            const E = a.substring(p[2], p[3]),
                O = i[E];
            if (O == null) continue;
            f[E] = O;
            const w = a.substring(S, p[1]),
                A = a.substring(p[4], g),
                z = $o(E, i, u) ? ? "";
            m += "/" + w + z + A;
            continue
        }
    }
    return a.endsWith("/") && (m += "/"), {
        usedParams: f,
        interpolatedPath: m || "/",
        isMissingParams: c
    }
}

function Qm(a, i) {
    const u = encodeURIComponent(a);
    return i ? .(u) ? ? u
}

function ne(a) {
    return a ? .isNotFound === !0
}

function Q0() {
    try {
        return typeof window < "u" && typeof window.sessionStorage == "object" ? window.sessionStorage : void 0
    } catch {
        return
    }
}
var Z0 = "tsr-scroll-restoration-v1_3";

function K0() {
    const a = Q0();
    if (!a) return null;
    let i = {};
    try {
        const r = JSON.parse(a.getItem("tsr-scroll-restoration-v1_3") || "{}");
        zl(r) && (i = r)
    } catch {}
    return {
        get state() {
            return i
        },
        set: r => {
            i = ta(r, i) || i
        },
        persist: () => {
            try {
                a.setItem(Z0, JSON.stringify(i))
            } catch {}
        }
    }
}
var Zm = K0(),
    J0 = a => a.state.__TSR_key || a.href;

function k0(a) {
    const i = [];
    let u;
    for (; u = a.parentNode;) i.push(`${a.tagName}:nth-child(${Array.prototype.indexOf.call(u.children,a)+1})`), a = u;
    return `${i.reverse().join(" > ")}`.toLowerCase()
}
var ss = !1,
    zi = "window",
    Km = "data-scroll-restoration-id";

function P0(a, i) {
    if (!Zm) return;
    const u = Zm;
    if ((a.options.scrollRestoration ? ? !1) && (a.isScrollRestoring = !0), a.isScrollRestorationSetup || !u) return;
    a.isScrollRestorationSetup = !0, ss = !1;
    const r = a.options.getScrollRestorationKey || J0,
        c = new Map;
    window.history.scrollRestoration = "manual";
    const f = y => {
            if (!(ss || !a.isScrollRestoring))
                if (y.target === document || y.target === window) c.set(zi, {
                    scrollX: window.scrollX || 0,
                    scrollY: window.scrollY || 0
                });
                else {
                    const p = y.target;
                    c.set(p, {
                        scrollX: p.scrollLeft || 0,
                        scrollY: p.scrollTop || 0
                    })
                }
        },
        h = y => {
            if (!a.isScrollRestoring || !y || c.size === 0 || !u) return;
            const p = u.state[y] || = {};
            for (const [m, S] of c) {
                let g;
                if (m === zi) g = zi;
                else if (m.isConnected) {
                    const _ = m.getAttribute(Km);
                    g = _ ? `[${Km}="${_}"]` : k0(m)
                }
                g && (p[g] = S)
            }
        };
    document.addEventListener("scroll", f, !0), a.subscribe("onBeforeLoad", y => {
        h(y.fromLocation ? r(y.fromLocation) : void 0), c.clear()
    }), window.addEventListener("pagehide", () => {
        h(r(a.stores.resolvedLocation.get() ? ? a.stores.location.get())), u.persist()
    }), a.subscribe("onRendered", y => {
        const p = r(y.toLocation),
            m = a.options.scrollRestorationBehavior,
            S = a.options.scrollToTopSelectors;
        if (c.clear(), !a.resetNextScroll) {
            a.resetNextScroll = !0;
            return
        }
        if (!(typeof a.options.scrollRestoration == "function" && !a.options.scrollRestoration({
                location: a.latestLocation
            }))) {
            ss = !0;
            try {
                const g = a.isScrollRestoring ? u.state[p] : void 0;
                let _ = !1;
                if (g)
                    for (const E in g) {
                        const O = g[E];
                        if (!zl(O)) continue;
                        const {
                            scrollX: w,
                            scrollY: A
                        } = O;
                        if (!(!Number.isFinite(w) || !Number.isFinite(A))) {
                            if (E === zi) window.scrollTo({
                                top: A,
                                left: w,
                                behavior: m
                            }), _ = !0;
                            else if (E) {
                                let z;
                                try {
                                    z = document.querySelector(E)
                                } catch {
                                    continue
                                }
                                z && (z.scrollLeft = w, z.scrollTop = A, _ = !0)
                            }
                        }
                    }
                if (!_) {
                    const E = a.history.location.hash.slice(1);
                    if (E) {
                        const O = window.history.state ? .__hashScrollIntoViewOptions ? ? !0;
                        if (O) {
                            const w = document.getElementById(E);
                            w && w.scrollIntoView(O)
                        }
                    } else {
                        const O = {
                            top: 0,
                            left: 0,
                            behavior: m
                        };
                        if (window.scrollTo(O), S)
                            for (const w of S) {
                                if (w === zi) continue;
                                const A = typeof w == "function" ? w() : document.querySelector(w);
                                A && A.scrollTo(O)
                            }
                    }
                }
            } finally {
                ss = !1
            }
            a.isScrollRestoring && u.set(g => (g[p] || = {}, g))
        }
    })
}

function Ly(a, i = String) {
    const u = new URLSearchParams;
    for (const r in a) {
        const c = a[r];
        c !== void 0 && u.set(r, i(c))
    }
    return u.toString()
}

function tc(a) {
    return a ? a === "false" ? !1 : a === "true" ? !0 : +a * 0 === 0 && +a + "" === a ? +a : a : ""
}

function F0(a) {
    const i = new URLSearchParams(a),
        u = Object.create(null);
    for (const [r, c] of i.entries()) {
        const f = u[r];
        f == null ? u[r] = tc(c) : Array.isArray(f) ? f.push(tc(c)) : u[r] = [f, tc(c)]
    }
    return u
}
var I0 = $0(JSON.parse),
    W0 = tS(JSON.stringify, JSON.parse);

function $0(a) {
    return i => {
        i[0] === "?" && (i = i.substring(1));
        const u = F0(i);
        for (const r in u) {
            const c = u[r];
            if (typeof c == "string") try {
                u[r] = a(c)
            } catch {}
        }
        return u
    }
}

function tS(a, i) {
    const u = typeof i == "function";

    function r(c) {
        if (typeof c == "object" && c !== null) try {
            return a(c)
        } catch {} else if (u && typeof c == "string") try {
            return i(c), a(c)
        } catch {}
        return c
    }
    return c => {
        const f = Ly(c, r);
        return f ? `?${f}` : ""
    }
}
var Da = "__root__";

function Uy(a) {
    if (a.statusCode = a.statusCode || a.code || 307, !a._builtLocation && !a.reloadDocument && typeof a.href == "string") try {
        new URL(a.href), a.reloadDocument = !0
    } catch {}
    const i = new Headers(a.headers);
    a.href && i.get("Location") === null && i.set("Location", a.href);
    const u = new Response(null, {
        status: a.statusCode,
        headers: i
    });
    if (u.options = a, a.throw) throw u;
    return u
}

function _e(a) {
    return a instanceof Response && !!a.options
}

function eS(a) {
    if (a !== null && typeof a == "object" && a.isSerializedRedirect) return Uy(a)
}

function nS(a) {
    return {
        input: ({
            url: i
        }) => {
            for (const u of a) i = dc(u, i);
            return i
        },
        output: ({
            url: i
        }) => {
            for (let u = a.length - 1; u >= 0; u--) i = Ny(a[u], i);
            return i
        }
    }
}

function aS(a) {
    const i = Dy(a.basepath),
        u = `/${i}`,
        r = `${u}/`,
        c = a.caseSensitive ? u : u.toLowerCase(),
        f = a.caseSensitive ? r : r.toLowerCase();
    return {
        input: ({
            url: h
        }) => {
            const y = a.caseSensitive ? h.pathname : h.pathname.toLowerCase();
            return y === c ? h.pathname = "/" : y.startsWith(f) && (h.pathname = h.pathname.slice(u.length)), h
        },
        output: ({
            url: h
        }) => (h.pathname = cs(["/", i, h.pathname]), h)
    }
}

function dc(a, i) {
    const u = a ? .input ? .({
        url: i
    });
    if (u) {
        if (typeof u == "string") return new URL(u);
        if (u instanceof URL) return u
    }
    return i
}

function Ny(a, i) {
    const u = a ? .output ? .({
        url: i
    });
    if (u) {
        if (typeof u == "string") return new URL(u);
        if (u instanceof URL) return u
    }
    return i
}

function lS(a, i) {
    const {
        createMutableStore: u,
        createReadonlyStore: r,
        batch: c,
        init: f
    } = i, h = new Map, y = new Map, p = new Map, m = u(a.status), S = u(a.loadedAt), g = u(a.isLoading), _ = u(a.isTransitioning), E = u(a.location), O = u(a.resolvedLocation), w = u(a.statusCode), A = u(a.redirect), z = u([]), X = u([]), Q = u([]), H = r(() => ec(h, z.get())), W = r(() => ec(y, X.get())), F = r(() => ec(p, Q.get())), V = r(() => z.get()[0]), J = r(() => z.get().some(K => h.get(K) ? .get().status === "pending")), P = r(() => ({
        locationHref: E.get().href,
        resolvedLocationHref: O.get() ? .href,
        status: m.get()
    })), ut = r(() => ({
        status: m.get(),
        loadedAt: S.get(),
        isLoading: g.get(),
        isTransitioning: _.get(),
        matches: H.get(),
        location: E.get(),
        resolvedLocation: O.get(),
        statusCode: w.get(),
        redirect: A.get()
    })), tt = Hi(64);

    function dt(K) {
        let it = tt.get(K);
        return it || (it = r(() => {
            const Rt = z.get();
            for (const At of Rt) {
                const M = h.get(At);
                if (M && M.routeId === K) return M.get()
            }
        }), tt.set(K, it)), it
    }
    const vt = {
        status: m,
        loadedAt: S,
        isLoading: g,
        isTransitioning: _,
        location: E,
        resolvedLocation: O,
        statusCode: w,
        redirect: A,
        matchesId: z,
        pendingIds: X,
        cachedIds: Q,
        matches: H,
        pendingMatches: W,
        cachedMatches: F,
        firstId: V,
        hasPending: J,
        matchRouteDeps: P,
        matchStores: h,
        pendingMatchStores: y,
        cachedMatchStores: p,
        __store: ut,
        getRouteMatchStore: dt,
        setMatches: Yt,
        setPending: Ot,
        setCached: B
    };
    Yt(a.matches), f ? .(vt);

    function Yt(K) {
        nc(K, h, z, u, c)
    }

    function Ot(K) {
        nc(K, y, X, u, c)
    }

    function B(K) {
        nc(K, p, Q, u, c)
    }
    return vt
}

function ec(a, i) {
    const u = [];
    for (const r of i) {
        const c = a.get(r);
        c && u.push(c.get())
    }
    return u
}

function nc(a, i, u, r, c) {
    const f = a.map(y => y.id),
        h = new Set(f);
    c(() => {
        for (const y of i.keys()) h.has(y) || i.delete(y);
        for (const y of a) {
            const p = i.get(y.id);
            if (!p) {
                const m = r(y);
                m.routeId = y.routeId, i.set(y.id, m);
                continue
            }
            p.routeId = y.routeId, p.get() !== y && p.set(y)
        }
        C0(u.get(), f) || u.set(f)
    })
}
var hc = a => {
        if (!a.rendered) return a.rendered = !0, a.onReady ? .()
    },
    iS = a => a.stores.matchesId.get().some(i => a.stores.matchStores.get(i) ? .get()._forcePending),
    Rs = (a, i) => !!(a.preload && !a.router.stores.matchStores.has(i)),
    La = (a, i, u = !0) => {
        const r = { ...a.router.options.context ? ? {}
            },
            c = u ? i : i - 1;
        for (let f = 0; f <= c; f++) {
            const h = a.matches[f];
            if (!h) continue;
            const y = a.router.getMatch(h.id);
            y && Object.assign(r, y.__routeContext, y.__beforeLoadContext)
        }
        return r
    },
    Jm = (a, i) => {
        if (!a.matches.length) return;
        const u = i.routeId,
            r = a.matches.findIndex(h => h.routeId === a.router.routeTree.id),
            c = r >= 0 ? r : 0;
        let f = u ? a.matches.findIndex(h => h.routeId === u) : a.firstBadMatchIndex ? ? a.matches.length - 1;
        f < 0 && (f = c);
        for (let h = f; h >= 0; h--) {
            const y = a.matches[h];
            if (a.router.looseRoutesById[y.routeId].options.notFoundComponent) return h
        }
        return u ? f : c
    },
    ea = (a, i, u) => {
        if (!(!_e(u) && !ne(u))) throw _e(u) && u.redirectHandled && !u.options.reloadDocument || (i && (i._nonReactive.beforeLoadPromise ? .resolve(), i._nonReactive.loaderPromise ? .resolve(), i._nonReactive.beforeLoadPromise = void 0, i._nonReactive.loaderPromise = void 0, i._nonReactive.error = u, a.updateMatch(i.id, r => ({ ...r,
            status: _e(u) ? "redirected" : ne(u) ? "notFound" : r.status === "pending" ? "success" : r.status,
            context: La(a, i.index),
            isFetching: !1,
            error: u
        })), ne(u) && !u.routeId && (u.routeId = i.routeId), i._nonReactive.loadPromise ? .resolve()), _e(u) && (a.rendered = !0, u.options._fromLocation = a.location, u.redirectHandled = !0, u = a.router.resolveRedirect(u))), u
    },
    By = (a, i) => {
        const u = a.router.getMatch(i);
        return !!(!u || u._nonReactive.dehydrated)
    },
    km = (a, i, u) => {
        const r = La(a, u);
        a.updateMatch(i, c => ({ ...c,
            context: r
        }))
    },
    Ci = (a, i, u, r) => {
        const {
            id: c,
            routeId: f
        } = a.matches[i], h = a.router.looseRoutesById[f];
        if (u instanceof Promise) throw u;
        u.routerCode = r, a.firstBadMatchIndex ? ? = i, ea(a, a.router.getMatch(c), u);
        try {
            h.options.onError ? .(u)
        } catch (y) {
            u = y, ea(a, a.router.getMatch(c), u)
        }
        a.updateMatch(c, y => (y._nonReactive.beforeLoadPromise ? .resolve(), y._nonReactive.beforeLoadPromise = void 0, y._nonReactive.loadPromise ? .resolve(), { ...y,
            error: u,
            status: "error",
            isFetching: !1,
            updatedAt: Date.now(),
            abortController: new AbortController
        })), !a.preload && !_e(u) && !ne(u) && (a.serialError ? ? = u)
    },
    jy = (a, i, u, r) => {
        if (r._nonReactive.pendingTimeout !== void 0) return;
        const c = u.options.pendingMs ? ? a.router.options.defaultPendingMs;
        if (a.onReady && !Rs(a, i) && (u.options.loader || u.options.beforeLoad || qy(u)) && typeof c == "number" && c !== 1 / 0 && (u.options.pendingComponent ? ? a.router.options ? .defaultPendingComponent)) {
            const f = setTimeout(() => {
                hc(a)
            }, c);
            r._nonReactive.pendingTimeout = f
        }
    },
    uS = (a, i, u) => {
        const r = a.router.getMatch(i);
        if (!r._nonReactive.beforeLoadPromise && !r._nonReactive.loaderPromise) return;
        jy(a, i, u, r);
        const c = () => {
            const f = a.router.getMatch(i);
            f.preload && (f.status === "redirected" || f.status === "notFound") && ea(a, f, f.error)
        };
        return r._nonReactive.beforeLoadPromise ? r._nonReactive.beforeLoadPromise.then(c) : c()
    },
    sS = (a, i, u, r) => {
        const c = a.router.getMatch(i);
        let f = c._nonReactive.loadPromise;
        c._nonReactive.loadPromise = Ua(() => {
            f ? .resolve(), f = void 0
        });
        const {
            paramsError: h,
            searchError: y
        } = c;
        h && Ci(a, u, h, "PARSE_PARAMS"), y && Ci(a, u, y, "VALIDATE_SEARCH"), jy(a, i, r, c);
        const p = new AbortController;
        let m = !1;
        const S = () => {
                m || (m = !0, a.updateMatch(i, H => ({ ...H,
                    isFetching: "beforeLoad",
                    fetchCount: H.fetchCount + 1,
                    abortController: p
                })))
            },
            g = () => {
                c._nonReactive.beforeLoadPromise ? .resolve(), c._nonReactive.beforeLoadPromise = void 0, a.updateMatch(i, H => ({ ...H,
                    isFetching: !1
                }))
            };
        if (!r.options.beforeLoad) {
            a.router.batch(() => {
                S(), g()
            });
            return
        }
        c._nonReactive.beforeLoadPromise = Ua();
        const _ = { ...La(a, u, !1),
                ...c.__routeContext
            },
            {
                search: E,
                params: O,
                cause: w
            } = c,
            A = Rs(a, i),
            z = {
                search: E,
                abortController: p,
                params: O,
                preload: A,
                context: _,
                location: a.location,
                navigate: H => a.router.navigate({ ...H,
                    _fromLocation: a.location
                }),
                buildLocation: a.router.buildLocation,
                cause: A ? "preload" : w,
                matches: a.matches,
                routeId: r.id,
                ...a.router.options.additionalContext
            },
            X = H => {
                if (H === void 0) {
                    a.router.batch(() => {
                        S(), g()
                    });
                    return
                }(_e(H) || ne(H)) && (S(), Ci(a, u, H, "BEFORE_LOAD")), a.router.batch(() => {
                    S(), a.updateMatch(i, W => ({ ...W,
                        __beforeLoadContext: H
                    })), g()
                })
            };
        let Q;
        try {
            if (Q = r.options.beforeLoad(z), ji(Q)) return S(), Q.catch(H => {
                Ci(a, u, H, "BEFORE_LOAD")
            }).then(X)
        } catch (H) {
            S(), Ci(a, u, H, "BEFORE_LOAD")
        }
        X(Q)
    },
    rS = (a, i) => {
        const {
            id: u,
            routeId: r
        } = a.matches[i], c = a.router.looseRoutesById[r], f = () => y(), h = () => sS(a, u, i, c), y = () => {
            if (By(a, u)) return;
            const p = uS(a, u, c);
            return ji(p) ? p.then(h) : h()
        };
        return f()
    },
    oS = (a, i, u) => {
        const r = a.router.getMatch(i);
        if (!r || !u.options.head && !u.options.scripts && !u.options.headers) return;
        const c = {
            ssr: a.router.options.ssr,
            matches: a.matches,
            match: r,
            params: r.params,
            loaderData: r.loaderData
        };
        return Promise.all([u.options.head ? .(c), u.options.scripts ? .(c), u.options.headers ? .(c)]).then(([f, h, y]) => ({
            meta: f ? .meta,
            links: f ? .links,
            headScripts: f ? .scripts,
            headers: y,
            scripts: h,
            styles: f ? .styles
        }))
    },
    Hy = (a, i, u, r, c) => {
        const f = i[r - 1],
            {
                params: h,
                loaderDeps: y,
                abortController: p,
                cause: m
            } = a.router.getMatch(u),
            S = La(a, r),
            g = Rs(a, u);
        return {
            params: h,
            deps: y,
            preload: !!g,
            parentMatchPromise: f,
            abortController: p,
            context: S,
            location: a.location,
            navigate: _ => a.router.navigate({ ..._,
                _fromLocation: a.location
            }),
            cause: g ? "preload" : m,
            route: c,
            ...a.router.options.additionalContext
        }
    },
    Pm = async (a, i, u, r, c) => {
        try {
            const f = a.router.getMatch(u);
            try {
                (!(Oy ? ? a.router.isServer) || f.ssr === !0) && qi(c);
                const h = c.options.loader,
                    y = typeof h == "function" ? h : h ? .handler,
                    p = y ? .(Hy(a, i, u, r, c)),
                    m = !!y && ji(p);
                if ((m || c._lazyPromise || c._componentsPromise || c.options.head || c.options.scripts || c.options.headers || f._nonReactive.minPendingPromise) && a.updateMatch(u, g => ({ ...g,
                        isFetching: "loader"
                    })), y) {
                    const g = m ? await p : p;
                    ea(a, a.router.getMatch(u), g), g !== void 0 && a.updateMatch(u, _ => ({ ..._,
                        loaderData: g
                    }))
                }
                c._lazyPromise && await c._lazyPromise;
                const S = f._nonReactive.minPendingPromise;
                S && await S, c._componentsPromise && await c._componentsPromise, a.updateMatch(u, g => ({ ...g,
                    error: void 0,
                    context: La(a, r),
                    status: "success",
                    isFetching: !1,
                    updatedAt: Date.now()
                }))
            } catch (h) {
                let y = h;
                if (y ? .name === "AbortError") {
                    if (f.abortController.signal.aborted) {
                        f._nonReactive.loaderPromise ? .resolve(), f._nonReactive.loaderPromise = void 0;
                        return
                    }
                    a.updateMatch(u, m => ({ ...m,
                        status: m.status === "pending" ? "success" : m.status,
                        isFetching: !1,
                        context: La(a, r)
                    }));
                    return
                }
                const p = f._nonReactive.minPendingPromise;
                p && await p, ne(h) && await c.options.notFoundComponent ? .preload ? .(), ea(a, a.router.getMatch(u), h);
                try {
                    c.options.onError ? .(h)
                } catch (m) {
                    y = m, ea(a, a.router.getMatch(u), m)
                }!_e(y) && !ne(y) && await qi(c, ["errorComponent"]), a.updateMatch(u, m => ({ ...m,
                    error: y,
                    context: La(a, r),
                    status: "error",
                    isFetching: !1
                }))
            }
        } catch (f) {
            const h = a.router.getMatch(u);
            h && (h._nonReactive.loaderPromise = void 0), ea(a, h, f)
        }
    },
    cS = async (a, i, u) => {
        async function r(E, O, w, A, z) {
            const X = Date.now() - O.updatedAt,
                Q = E ? z.options.preloadStaleTime ? ? a.router.options.defaultPreloadStaleTime ? ? 3e4 : z.options.staleTime ? ? a.router.options.defaultStaleTime ? ? 0,
                H = z.options.shouldReload,
                W = typeof H == "function" ? H(Hy(a, i, c, u, z)) : H,
                {
                    status: F,
                    invalid: V
                } = A,
                J = X >= Q && (!!a.forceStaleReload || A.cause === "enter" || w !== void 0 && w !== A.id);
            h = F === "success" && (V || (W ? ? J)), E && z.options.preload === !1 || (h && !a.sync && S ? (y = !0, (async () => {
                try {
                    await Pm(a, i, c, u, z);
                    const P = a.router.getMatch(c);
                    P._nonReactive.loaderPromise ? .resolve(), P._nonReactive.loadPromise ? .resolve(), P._nonReactive.loaderPromise = void 0, P._nonReactive.loadPromise = void 0
                } catch (P) {
                    _e(P) && await a.router.navigate(P.options)
                }
            })()) : F !== "success" || h ? await Pm(a, i, c, u, z) : km(a, c, u))
        }
        const {
            id: c,
            routeId: f
        } = a.matches[u];
        let h = !1,
            y = !1;
        const p = a.router.looseRoutesById[f],
            m = p.options.loader,
            S = ((typeof m == "function" ? void 0 : m ? .staleReloadMode) ? ? a.router.options.defaultStaleReloadMode) !== "blocking";
        if (By(a, c)) {
            if (!a.router.getMatch(c)) return a.matches[u];
            km(a, c, u)
        } else {
            const E = a.router.getMatch(c),
                O = a.router.stores.matchesId.get()[u],
                w = (O && a.router.stores.matchStores.get(O) || null) ? .routeId === f ? O : a.router.stores.matches.get().find(z => z.routeId === f) ? .id,
                A = Rs(a, c);
            if (E._nonReactive.loaderPromise) {
                if (E.status === "success" && !a.sync && !E.preload && S) return E;
                await E._nonReactive.loaderPromise;
                const z = a.router.getMatch(c),
                    X = z._nonReactive.error || z.error;
                X && ea(a, z, X), z.status === "pending" && await r(A, E, w, z, p)
            } else {
                const z = A && !a.router.stores.matchStores.has(c),
                    X = a.router.getMatch(c);
                X._nonReactive.loaderPromise = Ua(), z !== X.preload && a.updateMatch(c, Q => ({ ...Q,
                    preload: z
                })), await r(A, E, w, X, p)
            }
        }
        const g = a.router.getMatch(c);
        y || (g._nonReactive.loaderPromise ? .resolve(), g._nonReactive.loadPromise ? .resolve(), g._nonReactive.loadPromise = void 0), clearTimeout(g._nonReactive.pendingTimeout), g._nonReactive.pendingTimeout = void 0, y || (g._nonReactive.loaderPromise = void 0), g._nonReactive.dehydrated = void 0;
        const _ = y ? g.isFetching : !1;
        return _ !== g.isFetching || g.invalid !== !1 ? (a.updateMatch(c, E => ({ ...E,
            isFetching: _,
            invalid: !1
        })), a.router.getMatch(c)) : g
    };
async function Fm(a) {
    const i = a,
        u = [];
    iS(i.router) && hc(i);
    let r;
    for (let _ = 0; _ < i.matches.length; _++) {
        try {
            const E = rS(i, _);
            ji(E) && await E
        } catch (E) {
            if (_e(E)) throw E;
            if (ne(E)) r = E;
            else if (!i.preload) throw E;
            break
        }
        if (i.serialError || i.firstBadMatchIndex != null) break
    }
    const c = i.firstBadMatchIndex ? ? i.matches.length,
        f = r && !i.preload ? Jm(i, r) : void 0,
        h = r && i.preload ? 0 : f !== void 0 ? Math.min(f + 1, c) : c;
    let y, p;
    for (let _ = 0; _ < h; _++) u.push(cS(i, u, _));
    try {
        await Promise.all(u)
    } catch {
        const _ = await Promise.allSettled(u);
        for (const E of _) {
            if (E.status !== "rejected") continue;
            const O = E.reason;
            if (_e(O)) throw O;
            ne(O) ? y ? ? = O : p ? ? = O
        }
        if (p !== void 0) throw p
    }
    const m = y ? ? (r && !i.preload ? r : void 0);
    let S = i.firstBadMatchIndex !== void 0 ? i.firstBadMatchIndex : i.matches.length - 1;
    if (!m && r && i.preload) return i.matches;
    if (m) {
        const _ = Jm(i, m);
        _ === void 0 && Ee();
        const E = i.matches[_],
            O = i.router.looseRoutesById[E.routeId],
            w = i.router.options ? .defaultNotFoundComponent;
        !O.options.notFoundComponent && w && (O.options.notFoundComponent = w), m.routeId = E.routeId;
        const A = E.routeId === i.router.routeTree.id;
        i.updateMatch(E.id, z => ({ ...z,
            ...A ? {
                status: "success",
                globalNotFound: !0,
                error: void 0
            } : {
                status: "notFound",
                error: m
            },
            isFetching: !1
        })), S = _, await qi(O, ["notFoundComponent"])
    } else if (!i.preload) {
        const _ = i.matches[0];
        _.globalNotFound || i.router.getMatch(_.id) ? .globalNotFound && i.updateMatch(_.id, E => ({ ...E,
            globalNotFound: !1,
            error: void 0
        }))
    }
    if (i.serialError && i.firstBadMatchIndex !== void 0) {
        const _ = i.router.looseRoutesById[i.matches[i.firstBadMatchIndex].routeId];
        await qi(_, ["errorComponent"])
    }
    for (let _ = 0; _ <= S; _++) {
        const {
            id: E,
            routeId: O
        } = i.matches[_], w = i.router.looseRoutesById[O];
        try {
            const A = oS(i, E, w);
            if (A) {
                const z = await A;
                i.updateMatch(E, X => ({ ...X,
                    ...z
                }))
            }
        } catch (A) {
            console.error(`Error executing head for route ${O}:`, A)
        }
    }
    const g = hc(i);
    if (ji(g) && await g, m) throw m;
    if (i.serialError && !i.preload && !i.onReady) throw i.serialError;
    return i.matches
}

function Im(a, i) {
    const u = i.map(r => a.options[r] ? .preload ? .()).filter(Boolean);
    if (u.length !== 0) return Promise.all(u)
}

function qi(a, i = fs) {
    !a._lazyLoaded && a._lazyPromise === void 0 && (a.lazyFn ? a._lazyPromise = a.lazyFn().then(r => {
        const {
            id: c,
            ...f
        } = r.options;
        Object.assign(a.options, f), a._lazyLoaded = !0, a._lazyPromise = void 0
    }) : a._lazyLoaded = !0);
    const u = () => a._componentsLoaded ? void 0 : i === fs ? (() => {
        if (a._componentsPromise === void 0) {
            const r = Im(a, fs);
            r ? a._componentsPromise = r.then(() => {
                a._componentsLoaded = !0, a._componentsPromise = void 0
            }) : a._componentsLoaded = !0
        }
        return a._componentsPromise
    })() : Im(a, i);
    return a._lazyPromise ? a._lazyPromise.then(u) : u()
}

function qy(a) {
    for (const i of fs)
        if (a.options[i] ? .preload) return !0;
    return !1
}
var fs = ["component", "errorComponent", "pendingComponent", "notFoundComponent"],
    aa = "__TSR_index",
    Wm = "popstate",
    $m = "beforeunload";

function fS(a) {
    let i = a.getLocation();
    const u = new Set,
        r = h => {
            i = a.getLocation(), u.forEach(y => y({
                location: i,
                action: h
            }))
        },
        c = h => {
            a.notifyOnIndexChange ? ? !0 ? r(h) : i = a.getLocation()
        },
        f = async ({
            task: h,
            navigateOpts: y,
            ...p
        }) => {
            if (y ? .ignoreBlocker ? ? !1) {
                h();
                return
            }
            const m = a.getBlockers ? .() ? ? [],
                S = p.type === "PUSH" || p.type === "REPLACE";
            if (typeof document < "u" && m.length && S)
                for (const g of m) {
                    const _ = vs(p.path, p.state);
                    if (await g.blockerFn({
                            currentLocation: i,
                            nextLocation: _,
                            action: p.type
                        })) {
                        a.onBlocked ? .();
                        return
                    }
                }
            h()
        };
    return {
        get location() {
            return i
        },
        get length() {
            return a.getLength()
        },
        subscribers: u,
        subscribe: h => (u.add(h), () => {
            u.delete(h)
        }),
        push: (h, y, p) => {
            const m = i.state[aa];
            y = ty(m + 1, y), f({
                task: () => {
                    a.pushState(h, y), r({
                        type: "PUSH"
                    })
                },
                navigateOpts: p,
                type: "PUSH",
                path: h,
                state: y
            })
        },
        replace: (h, y, p) => {
            const m = i.state[aa];
            y = ty(m, y), f({
                task: () => {
                    a.replaceState(h, y), r({
                        type: "REPLACE"
                    })
                },
                navigateOpts: p,
                type: "REPLACE",
                path: h,
                state: y
            })
        },
        go: (h, y) => {
            f({
                task: () => {
                    a.go(h), c({
                        type: "GO",
                        index: h
                    })
                },
                navigateOpts: y,
                type: "GO"
            })
        },
        back: h => {
            f({
                task: () => {
                    a.back(h ? .ignoreBlocker ? ? !1), c({
                        type: "BACK"
                    })
                },
                navigateOpts: h,
                type: "BACK"
            })
        },
        forward: h => {
            f({
                task: () => {
                    a.forward(h ? .ignoreBlocker ? ? !1), c({
                        type: "FORWARD"
                    })
                },
                navigateOpts: h,
                type: "FORWARD"
            })
        },
        canGoBack: () => i.state[aa] !== 0,
        createHref: h => a.createHref(h),
        block: h => {
            if (!a.setBlockers) return () => {};
            const y = a.getBlockers ? .() ? ? [];
            return a.setBlockers([...y, h]), () => {
                const p = a.getBlockers ? .() ? ? [];
                a.setBlockers ? .(p.filter(m => m !== h))
            }
        },
        flush: () => a.flush ? .(),
        destroy: () => a.destroy ? .(),
        notify: r
    }
}

function ty(a, i) {
    i || (i = {});
    const u = Ec();
    return { ...i,
        key: u,
        __TSR_key: u,
        [aa]: a
    }
}

function dS(a) {
    const i = typeof document < "u" ? window : void 0,
        u = i.history.pushState,
        r = i.history.replaceState;
    let c = [];
    const f = () => c,
        h = J => c = J,
        y = (J => J),
        p = (() => vs(`${i.location.pathname}${i.location.search}${i.location.hash}`, i.history.state));
    if (!i.history.state ? .__TSR_key && !i.history.state ? .key) {
        const J = Ec();
        i.history.replaceState({
            [aa]: 0,
            key: J,
            __TSR_key: J
        }, "")
    }
    let m = p(),
        S, g = !1,
        _ = !1,
        E = !1,
        O = !1;
    const w = () => m;
    let A, z;
    const X = () => {
            A && (V._ignoreSubscribers = !0, (A.isPush ? i.history.pushState : i.history.replaceState)(A.state, "", A.href), V._ignoreSubscribers = !1, A = void 0, z = void 0, S = void 0)
        },
        Q = (J, P, ut) => {
            const tt = y(P);
            z || (S = m), m = vs(P, ut), A = {
                href: tt,
                state: ut,
                isPush: A ? .isPush || J === "push"
            }, z || (z = Promise.resolve().then(() => X()))
        },
        H = J => {
            m = p(), V.notify({
                type: J
            })
        },
        W = async () => {
            if (_) {
                _ = !1;
                return
            }
            const J = p(),
                P = J.state[aa] - m.state[aa],
                ut = P === 1,
                tt = P === -1,
                dt = !ut && !tt || g;
            g = !1;
            const vt = dt ? "GO" : tt ? "BACK" : "FORWARD",
                Yt = dt ? {
                    type: "GO",
                    index: P
                } : {
                    type: tt ? "BACK" : "FORWARD"
                };
            if (E) E = !1;
            else {
                const Ot = f();
                if (typeof document < "u" && Ot.length) {
                    for (const B of Ot)
                        if (await B.blockerFn({
                                currentLocation: m,
                                nextLocation: J,
                                action: vt
                            })) {
                            _ = !0, i.history.go(1), V.notify(Yt);
                            return
                        }
                }
            }
            m = p(), V.notify(Yt)
        },
        F = J => {
            if (O) {
                O = !1;
                return
            }
            let P = !1;
            const ut = f();
            if (typeof document < "u" && ut.length)
                for (const tt of ut) {
                    const dt = tt.enableBeforeUnload ? ? !0;
                    if (dt === !0) {
                        P = !0;
                        break
                    }
                    if (typeof dt == "function" && dt() === !0) {
                        P = !0;
                        break
                    }
                }
            if (P) return J.preventDefault(), J.returnValue = ""
        },
        V = fS({
            getLocation: w,
            getLength: () => i.history.length,
            pushState: (J, P) => Q("push", J, P),
            replaceState: (J, P) => Q("replace", J, P),
            back: J => (J && (E = !0), O = !0, i.history.back()),
            forward: J => {
                J && (E = !0), O = !0, i.history.forward()
            },
            go: J => {
                g = !0, i.history.go(J)
            },
            createHref: J => y(J),
            flush: X,
            destroy: () => {
                i.history.pushState = u, i.history.replaceState = r, i.removeEventListener($m, F, {
                    capture: !0
                }), i.removeEventListener(Wm, W)
            },
            onBlocked: () => {
                S && m !== S && (m = S)
            },
            getBlockers: f,
            setBlockers: h,
            notifyOnIndexChange: !1
        });
    return i.addEventListener($m, F, {
        capture: !0
    }), i.addEventListener(Wm, W), i.history.pushState = function(...J) {
        const P = u.apply(i.history, J);
        return V._ignoreSubscribers || H("PUSH"), P
    }, i.history.replaceState = function(...J) {
        const P = r.apply(i.history, J);
        return V._ignoreSubscribers || H("REPLACE"), P
    }, V
}

function hS(a) {
    let i = a.replace(/[\x00-\x1f\x7f]/g, "");
    return i.startsWith("//") && (i = "/" + i.replace(/^\/+/, "")), i
}

function vs(a, i) {
    const u = hS(a),
        r = u.indexOf("#"),
        c = u.indexOf("?"),
        f = Ec();
    return {
        href: u,
        pathname: u.substring(0, r > 0 ? c > 0 ? Math.min(r, c) : r : c > 0 ? c : u.length),
        hash: r > -1 ? u.substring(r) : "",
        search: c > -1 ? u.slice(c, r === -1 ? void 0 : r) : "",
        state: i || {
            [aa]: 0,
            key: f,
            __TSR_key: f
        }
    }
}

function Ec() {
    return (Math.random() + 1).toString(36).substring(7)
}

function mS(a) {
    return a instanceof Error ? {
        name: a.name,
        message: a.message
    } : {
        data: a
    }
}

function xl(a, i) {
    const u = i,
        r = a;
    return {
        fromLocation: u,
        toLocation: r,
        pathChanged: u ? .pathname !== r.pathname,
        hrefChanged: u ? .href !== r.href,
        hashChanged: u ? .hash !== r.hash
    }
}
var yS = class {
        constructor(a, i) {
            this.tempLocationKey = `${Math.round(Math.random()*1e7)}`, this.resetNextScroll = !0, this.shouldViewTransition = void 0, this.isViewTransitionTypesSupported = void 0, this.subscribers = new Set, this.isScrollRestoring = !1, this.isScrollRestorationSetup = !1, this.startTransition = u => u(), this.update = u => {
                const r = this.options,
                    c = this.basepath ? ? r ? .basepath ? ? "/",
                    f = this.basepath === void 0,
                    h = r ? .rewrite;
                if (this.options = { ...r,
                        ...u
                    }, this.isServer = this.options.isServer ? ? typeof document > "u", this.protocolAllowlist = new Set(this.options.protocolAllowlist), this.options.pathParamsAllowedCharacters && (this.pathParamsDecoder = V0(this.options.pathParamsAllowedCharacters)), (!this.history || this.options.history && this.options.history !== this.history) && (this.options.history ? this.history = this.options.history : this.history = dS()), this.origin = this.options.origin, this.origin || (window ? .origin && window.origin !== "null" ? this.origin = window.origin : this.origin = "http://localhost"), this.history && this.updateLatestLocation(), this.options.routeTree !== this.routeTree) {
                    this.routeTree = this.options.routeTree;
                    let S;
                    this.resolvePathCache = Hi(1e3), S = this.buildRouteTree(), this.setRoutes(S)
                }
                if (!this.stores && this.latestLocation) {
                    const S = this.getStoreConfig(this);
                    this.batch = S.batch, this.stores = lS(vS(this.latestLocation), S), P0(this)
                }
                let y = !1;
                const p = this.options.basepath ? ? "/",
                    m = this.options.rewrite;
                if (f || c !== p || h !== m) {
                    this.basepath = p;
                    const S = [],
                        g = Dy(p);
                    g && g !== "/" && S.push(aS({
                        basepath: p
                    })), m && S.push(m), this.rewrite = S.length === 0 ? void 0 : S.length === 1 ? S[0] : nS(S), this.history && this.updateLatestLocation(), y = !0
                }
                y && this.stores && this.stores.location.set(this.latestLocation), typeof window < "u" && "CSS" in window && typeof window.CSS ? .supports == "function" && (this.isViewTransitionTypesSupported = window.CSS.supports("selector(:active-view-transition-type(a)"))
            }, this.updateLatestLocation = () => {
                this.latestLocation = this.parseLocation(this.history.location, this.latestLocation)
            }, this.buildRouteTree = () => {
                const u = j0(this.routeTree, this.options.caseSensitive, (r, c) => {
                    r.init({
                        originalIndex: c
                    })
                });
                return this.options.routeMasks && D0(this.options.routeMasks, u.processedTree), u
            }, this.subscribe = (u, r) => {
                const c = {
                    eventType: u,
                    fn: r
                };
                return this.subscribers.add(c), () => {
                    this.subscribers.delete(c)
                }
            }, this.emit = u => {
                this.subscribers.forEach(r => {
                    r.eventType === u.type && r.fn(u)
                })
            }, this.parseLocation = (u, r) => {
                const c = ({
                        pathname: p,
                        search: m,
                        hash: S,
                        href: g,
                        state: _
                    }) => {
                        if (!this.rewrite && !/[ \x00-\x1f\x7f\u0080-\uffff]/.test(p)) {
                            const z = this.options.parseSearch(m),
                                X = this.options.stringifySearch(z);
                            return {
                                href: p + X + S,
                                publicHref: p + X + S,
                                pathname: Mi(p).path,
                                external: !1,
                                searchStr: X,
                                search: Ma(r ? .search, z),
                                hash: Mi(S.slice(1)).path,
                                state: Oa(r ? .state, _)
                            }
                        }
                        const E = new URL(g, this.origin),
                            O = dc(this.rewrite, E),
                            w = this.options.parseSearch(O.search),
                            A = this.options.stringifySearch(w);
                        return O.search = A, {
                            href: O.href.replace(O.origin, ""),
                            publicHref: g,
                            pathname: Mi(O.pathname).path,
                            external: !!this.rewrite && O.origin !== this.origin,
                            searchStr: A,
                            search: Ma(r ? .search, w),
                            hash: Mi(O.hash.slice(1)).path,
                            state: Oa(r ? .state, _)
                        }
                    },
                    f = c(u),
                    {
                        __tempLocation: h,
                        __tempKey: y
                    } = f.state;
                if (h && (!y || y === this.tempLocationKey)) {
                    const p = c(h);
                    return p.state.key = f.state.key, p.state.__TSR_key = f.state.__TSR_key, delete p.state.__tempLocation, { ...p,
                        maskedLocation: f
                    }
                }
                return f
            }, this.resolvePathWithBase = (u, r) => X0({
                base: u,
                to: _c(r),
                trailingSlash: this.options.trailingSlash,
                cache: this.resolvePathCache
            }), this.matchRoutes = (u, r, c) => typeof u == "string" ? this.matchRoutesInternal({
                pathname: u,
                search: r
            }, c) : this.matchRoutesInternal(u, r), this.getMatchedRoutes = u => gS({
                pathname: u,
                routesById: this.routesById,
                processedTree: this.processedTree
            }), this.cancelMatch = u => {
                const r = this.getMatch(u);
                r && (r.abortController.abort(), clearTimeout(r._nonReactive.pendingTimeout), r._nonReactive.pendingTimeout = void 0)
            }, this.cancelMatches = () => {
                this.stores.pendingIds.get().forEach(u => {
                    this.cancelMatch(u)
                }), this.stores.matchesId.get().forEach(u => {
                    if (this.stores.pendingMatchStores.has(u)) return;
                    const r = this.stores.matchStores.get(u) ? .get();
                    r && (r.status === "pending" || r.isFetching === "loader") && this.cancelMatch(u)
                })
            }, this.buildLocation = u => {
                const r = (f = {}) => {
                        const h = f._fromLocation || this.pendingBuiltLocation || this.latestLocation,
                            y = this.matchRoutesLightweight(h);
                        f.from;
                        const p = f.unsafeRelative === "path" ? h.pathname : f.from ? ? y.fullPath,
                            m = this.resolvePathWithBase(p, "."),
                            S = y.search,
                            g = Object.assign(Object.create(null), y.params),
                            _ = f.to ? this.resolvePathWithBase(m, `${f.to}`) : this.resolvePathWithBase(m, "."),
                            E = f.params === !1 || f.params === null ? Object.create(null) : (f.params ? ? !0) === !0 ? g : Object.assign(g, ta(f.params, g)),
                            O = this.getMatchedRoutes(_);
                        let w = O.matchedRoutes;
                        if ((!O.foundRoute || O.foundRoute.path !== "/" && O.routeParams["**"]) && this.options.notFoundRoute && (w = [...w, this.options.notFoundRoute]), Object.keys(E).length > 0)
                            for (const ut of w) {
                                const tt = ut.options.params ? .stringify ? ? ut.options.stringifyParams;
                                if (tt) try {
                                    Object.assign(E, tt(E))
                                } catch {}
                            }
                        const A = u.leaveParams ? _ : Mi(Vm({
                            path: _,
                            params: E,
                            decoder: this.pathParamsDecoder,
                            server: this.isServer
                        }).interpolatedPath).path;
                        let z = S;
                        if (u._includeValidateSearch && this.options.search ? .strict) {
                            const ut = {};
                            w.forEach(tt => {
                                if (tt.options.validateSearch) try {
                                    Object.assign(ut, ds(tt.options.validateSearch, { ...ut,
                                        ...z
                                    }))
                                } catch {}
                            }), z = ut
                        }
                        z = SS({
                            search: z,
                            dest: f,
                            destRoutes: w,
                            _includeValidateSearch: u._includeValidateSearch
                        }), z = Ma(S, z);
                        const X = this.options.stringifySearch(z),
                            Q = f.hash === !0 ? h.hash : f.hash ? ta(f.hash, h.hash) : void 0,
                            H = Q ? `#${Q}` : "";
                        let W = f.state === !0 ? h.state : f.state ? ta(f.state, h.state) : {};
                        W = Oa(h.state, W);
                        const F = `${A}${X}${H}`;
                        let V, J, P = !1;
                        if (this.rewrite) {
                            const ut = new URL(F, this.origin),
                                tt = Ny(this.rewrite, ut);
                            V = ut.href.replace(ut.origin, ""), tt.origin !== this.origin ? (J = tt.href, P = !0) : J = tt.pathname + tt.search + tt.hash
                        } else V = z0(F), J = V;
                        return {
                            publicHref: J,
                            href: V,
                            pathname: A,
                            search: z,
                            searchStr: X,
                            state: W,
                            hash: Q ? ? "",
                            external: P,
                            unmaskOnReload: f.unmaskOnReload
                        }
                    },
                    c = (f = {}, h) => {
                        const y = r(f);
                        let p = h ? r(h) : void 0;
                        if (!p) {
                            const m = Object.create(null);
                            if (this.options.routeMasks) {
                                const S = L0(y.pathname, this.processedTree);
                                if (S) {
                                    Object.assign(m, S.rawParams);
                                    const {
                                        from: g,
                                        params: _,
                                        ...E
                                    } = S.route, O = _ === !1 || _ === null ? Object.create(null) : (_ ? ? !0) === !0 ? m : Object.assign(m, ta(_, m));
                                    h = {
                                        from: u.from,
                                        ...E,
                                        params: O
                                    }, p = r(h)
                                }
                            }
                        }
                        return p && (y.maskedLocation = p), y
                    };
                return u.mask ? c(u, {
                    from: u.from,
                    ...u.mask
                }) : c(u)
            }, this.commitLocation = async ({
                viewTransition: u,
                ignoreBlocker: r,
                ...c
            }) => {
                const f = () => {
                        const p = ["key", "__TSR_key", "__TSR_index", "__hashScrollIntoViewOptions"];
                        p.forEach(S => {
                            c.state[S] = this.latestLocation.state[S]
                        });
                        const m = be(c.state, this.latestLocation.state);
                        return p.forEach(S => {
                            delete c.state[S]
                        }), m
                    },
                    h = na(this.latestLocation.href) === na(c.href);
                let y = this.commitLocationPromise;
                if (this.commitLocationPromise = Ua(() => {
                        y ? .resolve(), y = void 0
                    }), h && f()) this.load();
                else {
                    let {
                        maskedLocation: p,
                        hashScrollIntoView: m,
                        ...S
                    } = c;
                    p && (S = { ...p,
                        state: { ...p.state,
                            __tempKey: void 0,
                            __tempLocation: { ...S,
                                search: S.searchStr,
                                state: { ...S.state,
                                    __tempKey: void 0,
                                    __tempLocation: void 0,
                                    __TSR_key: void 0,
                                    key: void 0
                                }
                            }
                        }
                    }, (S.unmaskOnReload ? ? this.options.unmaskOnReload ? ? !1) && (S.state.__tempKey = this.tempLocationKey)), S.state.__hashScrollIntoViewOptions = m ? ? this.options.defaultHashScrollIntoView ? ? !0, this.shouldViewTransition = u, this.history[c.replace ? "replace" : "push"](S.publicHref, S.state, {
                        ignoreBlocker: r
                    })
                }
                return this.resetNextScroll = c.resetScroll ? ? !0, this.history.subscribers.size || this.load(), this.commitLocationPromise
            }, this.buildAndCommitLocation = ({
                replace: u,
                resetScroll: r,
                hashScrollIntoView: c,
                viewTransition: f,
                ignoreBlocker: h,
                href: y,
                ...p
            } = {}) => {
                if (y) {
                    const g = this.history.location.state.__TSR_index,
                        _ = vs(y, {
                            __TSR_index: u ? g : g + 1
                        }),
                        E = new URL(_.pathname, this.origin);
                    p.to = dc(this.rewrite, E).pathname, p.search = this.options.parseSearch(_.search), p.hash = _.hash.slice(1)
                }
                const m = this.buildLocation({ ...p,
                    _includeValidateSearch: !0
                });
                this.pendingBuiltLocation = m;
                const S = this.commitLocation({ ...m,
                    viewTransition: f,
                    replace: u,
                    resetScroll: r,
                    hashScrollIntoView: c,
                    ignoreBlocker: h
                });
                return Promise.resolve().then(() => {
                    this.pendingBuiltLocation === m && (this.pendingBuiltLocation = void 0)
                }), S
            }, this.navigate = async ({
                to: u,
                reloadDocument: r,
                href: c,
                publicHref: f,
                ...h
            }) => {
                let y = !1;
                if (c) try {
                    new URL(`${c}`), y = !0
                } catch {}
                if (y && !r && (r = !0), r) {
                    if (u !== void 0 || !c) {
                        const m = this.buildLocation({
                            to: u,
                            ...h
                        });
                        c = c ? ? m.publicHref, f = f ? ? m.publicHref
                    }
                    const p = !y && f ? f : c;
                    if (ys(p, this.protocolAllowlist)) return Promise.resolve();
                    if (!h.ignoreBlocker) {
                        const m = this.history.getBlockers ? .() ? ? [];
                        for (const S of m)
                            if (S ? .blockerFn && await S.blockerFn({
                                    currentLocation: this.latestLocation,
                                    nextLocation: this.latestLocation,
                                    action: "PUSH"
                                })) return Promise.resolve()
                    }
                    return h.replace ? window.location.replace(p) : window.location.href = p, Promise.resolve()
                }
                return this.buildAndCommitLocation({ ...h,
                    href: c,
                    to: u,
                    _isNavigate: !0
                })
            }, this.beforeLoad = () => {
                this.cancelMatches(), this.updateLatestLocation();
                const u = this.matchRoutes(this.latestLocation),
                    r = this.stores.cachedMatches.get().filter(c => !u.some(f => f.id === c.id));
                this.batch(() => {
                    this.stores.status.set("pending"), this.stores.statusCode.set(200), this.stores.isLoading.set(!0), this.stores.location.set(this.latestLocation), this.stores.setPending(u), this.stores.setCached(r)
                })
            }, this.load = async u => {
                let r, c, f;
                const h = this.stores.resolvedLocation.get() ? ? this.stores.location.get();
                for (f = new Promise(p => {
                        this.startTransition(async () => {
                            try {
                                this.beforeLoad();
                                const m = this.latestLocation,
                                    S = xl(m, this.stores.resolvedLocation.get());
                                this.stores.redirect.get() || this.emit({
                                    type: "onBeforeNavigate",
                                    ...S
                                }), this.emit({
                                    type: "onBeforeLoad",
                                    ...S
                                }), await Fm({
                                    router: this,
                                    sync: u ? .sync,
                                    forceStaleReload: h.href === m.href,
                                    matches: this.stores.pendingMatches.get(),
                                    location: m,
                                    updateMatch: this.updateMatch,
                                    onReady: async () => {
                                        this.startTransition(() => {
                                            this.startViewTransition(async () => {
                                                let g = null,
                                                    _ = null,
                                                    E = null,
                                                    O = null;
                                                this.batch(() => {
                                                    const w = this.stores.pendingMatches.get(),
                                                        A = w.length,
                                                        z = this.stores.matches.get();
                                                    g = A ? z.filter(H => !this.stores.pendingMatchStores.has(H.id)) : null;
                                                    const X = new Set;
                                                    for (const H of this.stores.pendingMatchStores.values()) H.routeId && X.add(H.routeId);
                                                    const Q = new Set;
                                                    for (const H of this.stores.matchStores.values()) H.routeId && Q.add(H.routeId);
                                                    _ = A ? z.filter(H => !X.has(H.routeId)) : null, E = A ? w.filter(H => !Q.has(H.routeId)) : null, O = A ? w.filter(H => Q.has(H.routeId)) : z, this.stores.isLoading.set(!1), this.stores.loadedAt.set(Date.now()), A && (this.stores.setMatches(w), this.stores.setPending([]), this.stores.setCached([...this.stores.cachedMatches.get(), ...g.filter(H => H.status !== "error" && H.status !== "notFound" && H.status !== "redirected")]), this.clearExpiredCache())
                                                });
                                                for (const [w, A] of [
                                                        [_, "onLeave"],
                                                        [E, "onEnter"],
                                                        [O, "onStay"]
                                                    ])
                                                    if (w)
                                                        for (const z of w) this.looseRoutesById[z.routeId].options[A] ? .(z)
                                            })
                                        })
                                    }
                                })
                            } catch (m) {
                                _e(m) ? (r = m, this.navigate({ ...r.options,
                                    replace: !0,
                                    ignoreBlocker: !0
                                })) : ne(m) && (c = m);
                                const S = r ? r.status : c ? 404 : this.stores.matches.get().some(g => g.status === "error") ? 500 : 200;
                                this.batch(() => {
                                    this.stores.statusCode.set(S), this.stores.redirect.set(r)
                                })
                            }
                            this.latestLoadPromise === f && (this.commitLocationPromise ? .resolve(), this.latestLoadPromise = void 0, this.commitLocationPromise = void 0), p()
                        })
                    }), this.latestLoadPromise = f, await f; this.latestLoadPromise && f !== this.latestLoadPromise;) await this.latestLoadPromise;
                let y;
                this.hasNotFoundMatch() ? y = 404 : this.stores.matches.get().some(p => p.status === "error") && (y = 500), y !== void 0 && this.stores.statusCode.set(y)
            }, this.startViewTransition = u => {
                const r = this.shouldViewTransition ? ? this.options.defaultViewTransition;
                if (this.shouldViewTransition = void 0, r && typeof document < "u" && "startViewTransition" in document && typeof document.startViewTransition == "function") {
                    let c;
                    if (typeof r == "object" && this.isViewTransitionTypesSupported) {
                        const f = this.latestLocation,
                            h = this.stores.resolvedLocation.get(),
                            y = typeof r.types == "function" ? r.types(xl(f, h)) : r.types;
                        if (y === !1) {
                            u();
                            return
                        }
                        c = {
                            update: u,
                            types: y
                        }
                    } else c = u;
                    document.startViewTransition(c)
                } else u()
            }, this.updateMatch = (u, r) => {
                this.startTransition(() => {
                    const c = this.stores.pendingMatchStores.get(u);
                    if (c) {
                        c.set(r);
                        return
                    }
                    const f = this.stores.matchStores.get(u);
                    if (f) {
                        f.set(r);
                        return
                    }
                    const h = this.stores.cachedMatchStores.get(u);
                    if (h) {
                        const y = r(h.get());
                        y.status === "redirected" ? this.stores.cachedMatchStores.delete(u) && this.stores.cachedIds.set(p => p.filter(m => m !== u)) : h.set(y)
                    }
                })
            }, this.getMatch = u => this.stores.cachedMatchStores.get(u) ? .get() ? ? this.stores.pendingMatchStores.get(u) ? .get() ? ? this.stores.matchStores.get(u) ? .get(), this.invalidate = u => {
                const r = c => u ? .filter ? .(c) ? ? !0 ? { ...c,
                    invalid: !0,
                    ...u ? .forcePending || c.status === "error" || c.status === "notFound" ? {
                        status: "pending",
                        error: void 0
                    } : void 0
                } : c;
                return this.batch(() => {
                    this.stores.setMatches(this.stores.matches.get().map(r)), this.stores.setCached(this.stores.cachedMatches.get().map(r)), this.stores.setPending(this.stores.pendingMatches.get().map(r))
                }), this.shouldViewTransition = !1, this.load({
                    sync: u ? .sync
                })
            }, this.getParsedLocationHref = u => u.publicHref || "/", this.resolveRedirect = u => {
                const r = u.headers.get("Location");
                if (!u.options.href || u.options._builtLocation) {
                    const c = u.options._builtLocation ? ? this.buildLocation(u.options),
                        f = this.getParsedLocationHref(c);
                    u.options.href = f, u.headers.set("Location", f)
                } else if (r) try {
                    const c = new URL(r);
                    if (this.origin && c.origin === this.origin) {
                        const f = c.pathname + c.search + c.hash;
                        u.options.href = f, u.headers.set("Location", f)
                    }
                } catch {}
                if (u.options.href && !u.options._builtLocation && ys(u.options.href, this.protocolAllowlist)) throw new Error("Redirect blocked: unsafe protocol");
                return u.headers.get("Location") || u.headers.set("Location", u.options.href), u
            }, this.clearCache = u => {
                const r = u ? .filter;
                r !== void 0 ? this.stores.setCached(this.stores.cachedMatches.get().filter(c => !r(c))) : this.stores.setCached([])
            }, this.clearExpiredCache = () => {
                const u = Date.now(),
                    r = c => {
                        const f = this.looseRoutesById[c.routeId];
                        if (!f.options.loader) return !0;
                        const h = (c.preload ? f.options.preloadGcTime ? ? this.options.defaultPreloadGcTime : f.options.gcTime ? ? this.options.defaultGcTime) ? ? 300 * 1e3;
                        return c.status === "error" ? !0 : u - c.updatedAt >= h
                    };
                this.clearCache({
                    filter: r
                })
            }, this.loadRouteChunk = qi, this.preloadRoute = async u => {
                const r = u._builtLocation ? ? this.buildLocation(u);
                let c = this.matchRoutes(r, {
                    throwOnError: !0,
                    preload: !0,
                    dest: u
                });
                const f = new Set([...this.stores.matchesId.get(), ...this.stores.pendingIds.get()]),
                    h = new Set([...f, ...this.stores.cachedIds.get()]),
                    y = c.filter(p => !h.has(p.id));
                if (y.length) {
                    const p = this.stores.cachedMatches.get();
                    this.stores.setCached([...p, ...y])
                }
                try {
                    return c = await Fm({
                        router: this,
                        matches: c,
                        location: r,
                        preload: !0,
                        updateMatch: (p, m) => {
                            f.has(p) ? c = c.map(S => S.id === p ? m(S) : S) : this.updateMatch(p, m)
                        }
                    }), c
                } catch (p) {
                    if (_e(p)) return p.options.reloadDocument ? void 0 : await this.preloadRoute({ ...p.options,
                        _fromLocation: r
                    });
                    ne(p) || console.error(p);
                    return
                }
            }, this.matchRoute = (u, r) => {
                const c = { ...u,
                        to: u.to ? this.resolvePathWithBase(u.from || "", u.to) : void 0,
                        params: u.params || {},
                        leaveParams: !0
                    },
                    f = this.buildLocation(c);
                if (r ? .pending && this.stores.status.get() !== "pending") return !1;
                const h = (r ? .pending === void 0 ? !this.stores.isLoading.get() : r.pending) ? this.latestLocation : this.stores.resolvedLocation.get() || this.stores.location.get(),
                    y = U0(f.pathname, r ? .caseSensitive ? ? !1, r ? .fuzzy ? ? !1, h.pathname, this.processedTree);
                return !y || u.params && !be(y.rawParams, u.params, {
                    partial: !0
                }) ? !1 : r ? .includeSearch ? ? !0 ? be(h.search, f.search, {
                    partial: !0
                }) ? y.rawParams : !1 : y.rawParams
            }, this.hasNotFoundMatch = () => this.stores.matches.get().some(u => u.status === "notFound" || u.globalNotFound), this.getStoreConfig = i, this.update({
                defaultPreloadDelay: 50,
                defaultPendingMs: 1e3,
                defaultPendingMinMs: 500,
                context: void 0,
                ...a,
                caseSensitive: a.caseSensitive ? ? !1,
                notFoundMode: a.notFoundMode ? ? "fuzzy",
                stringifySearch: a.stringifySearch ? ? W0,
                parseSearch: a.parseSearch ? ? I0,
                protocolAllowlist: a.protocolAllowlist ? ? A0
            }), typeof document < "u" && (self.__TSR_ROUTER__ = this)
        }
        isShell() {
            return !!this.options.isShell
        }
        isPrerendering() {
            return !!this.options.isPrerendering
        }
        get state() {
            return this.stores.__store.get()
        }
        setRoutes({
            routesById: a,
            routesByPath: i,
            processedTree: u
        }) {
            this.routesById = a, this.routesByPath = i, this.processedTree = u;
            const r = this.options.notFoundRoute;
            r && (r.init({
                originalIndex: 99999999999
            }), this.routesById[r.id] = r)
        }
        get looseRoutesById() {
            return this.routesById
        }
        getParentContext(a) {
            return a ? .id ? a.context ? ? this.options.context ? ? void 0 : this.options.context ? ? void 0
        }
        matchRoutesInternal(a, i) {
            const u = this.getMatchedRoutes(a.pathname),
                {
                    foundRoute: r,
                    routeParams: c,
                    parsedParams: f
                } = u;
            let {
                matchedRoutes: h
            } = u, y = !1;
            (r ? r.path !== "/" && c["**"] : na(a.pathname)) && (this.options.notFoundRoute ? h = [...h, this.options.notFoundRoute] : y = !0);
            const p = y ? _S(this.options.notFoundMode, h) : void 0,
                m = new Array(h.length),
                S = new Map;
            for (const g of this.stores.matchStores.values()) g.routeId && S.set(g.routeId, g.get());
            for (let g = 0; g < h.length; g++) {
                const _ = h[g],
                    E = m[g - 1];
                let O, w, A; {
                    const vt = E ? .search ? ? a.search,
                        Yt = E ? ._strictSearch ? ? void 0;
                    try {
                        const Ot = ds(_.options.validateSearch, { ...vt
                        }) ? ? void 0;
                        O = { ...vt,
                            ...Ot
                        }, w = { ...Yt,
                            ...Ot
                        }, A = void 0
                    } catch (Ot) {
                        let B = Ot;
                        if (Ot instanceof gs || (B = new gs(Ot.message, {
                                cause: Ot
                            })), i ? .throwOnError) throw B;
                        O = vt, w = {}, A = B
                    }
                }
                const z = _.options.loaderDeps ? .({
                        search: O
                    }) ? ? "",
                    X = z ? JSON.stringify(z) : "",
                    {
                        interpolatedPath: Q,
                        usedParams: H
                    } = Vm({
                        path: _.fullPath,
                        params: c,
                        decoder: this.pathParamsDecoder,
                        server: this.isServer
                    }),
                    W = _.id + Q + X,
                    F = this.getMatch(W),
                    V = S.get(_.id),
                    J = F ? ._strictParams ? ? H;
                let P;
                if (!F) try {
                    ey(_, H, f, J)
                } catch (vt) {
                    if (ne(vt) || _e(vt) ? P = vt : P = new pS(vt.message, {
                            cause: vt
                        }), i ? .throwOnError) throw P
                }
                Object.assign(c, J);
                const ut = V ? "stay" : "enter";
                let tt;
                if (F) tt = { ...F,
                    cause: ut,
                    params: V ? .params ? ? c,
                    _strictParams: J,
                    search: Ma(V ? V.search : F.search, O),
                    _strictSearch: w
                };
                else {
                    const vt = _.options.loader || _.options.beforeLoad || _.lazyFn || qy(_) ? "pending" : "success";
                    tt = {
                        id: W,
                        ssr: _.options.ssr,
                        index: g,
                        routeId: _.id,
                        params: V ? .params ? ? c,
                        _strictParams: J,
                        pathname: Q,
                        updatedAt: Date.now(),
                        search: V ? Ma(V.search, O) : O,
                        _strictSearch: w,
                        searchError: void 0,
                        status: vt,
                        isFetching: !1,
                        error: void 0,
                        paramsError: P,
                        __routeContext: void 0,
                        _nonReactive: {
                            loadPromise: Ua()
                        },
                        __beforeLoadContext: void 0,
                        context: {},
                        abortController: new AbortController,
                        fetchCount: 0,
                        cause: ut,
                        loaderDeps: V ? Oa(V.loaderDeps, z) : z,
                        invalid: !1,
                        preload: !1,
                        links: void 0,
                        scripts: void 0,
                        headScripts: void 0,
                        meta: void 0,
                        staticData: _.options.staticData || {},
                        fullPath: _.fullPath
                    }
                }
                i ? .preload || (tt.globalNotFound = p === _.id), tt.searchError = A;
                const dt = this.getParentContext(E);
                tt.context = { ...dt,
                    ...tt.__routeContext,
                    ...tt.__beforeLoadContext
                }, m[g] = tt
            }
            for (let g = 0; g < m.length; g++) {
                const _ = m[g],
                    E = this.looseRoutesById[_.routeId],
                    O = this.getMatch(_.id),
                    w = S.get(_.routeId);
                if (_.params = w ? Ma(w.params, c) : c, !O) {
                    const A = m[g - 1],
                        z = this.getParentContext(A);
                    if (E.options.context) {
                        const X = {
                            deps: _.loaderDeps,
                            params: _.params,
                            context: z ? ? {},
                            location: a,
                            navigate: Q => this.navigate({ ...Q,
                                _fromLocation: a
                            }),
                            buildLocation: this.buildLocation,
                            cause: _.cause,
                            abortController: _.abortController,
                            preload: !!_.preload,
                            matches: m,
                            routeId: E.id
                        };
                        _.__routeContext = E.options.context(X) ? ? void 0
                    }
                    _.context = { ...z,
                        ..._.__routeContext,
                        ..._.__beforeLoadContext
                    }
                }
            }
            return m
        }
        matchRoutesLightweight(a) {
            const {
                matchedRoutes: i,
                routeParams: u,
                parsedParams: r
            } = this.getMatchedRoutes(a.pathname), c = Bi(i), f = { ...a.search
            };
            for (const S of i) try {
                Object.assign(f, ds(S.options.validateSearch, f))
            } catch {}
            const h = Bi(this.stores.matchesId.get()),
                y = h && this.stores.matchStores.get(h) ? .get(),
                p = y && y.routeId === c.id && y.pathname === a.pathname;
            let m;
            if (p) m = y.params;
            else {
                const S = Object.assign(Object.create(null), u);
                for (const g of i) try {
                    ey(g, u, r ? ? {}, S)
                } catch {}
                m = S
            }
            return {
                matchedRoutes: i,
                fullPath: c.fullPath,
                search: f,
                params: m
            }
        }
    },
    gs = class extends Error {},
    pS = class extends Error {};

function vS(a) {
    return {
        loadedAt: 0,
        isLoading: !1,
        isTransitioning: !1,
        status: "idle",
        resolvedLocation: void 0,
        location: a,
        matches: [],
        statusCode: 200
    }
}

function ds(a, i) {
    if (a == null) return {};
    if ("~standard" in a) {
        const u = a["~standard"].validate(i);
        if (u instanceof Promise) throw new gs("Async validation not supported");
        if (u.issues) throw new gs(JSON.stringify(u.issues, void 0, 2), {
            cause: u
        });
        return u.value
    }
    return "parse" in a ? a.parse(i) : typeof a == "function" ? a(i) : {}
}

function gS({
    pathname: a,
    routesById: i,
    processedTree: u
}) {
    const r = Object.create(null),
        c = na(a);
    let f, h;
    const y = N0(c, u, !0);
    return y && (f = y.route, Object.assign(r, y.rawParams), h = Object.assign(Object.create(null), y.parsedParams)), {
        matchedRoutes: y ? .branch || [i.__root__],
        routeParams: r,
        foundRoute: f,
        parsedParams: h
    }
}

function SS({
    search: a,
    dest: i,
    destRoutes: u,
    _includeValidateSearch: r
}) {
    return bS(u)(a, i, r ? ? !1)
}

function bS(a) {
    const i = {
        dest: null,
        _includeValidateSearch: !1,
        middlewares: []
    };
    for (const c of a) {
        if ("search" in c.options) c.options.search ? .middlewares && i.middlewares.push(...c.options.search.middlewares);
        else if (c.options.preSearchFilters || c.options.postSearchFilters) {
            const f = ({
                search: h,
                next: y
            }) => {
                let p = h;
                "preSearchFilters" in c.options && c.options.preSearchFilters && (p = c.options.preSearchFilters.reduce((S, g) => g(S), h));
                const m = y(p);
                return "postSearchFilters" in c.options && c.options.postSearchFilters ? c.options.postSearchFilters.reduce((S, g) => g(S), m) : m
            };
            i.middlewares.push(f)
        }
        if (c.options.validateSearch) {
            const f = ({
                search: h,
                next: y
            }) => {
                const p = y(h);
                if (!i._includeValidateSearch) return p;
                try {
                    return { ...p,
                        ...ds(c.options.validateSearch, p) ? ? void 0
                    }
                } catch {
                    return p
                }
            };
            i.middlewares.push(f)
        }
    }
    const u = ({
        search: c
    }) => {
        const f = i.dest;
        return f.search ? f.search === !0 ? c : ta(f.search, c) : {}
    };
    i.middlewares.push(u);
    const r = (c, f, h) => {
        if (c >= h.length) return f;
        const y = h[c];
        return y({
            search: f,
            next: m => r(c + 1, m, h)
        })
    };
    return function(f, h, y) {
        return i.dest = h, i._includeValidateSearch = y, r(0, f, i.middlewares)
    }
}

function _S(a, i) {
    if (a !== "root")
        for (let u = i.length - 1; u >= 0; u--) {
            const r = i[u];
            if (r.children) return r.id
        }
    return Da
}

function ey(a, i, u, r) {
    const c = a.options.params ? .parse ? ? a.options.parseParams;
    if (c)
        if (a.options.skipRouteOnParseError)
            for (const f in i) f in u && (r[f] = u[f]);
        else {
            const f = c(r);
            Object.assign(r, f)
        }
}
var $e = Symbol.for("TSR_DEFERRED_PROMISE");

function ES(a, i) {
    const u = a;
    return u[$e] || (u[$e] = {
        status: "pending"
    }, u.then(r => {
        u[$e].status = "success", u[$e].data = r
    }).catch(r => {
        u[$e].status = "error", u[$e].error = {
            data: mS(r),
            __isServerError: !0
        }
    })), u
}
var RS = "Error preloading route! ☝️";

function ny(a, i) {
    if (a) return typeof a == "string" ? a : a[i]
}

function TS(a) {
    return typeof a == "string" ? {
        href: a,
        crossOrigin: void 0
    } : a
}
var Yy = class {
        get to() {
            return this._to
        }
        get id() {
            return this._id
        }
        get path() {
            return this._path
        }
        get fullPath() {
            return this._fullPath
        }
        constructor(a) {
            if (this.init = i => {
                    this.originalIndex = i.originalIndex;
                    const u = this.options,
                        r = !u ? .path && !u ? .id;
                    this.parentRoute = this.options.getParentRoute ? .(), r ? this._path = Da : this.parentRoute || Ee();
                    let c = r ? Da : u ? .path;
                    c && c !== "/" && (c = wy(c));
                    const f = u ? .id || c;
                    let h = r ? Da : cs([this.parentRoute.id === "__root__" ? "" : this.parentRoute.id, f]);
                    c === "__root__" && (c = "/"), h !== "__root__" && (h = cs(["/", h]));
                    const y = h === "__root__" ? "/" : cs([this.parentRoute.fullPath, c]);
                    this._path = c, this._id = h, this._fullPath = y, this._to = na(y)
                }, this.addChildren = i => this._addFileChildren(i), this._addFileChildren = i => (Array.isArray(i) && (this.children = i), typeof i == "object" && i !== null && (this.children = Object.values(i)), this), this._addFileTypes = () => this, this.updateLoader = i => (Object.assign(this.options, i), this), this.update = i => (Object.assign(this.options, i), this), this.lazy = i => (this.lazyFn = i, this), this.redirect = i => Uy({
                    from: this.fullPath,
                    ...i
                }), this.options = a || {}, this.isRoot = !a ? .getParentRoute, a ? .id && a ? .path) throw new Error("Route cannot have both an 'id' and a 'path' option.")
        }
    },
    AS = class extends Yy {
        constructor(a) {
            super(a)
        }
    };

function xS(a) {
    if (typeof document < "u" && document.querySelector) {
        const i = a.stores.location.get(),
            u = i.state.__hashScrollIntoViewOptions ? ? !0;
        if (u && i.hash !== "") {
            const r = document.getElementById(i.hash);
            r && r.scrollIntoView(u)
        }
    }
}
var MS = (a => (a[a.AggregateError = 1] = "AggregateError", a[a.ArrowFunction = 2] = "ArrowFunction", a[a.ErrorPrototypeStack = 4] = "ErrorPrototypeStack", a[a.ObjectAssign = 8] = "ObjectAssign", a[a.BigIntTypedArray = 16] = "BigIntTypedArray", a[a.RegExp = 32] = "RegExp", a))(MS || {}),
    Rn = Symbol.asyncIterator,
    Gy = Symbol.hasInstance,
    Ml = Symbol.isConcatSpreadable,
    Tn = Symbol.iterator,
    Xy = Symbol.match,
    Vy = Symbol.matchAll,
    Qy = Symbol.replace,
    Zy = Symbol.search,
    Ky = Symbol.species,
    Jy = Symbol.split,
    ky = Symbol.toPrimitive,
    Ol = Symbol.toStringTag,
    Py = Symbol.unscopables,
    Fy = {
        [Rn]: 0,
        [Gy]: 1,
        [Ml]: 2,
        [Tn]: 3,
        [Xy]: 4,
        [Vy]: 5,
        [Qy]: 6,
        [Zy]: 7,
        [Ky]: 8,
        [Jy]: 9,
        [ky]: 10,
        [Ol]: 11,
        [Py]: 12
    },
    OS = {
        0: Rn,
        1: Gy,
        2: Ml,
        3: Tn,
        4: Xy,
        5: Vy,
        6: Qy,
        7: Zy,
        8: Ky,
        9: Jy,
        10: ky,
        11: Ol,
        12: Py
    },
    b = void 0,
    zS = {
        2: !0,
        3: !1,
        1: b,
        0: null,
        4: -0,
        5: Number.POSITIVE_INFINITY,
        6: Number.NEGATIVE_INFINITY,
        7: Number.NaN
    },
    CS = {
        0: "Error",
        1: "EvalError",
        2: "RangeError",
        3: "ReferenceError",
        4: "SyntaxError",
        5: "TypeError",
        6: "URIError"
    },
    wS = {
        0: Error,
        1: EvalError,
        2: RangeError,
        3: ReferenceError,
        4: SyntaxError,
        5: TypeError,
        6: URIError
    };

function Et(a, i, u, r, c, f, h, y, p, m, S, g) {
    return {
        t: a,
        i,
        s: u,
        c: r,
        m: c,
        p: f,
        e: h,
        a: y,
        f: p,
        b: m,
        o: S,
        l: g
    }
}

function la(a) {
    return Et(2, b, a, b, b, b, b, b, b, b, b, b)
}
var Iy = la(2),
    Wy = la(3),
    DS = la(1),
    LS = la(0),
    US = la(4),
    NS = la(5),
    BS = la(6),
    jS = la(7);

function HS(a) {
    switch (a) {
        case '"':
            return '\\"';
        case "\\":
            return "\\\\";
        case `
`:
            return "\\n";
        case "\r":
            return "\\r";
        case "\b":
            return "\\b";
        case "	":
            return "\\t";
        case "\f":
            return "\\f";
        case "<":
            return "\\x3C";
        case "\u2028":
            return "\\u2028";
        case "\u2029":
            return "\\u2029";
        default:
            return b
    }
}

function ia(a) {
    let i = "",
        u = 0,
        r;
    for (let c = 0, f = a.length; c < f; c++) r = HS(a[c]), r && (i += a.slice(u, c) + r, u = c + 1);
    return u === 0 ? i = a : i += a.slice(u), i
}

function qS(a) {
    switch (a) {
        case "\\\\":
            return "\\";
        case '\\"':
            return '"';
        case "\\n":
            return `
`;
        case "\\r":
            return "\r";
        case "\\b":
            return "\b";
        case "\\t":
            return "	";
        case "\\f":
            return "\f";
        case "\\x3C":
            return "<";
        case "\\u2028":
            return "\u2028";
        case "\\u2029":
            return "\u2029";
        default:
            return a
    }
}

function ua(a) {
    return a.replace(/(\\\\|\\"|\\n|\\r|\\b|\\t|\\f|\\u2028|\\u2029|\\x3C)/g, qS)
}
var rs = "__SEROVAL_REFS__",
    $y = new Map,
    Al = new Map;

function tp(a) {
    return $y.has(a)
}

function YS(a) {
    return Al.has(a)
}

function GS(a) {
    if (tp(a)) return $y.get(a);
    throw new g1(a)
}

function XS(a) {
    if (YS(a)) return Al.get(a);
    throw new S1(a)
}
typeof globalThis < "u" ? Object.defineProperty(globalThis, rs, {
    value: Al,
    configurable: !0,
    writable: !1,
    enumerable: !1
}) : typeof window < "u" ? Object.defineProperty(window, rs, {
    value: Al,
    configurable: !0,
    writable: !1,
    enumerable: !1
}) : typeof self < "u" ? Object.defineProperty(self, rs, {
    value: Al,
    configurable: !0,
    writable: !1,
    enumerable: !1
}) : typeof global < "u" && Object.defineProperty(global, rs, {
    value: Al,
    configurable: !0,
    writable: !1,
    enumerable: !1
});

function Rc(a) {
    return a instanceof EvalError ? 1 : a instanceof RangeError ? 2 : a instanceof ReferenceError ? 3 : a instanceof SyntaxError ? 4 : a instanceof TypeError ? 5 : a instanceof URIError ? 6 : 0
}

function VS(a) {
    let i = CS[Rc(a)];
    return a.name !== i ? {
        name: a.name
    } : a.constructor.name !== i ? {
        name: a.constructor.name
    } : {}
}

function ep(a, i) {
    let u = VS(a),
        r = Object.getOwnPropertyNames(a);
    for (let c = 0, f = r.length, h; c < f; c++) h = r[c], h !== "name" && h !== "message" && (h === "stack" ? i & 4 && (u = u || {}, u[h] = a[h]) : (u = u || {}, u[h] = a[h]));
    return u
}

function np(a) {
    return Object.isFrozen(a) ? 3 : Object.isSealed(a) ? 2 : Object.isExtensible(a) ? 0 : 1
}

function QS(a) {
    switch (a) {
        case Number.POSITIVE_INFINITY:
            return NS;
        case Number.NEGATIVE_INFINITY:
            return BS
    }
    return a !== a ? jS : Object.is(a, -0) ? US : Et(0, b, a, b, b, b, b, b, b, b, b, b)
}

function ap(a) {
    return Et(1, b, ia(a), b, b, b, b, b, b, b, b, b)
}

function ZS(a) {
    return Et(3, b, "" + a, b, b, b, b, b, b, b, b, b)
}

function KS(a) {
    return Et(4, a, b, b, b, b, b, b, b, b, b, b)
}

function JS(a, i) {
    let u = i.valueOf();
    return Et(5, a, u !== u ? "" : i.toISOString(), b, b, b, b, b, b, b, b, b)
}

function kS(a, i) {
    return Et(6, a, b, ia(i.source), i.flags, b, b, b, b, b, b, b)
}

function PS(a, i) {
    return Et(17, a, Fy[i], b, b, b, b, b, b, b, b, b)
}

function FS(a, i) {
    return Et(18, a, ia(GS(i)), b, b, b, b, b, b, b, b, b)
}

function IS(a, i, u) {
    return Et(25, a, u, ia(i), b, b, b, b, b, b, b, b)
}

function WS(a, i, u) {
    return Et(9, a, b, b, b, b, b, u, b, b, np(i), b)
}

function $S(a, i) {
    return Et(21, a, b, b, b, b, b, b, i, b, b, b)
}

function t1(a, i, u) {
    return Et(15, a, b, i.constructor.name, b, b, b, b, u, i.byteOffset, b, i.length)
}

function e1(a, i, u) {
    return Et(16, a, b, i.constructor.name, b, b, b, b, u, i.byteOffset, b, i.byteLength)
}

function n1(a, i, u) {
    return Et(20, a, b, b, b, b, b, b, u, i.byteOffset, b, i.byteLength)
}

function a1(a, i, u) {
    return Et(13, a, Rc(i), b, ia(i.message), u, b, b, b, b, b, b)
}

function l1(a, i, u) {
    return Et(14, a, Rc(i), b, ia(i.message), u, b, b, b, b, b, b)
}

function i1(a, i) {
    return Et(7, a, b, b, b, b, b, i, b, b, b, b)
}

function u1(a, i) {
    return Et(28, b, b, b, b, b, b, [a, i], b, b, b, b)
}

function s1(a, i) {
    return Et(30, b, b, b, b, b, b, [a, i], b, b, b, b)
}

function r1(a, i, u) {
    return Et(31, a, b, b, b, b, b, u, i, b, b, b)
}

function o1(a, i) {
    return Et(32, a, b, b, b, b, b, b, i, b, b, b)
}

function c1(a, i) {
    return Et(33, a, b, b, b, b, b, b, i, b, b, b)
}

function f1(a, i) {
    return Et(34, a, b, b, b, b, b, b, i, b, b, b)
}

function d1(a, i, u, r) {
    return Et(35, a, u, b, b, b, b, i, b, b, b, r)
}
var h1 = {
    parsing: 1,
    serialization: 2,
    deserialization: 3
};

function m1(a) {
    return `Seroval Error (step: ${h1[a]})`
}
var y1 = (a, i) => m1(a),
    lp = class extends Error {
        constructor(a, i) {
            super(y1(a)), this.cause = i
        }
    },
    ay = class extends lp {
        constructor(a) {
            super("parsing", a)
        }
    },
    p1 = class extends lp {
        constructor(a) {
            super("deserialization", a)
        }
    };

function An(a) {
    return `Seroval Error (specific: ${a})`
}
var Ts = class extends Error {
        constructor(i) {
            super(An(1)), this.value = i
        }
    },
    ip = class extends Error {
        constructor(i) {
            super(An(2))
        }
    },
    v1 = class extends Error {
        constructor(a) {
            super(An(3))
        }
    },
    Xi = class extends Error {
        constructor(a) {
            super(An(4))
        }
    },
    g1 = class extends Error {
        constructor(a) {
            super(An(5)), this.value = a
        }
    },
    S1 = class extends Error {
        constructor(a) {
            super(An(6))
        }
    },
    b1 = class extends Error {
        constructor(a) {
            super(An(7))
        }
    },
    sa = class extends Error {
        constructor(a) {
            super(An(8))
        }
    },
    _1 = class extends Error {
        constructor(i) {
            super(An(9))
        }
    },
    E1 = class {
        constructor(a, i) {
            this.value = a, this.replacement = i
        }
    },
    As = () => {
        let a = {
            p: 0,
            s: 0,
            f: 0
        };
        return a.p = new Promise((i, u) => {
            a.s = i, a.f = u
        }), a
    },
    R1 = (a, i) => {
        a.s(i), a.p.s = 1, a.p.v = i
    },
    T1 = (a, i) => {
        a.f(i), a.p.s = 2, a.p.v = i
    };
As.toString();
R1.toString();
T1.toString();
var A1 = () => {
        let a = [],
            i = [],
            u = !0,
            r = !1,
            c = 0,
            f = (p, m, S) => {
                for (S = 0; S < c; S++) i[S] && i[S][m](p)
            },
            h = (p, m, S, g) => {
                for (m = 0, S = a.length; m < S; m++) g = a[m], !u && m === S - 1 ? p[r ? "return" : "throw"](g) : p.next(g)
            },
            y = (p, m) => (u && (m = c++, i[m] = p), h(p), () => {
                u && (i[m] = i[c], i[c--] = void 0)
            });
        return {
            __SEROVAL_STREAM__: !0,
            on: p => y(p),
            next: p => {
                u && (a.push(p), f(p, "next"))
            },
            throw: p => {
                u && (a.push(p), f(p, "throw"), u = !1, r = !1, i.length = 0)
            },
            return: p => {
                u && (a.push(p), f(p, "return"), u = !1, r = !0, i.length = 0)
            }
        }
    },
    x1 = a => i => () => {
        let u = 0,
            r = {
                [a]: () => r,
                next: () => {
                    if (u > i.d) return {
                        done: !0,
                        value: void 0
                    };
                    let c = u++,
                        f = i.v[c];
                    if (c === i.t) throw f;
                    return {
                        done: c === i.d,
                        value: f
                    }
                }
            };
        return r
    },
    M1 = (a, i) => u => () => {
        let r = 0,
            c = -1,
            f = !1,
            h = [],
            y = [],
            p = (S = 0, g = y.length) => {
                for (; S < g; S++) y[S].s({
                    done: !0,
                    value: void 0
                })
            };
        u.on({
            next: S => {
                let g = y.shift();
                g && g.s({
                    done: !1,
                    value: S
                }), h.push(S)
            },
            throw: S => {
                let g = y.shift();
                g && g.f(S), p(), c = h.length, f = !0, h.push(S)
            },
            return: S => {
                let g = y.shift();
                g && g.s({
                    done: !0,
                    value: S
                }), p(), c = h.length, h.push(S)
            }
        });
        let m = {
            [a]: () => m,
            next: () => {
                if (c === -1) {
                    let _ = r++;
                    if (_ >= h.length) {
                        let E = i();
                        return y.push(E), E.p
                    }
                    return {
                        done: !1,
                        value: h[_]
                    }
                }
                if (r > c) return {
                    done: !0,
                    value: void 0
                };
                let S = r++,
                    g = h[S];
                if (S !== c) return {
                    done: !1,
                    value: g
                };
                if (f) throw g;
                return {
                    done: !0,
                    value: g
                }
            }
        };
        return m
    },
    up = a => {
        let i = atob(a),
            u = i.length,
            r = new Uint8Array(u);
        for (let c = 0; c < u; c++) r[c] = i.charCodeAt(c);
        return r.buffer
    };
up.toString();

function O1(a) {
    return "__SEROVAL_SEQUENCE__" in a
}

function sp(a, i, u) {
    return {
        __SEROVAL_SEQUENCE__: !0,
        v: a,
        t: i,
        d: u
    }
}

function z1(a) {
    let i = [],
        u = -1,
        r = -1,
        c = a[Tn]();
    for (;;) try {
        let f = c.next();
        if (i.push(f.value), f.done) {
            r = i.length - 1;
            break
        }
    } catch (f) {
        u = i.length, i.push(f)
    }
    return sp(i, u, r)
}
var C1 = x1(Tn);

function w1(a) {
    return C1(a)
}
var D1 = {},
    L1 = {},
    U1 = {
        0: {},
        1: {},
        2: {},
        3: {},
        4: {},
        5: {}
    };

function xs(a) {
    return "__SEROVAL_STREAM__" in a
}

function Na() {
    return A1()
}

function N1(a) {
    let i = Na(),
        u = a[Rn]();
    async function r() {
        try {
            let c = await u.next();
            c.done ? i.return(c.value) : (i.next(c.value), await r())
        } catch (c) {
            i.throw(c)
        }
    }
    return r().catch(() => {}), i
}
var B1 = M1(Rn, As);

function j1(a) {
    return B1(a)
}
async function H1(a) {
    try {
        return [1, await a]
    } catch (i) {
        return [0, i]
    }
}

function q1(a, i) {
    return {
        plugins: i.plugins,
        mode: a,
        marked: new Set,
        features: 63 ^ (i.disabledFeatures || 0),
        refs: i.refs || new Map,
        depthLimit: i.depthLimit || 1e3
    }
}

function hs(a, i) {
    a.marked.add(i)
}

function Y1(a, i) {
    let u = a.refs.size;
    return a.refs.set(i, u), u
}

function Ms(a, i) {
    let u = a.refs.get(i);
    return u != null ? (hs(a, u), {
        type: 1,
        value: KS(u)
    }) : {
        type: 0,
        value: Y1(a, i)
    }
}

function Tc(a, i) {
    let u = Ms(a, i);
    return u.type === 1 ? u : tp(i) ? {
        type: 2,
        value: FS(u.value, i)
    } : u
}

function wa(a, i) {
    let u = Tc(a, i);
    if (u.type !== 0) return u.value;
    if (i in Fy) return PS(u.value, i);
    throw new Ts(i)
}

function Os(a, i) {
    let u = Ms(a, U1[i]);
    return u.type === 1 ? u.value : Et(26, u.value, i, b, b, b, b, b, b, b, b, b)
}

function G1(a) {
    let i = Ms(a, D1);
    return i.type === 1 ? i.value : Et(27, i.value, b, b, b, b, b, b, wa(a, Tn), b, b, b)
}

function X1(a) {
    let i = Ms(a, L1);
    return i.type === 1 ? i.value : Et(29, i.value, b, b, b, b, b, [Os(a, 1), wa(a, Rn)], b, b, b, b)
}

function V1(a, i, u, r) {
    return Et(u ? 11 : 10, a, b, b, b, r, b, b, b, b, np(i), b)
}

function Q1(a, i, u, r) {
    return Et(8, i, b, b, b, b, {
        k: u,
        v: r
    }, b, Os(a, 0), b, b, b)
}

function Z1(a, i, u) {
    let r = new Uint8Array(u),
        c = "";
    for (let f = 0, h = r.length; f < h; f++) c += String.fromCharCode(r[f]);
    return Et(19, i, ia(btoa(c)), b, b, b, b, b, Os(a, 5), b, b, b)
}

function K1(a, i) {
    return {
        base: q1(a, i),
        child: void 0
    }
}
var J1 = class {
    constructor(a, i) {
        this._p = a, this.depth = i
    }
    parse(a) {
        return Wt(this._p, this.depth, a)
    }
};
async function k1(a, i, u) {
    let r = [];
    for (let c = 0, f = u.length; c < f; c++) c in u ? r[c] = await Wt(a, i, u[c]) : r[c] = 0;
    return r
}
async function P1(a, i, u, r) {
    return WS(u, r, await k1(a, i, r))
}
async function Ac(a, i, u) {
    let r = Object.entries(u),
        c = [],
        f = [];
    for (let h = 0, y = r.length; h < y; h++) c.push(ia(r[h][0])), f.push(await Wt(a, i, r[h][1]));
    return Tn in u && (c.push(wa(a.base, Tn)), f.push(u1(G1(a.base), await Wt(a, i, z1(u))))), Rn in u && (c.push(wa(a.base, Rn)), f.push(s1(X1(a.base), await Wt(a, i, N1(u))))), Ol in u && (c.push(wa(a.base, Ol)), f.push(ap(u[Ol]))), Ml in u && (c.push(wa(a.base, Ml)), f.push(u[Ml] ? Iy : Wy)), {
        k: c,
        v: f
    }
}
async function ac(a, i, u, r, c) {
    return V1(u, r, c, await Ac(a, i, r))
}
async function F1(a, i, u, r) {
    return $S(u, await Wt(a, i, r.valueOf()))
}
async function I1(a, i, u, r) {
    return t1(u, r, await Wt(a, i, r.buffer))
}
async function W1(a, i, u, r) {
    return e1(u, r, await Wt(a, i, r.buffer))
}
async function $1(a, i, u, r) {
    return n1(u, r, await Wt(a, i, r.buffer))
}
async function ly(a, i, u, r) {
    let c = ep(r, a.base.features);
    return a1(u, r, c ? await Ac(a, i, c) : b)
}
async function tb(a, i, u, r) {
    let c = ep(r, a.base.features);
    return l1(u, r, c ? await Ac(a, i, c) : b)
}
async function eb(a, i, u, r) {
    let c = [],
        f = [];
    for (let [h, y] of r.entries()) c.push(await Wt(a, i, h)), f.push(await Wt(a, i, y));
    return Q1(a.base, u, c, f)
}
async function nb(a, i, u, r) {
    let c = [];
    for (let f of r.keys()) c.push(await Wt(a, i, f));
    return i1(u, c)
}
async function rp(a, i, u, r) {
    let c = a.base.plugins;
    if (c)
        for (let f = 0, h = c.length; f < h; f++) {
            let y = c[f];
            if (y.parse.async && y.test(r)) return IS(u, y.tag, await y.parse.async(r, new J1(a, i), {
                id: u
            }))
        }
    return b
}
async function ab(a, i, u, r) {
    let [c, f] = await H1(r);
    return Et(12, u, c, b, b, b, b, b, await Wt(a, i, f), b, b, b)
}

function lb(a, i, u, r, c) {
    let f = [],
        h = u.on({
            next: y => {
                hs(this.base, i), Wt(this, a, y).then(p => {
                    f.push(o1(i, p))
                }, p => {
                    c(p), h()
                })
            },
            throw: y => {
                hs(this.base, i), Wt(this, a, y).then(p => {
                    f.push(c1(i, p)), r(f), h()
                }, p => {
                    c(p), h()
                })
            },
            return: y => {
                hs(this.base, i), Wt(this, a, y).then(p => {
                    f.push(f1(i, p)), r(f), h()
                }, p => {
                    c(p), h()
                })
            }
        })
}
async function ib(a, i, u, r) {
    return r1(u, Os(a.base, 4), await new Promise(lb.bind(a, i, u, r)))
}
async function ub(a, i, u, r) {
    let c = [];
    for (let f = 0, h = r.v.length; f < h; f++) c[f] = await Wt(a, i, r.v[f]);
    return d1(u, c, r.t, r.d)
}
async function sb(a, i, u, r) {
    if (Array.isArray(r)) return P1(a, i, u, r);
    if (xs(r)) return ib(a, i, u, r);
    if (O1(r)) return ub(a, i, u, r);
    let c = r.constructor;
    if (c === E1) return Wt(a, i, r.replacement);
    let f = await rp(a, i, u, r);
    if (f) return f;
    switch (c) {
        case Object:
            return ac(a, i, u, r, !1);
        case b:
            return ac(a, i, u, r, !0);
        case Date:
            return JS(u, r);
        case Error:
        case EvalError:
        case RangeError:
        case ReferenceError:
        case SyntaxError:
        case TypeError:
        case URIError:
            return ly(a, i, u, r);
        case Number:
        case Boolean:
        case String:
        case BigInt:
            return F1(a, i, u, r);
        case ArrayBuffer:
            return Z1(a.base, u, r);
        case Int8Array:
        case Int16Array:
        case Int32Array:
        case Uint8Array:
        case Uint16Array:
        case Uint32Array:
        case Uint8ClampedArray:
        case Float32Array:
        case Float64Array:
            return I1(a, i, u, r);
        case DataView:
            return $1(a, i, u, r);
        case Map:
            return eb(a, i, u, r);
        case Set:
            return nb(a, i, u, r)
    }
    if (c === Promise || r instanceof Promise) return ab(a, i, u, r);
    let h = a.base.features;
    if (h & 32 && c === RegExp) return kS(u, r);
    if (h & 16) switch (c) {
        case BigInt64Array:
        case BigUint64Array:
            return W1(a, i, u, r)
    }
    if (h & 1 && typeof AggregateError < "u" && (c === AggregateError || r instanceof AggregateError)) return tb(a, i, u, r);
    if (r instanceof Error) return ly(a, i, u, r);
    if (Tn in r || Rn in r) return ac(a, i, u, r, !!c);
    throw new Ts(r)
}
async function rb(a, i, u) {
    let r = Tc(a.base, u);
    if (r.type !== 0) return r.value;
    let c = await rp(a, i, r.value, u);
    if (c) return c;
    throw new Ts(u)
}
async function Wt(a, i, u) {
    switch (typeof u) {
        case "boolean":
            return u ? Iy : Wy;
        case "undefined":
            return DS;
        case "string":
            return ap(u);
        case "number":
            return QS(u);
        case "bigint":
            return ZS(u);
        case "object":
            {
                if (u) {
                    let r = Tc(a.base, u);
                    return r.type === 0 ? await sb(a, i + 1, r.value, u) : r.value
                }
                return LS
            }
        case "symbol":
            return wa(a.base, u);
        case "function":
            return rb(a, i, u);
        default:
            throw new Ts(u)
    }
}
async function ob(a, i) {
    try {
        return await Wt(a, 0, i)
    } catch (u) {
        throw u instanceof ay ? u : new ay(u)
    }
}
var cb = (a => (a[a.Vanilla = 1] = "Vanilla", a[a.Cross = 2] = "Cross", a))(cb || {});

function op(a, i) {
    for (let u = 0, r = i.length; u < r; u++) {
        let c = i[u];
        a.has(c) || (a.add(c), c.extends && op(a, c.extends))
    }
}

function cp(a) {
    if (a) {
        let i = new Set;
        return op(i, a), [...i]
    }
}

function fb(a) {
    switch (a) {
        case "Int8Array":
            return Int8Array;
        case "Int16Array":
            return Int16Array;
        case "Int32Array":
            return Int32Array;
        case "Uint8Array":
            return Uint8Array;
        case "Uint16Array":
            return Uint16Array;
        case "Uint32Array":
            return Uint32Array;
        case "Uint8ClampedArray":
            return Uint8ClampedArray;
        case "Float32Array":
            return Float32Array;
        case "Float64Array":
            return Float64Array;
        case "BigInt64Array":
            return BigInt64Array;
        case "BigUint64Array":
            return BigUint64Array;
        default:
            throw new b1(a)
    }
}
var db = 1e6,
    hb = 1e4,
    mb = 2e4;

function fp(a, i) {
    switch (i) {
        case 3:
            return Object.freeze(a);
        case 1:
            return Object.preventExtensions(a);
        case 2:
            return Object.seal(a);
        default:
            return a
    }
}
var yb = 1e3;

function pb(a, i) {
    var u;
    return {
        mode: a,
        plugins: i.plugins,
        refs: i.refs || new Map,
        features: (u = i.features) != null ? u : 63 ^ (i.disabledFeatures || 0),
        depthLimit: i.depthLimit || yb
    }
}

function vb(a) {
    return {
        mode: 2,
        base: pb(2, a),
        child: b
    }
}
var gb = class {
    constructor(a, i) {
        this._p = a, this.depth = i
    }
    deserialize(a) {
        return Ut(this._p, this.depth, a)
    }
};

function dp(a, i) {
    if (i < 0 || !Number.isFinite(i) || !Number.isInteger(i)) throw new sa({
        t: 4,
        i
    });
    if (a.refs.has(i)) throw new Error("Conflicted ref id: " + i)
}

function Sb(a, i, u) {
    return dp(a.base, i), a.state.marked.has(i) && a.base.refs.set(i, u), u
}

function bb(a, i, u) {
    return dp(a.base, i), a.base.refs.set(i, u), u
}

function $t(a, i, u) {
    return a.mode === 1 ? Sb(a, i, u) : bb(a, i, u)
}

function mc(a, i, u) {
    if (Object.hasOwn(i, u)) return i[u];
    throw new sa(a)
}

function _b(a, i) {
    return $t(a, i.i, XS(ua(i.s)))
}

function Eb(a, i, u) {
    let r = u.a,
        c = r.length,
        f = $t(a, u.i, new Array(c));
    for (let h = 0, y; h < c; h++) y = r[h], y && (f[h] = Ut(a, i, y));
    return fp(f, u.o), f
}

function Rb(a) {
    switch (a) {
        case "constructor":
        case "__proto__":
        case "prototype":
        case "__defineGetter__":
        case "__defineSetter__":
        case "__lookupGetter__":
        case "__lookupSetter__":
            return !1;
        default:
            return !0
    }
}

function Tb(a) {
    switch (a) {
        case Rn:
        case Ml:
        case Ol:
        case Tn:
            return !0;
        default:
            return !1
    }
}

function iy(a, i, u) {
    Rb(i) ? a[i] = u : Object.defineProperty(a, i, {
        value: u,
        configurable: !0,
        enumerable: !0,
        writable: !0
    })
}

function Ab(a, i, u, r, c) {
    if (typeof r == "string") iy(u, ua(r), Ut(a, i, c));
    else {
        let f = Ut(a, i, r);
        switch (typeof f) {
            case "string":
                iy(u, f, Ut(a, i, c));
                break;
            case "symbol":
                Tb(f) && (u[f] = Ut(a, i, c));
                break;
            default:
                throw new sa(r)
        }
    }
}

function hp(a, i, u, r) {
    let c = u.k;
    if (c.length > 0)
        for (let f = 0, h = u.v, y = c.length; f < y; f++) Ab(a, i, r, c[f], h[f]);
    return r
}

function xb(a, i, u) {
    let r = $t(a, u.i, u.t === 10 ? {} : Object.create(null));
    return hp(a, i, u.p, r), fp(r, u.o), r
}

function Mb(a, i) {
    return $t(a, i.i, new Date(i.s))
}

function Ob(a, i) {
    if (a.base.features & 32) {
        let u = ua(i.c);
        if (u.length > mb) throw new sa(i);
        return $t(a, i.i, new RegExp(u, i.m))
    }
    throw new ip(i)
}

function zb(a, i, u) {
    let r = $t(a, u.i, new Set);
    for (let c = 0, f = u.a, h = f.length; c < h; c++) r.add(Ut(a, i, f[c]));
    return r
}

function Cb(a, i, u) {
    let r = $t(a, u.i, new Map);
    for (let c = 0, f = u.e.k, h = u.e.v, y = f.length; c < y; c++) r.set(Ut(a, i, f[c]), Ut(a, i, h[c]));
    return r
}

function wb(a, i) {
    if (i.s.length > db) throw new sa(i);
    return $t(a, i.i, up(ua(i.s)))
}

function Db(a, i, u) {
    var r;
    let c = fb(u.c),
        f = Ut(a, i, u.f),
        h = (r = u.b) != null ? r : 0;
    if (h < 0 || h > f.byteLength) throw new sa(u);
    return $t(a, u.i, new c(f, h, u.l))
}

function Lb(a, i, u) {
    var r;
    let c = Ut(a, i, u.f),
        f = (r = u.b) != null ? r : 0;
    if (f < 0 || f > c.byteLength) throw new sa(u);
    return $t(a, u.i, new DataView(c, f, u.l))
}

function mp(a, i, u, r) {
    if (u.p) {
        let c = hp(a, i, u.p, {});
        Object.defineProperties(r, Object.getOwnPropertyDescriptors(c))
    }
    return r
}

function Ub(a, i, u) {
    let r = $t(a, u.i, new AggregateError([], ua(u.m)));
    return mp(a, i, u, r)
}

function Nb(a, i, u) {
    let r = mc(u, wS, u.s),
        c = $t(a, u.i, new r(ua(u.m)));
    return mp(a, i, u, c)
}

function Bb(a, i, u) {
    let r = As(),
        c = $t(a, u.i, r.p),
        f = Ut(a, i, u.f);
    return u.s ? r.s(f) : r.f(f), c
}

function jb(a, i, u) {
    return $t(a, u.i, Object(Ut(a, i, u.f)))
}

function Hb(a, i, u) {
    let r = a.base.plugins;
    if (r) {
        let c = ua(u.c);
        for (let f = 0, h = r.length; f < h; f++) {
            let y = r[f];
            if (y.tag === c) return $t(a, u.i, y.deserialize(u.s, new gb(a, i), {
                id: u.i
            }))
        }
    }
    throw new v1(u.c)
}

function qb(a, i) {
    return $t(a, i.i, $t(a, i.s, As()).p)
}

function Yb(a, i, u) {
    let r = a.base.refs.get(u.i);
    if (r) return r.s(Ut(a, i, u.a[1])), b;
    throw new Xi("Promise")
}

function Gb(a, i, u) {
    let r = a.base.refs.get(u.i);
    if (r) return r.f(Ut(a, i, u.a[1])), b;
    throw new Xi("Promise")
}

function Xb(a, i, u) {
    Ut(a, i, u.a[0]);
    let r = Ut(a, i, u.a[1]);
    return w1(r)
}

function Vb(a, i, u) {
    Ut(a, i, u.a[0]);
    let r = Ut(a, i, u.a[1]);
    return j1(r)
}

function Qb(a, i, u) {
    let r = $t(a, u.i, Na()),
        c = u.a,
        f = c.length;
    if (f)
        for (let h = 0; h < f; h++) Ut(a, i, c[h]);
    return r
}

function Zb(a, i, u) {
    let r = a.base.refs.get(u.i);
    if (r && xs(r)) return r.next(Ut(a, i, u.f)), b;
    throw new Xi("Stream")
}

function Kb(a, i, u) {
    let r = a.base.refs.get(u.i);
    if (r && xs(r)) return r.throw(Ut(a, i, u.f)), b;
    throw new Xi("Stream")
}

function Jb(a, i, u) {
    let r = a.base.refs.get(u.i);
    if (r && xs(r)) return r.return(Ut(a, i, u.f)), b;
    throw new Xi("Stream")
}

function kb(a, i, u) {
    return Ut(a, i, u.f), b
}

function Pb(a, i, u) {
    return Ut(a, i, u.a[1]), b
}

function Fb(a, i, u) {
    let r = $t(a, u.i, sp([], u.s, u.l));
    for (let c = 0, f = u.a.length; c < f; c++) r.v[c] = Ut(a, i, u.a[c]);
    return r
}

function Ut(a, i, u) {
    if (i > a.base.depthLimit) throw new _1(a.base.depthLimit);
    switch (i += 1, u.t) {
        case 2:
            return mc(u, zS, u.s);
        case 0:
            return Number(u.s);
        case 1:
            return ua(String(u.s));
        case 3:
            if (String(u.s).length > hb) throw new sa(u);
            return BigInt(u.s);
        case 4:
            return a.base.refs.get(u.i);
        case 18:
            return _b(a, u);
        case 9:
            return Eb(a, i, u);
        case 10:
        case 11:
            return xb(a, i, u);
        case 5:
            return Mb(a, u);
        case 6:
            return Ob(a, u);
        case 7:
            return zb(a, i, u);
        case 8:
            return Cb(a, i, u);
        case 19:
            return wb(a, u);
        case 16:
        case 15:
            return Db(a, i, u);
        case 20:
            return Lb(a, i, u);
        case 14:
            return Ub(a, i, u);
        case 13:
            return Nb(a, i, u);
        case 12:
            return Bb(a, i, u);
        case 17:
            return mc(u, OS, u.s);
        case 21:
            return jb(a, i, u);
        case 25:
            return Hb(a, i, u);
        case 22:
            return qb(a, u);
        case 23:
            return Yb(a, i, u);
        case 24:
            return Gb(a, i, u);
        case 28:
            return Xb(a, i, u);
        case 30:
            return Vb(a, i, u);
        case 31:
            return Qb(a, i, u);
        case 32:
            return Zb(a, i, u);
        case 33:
            return Kb(a, i, u);
        case 34:
            return Jb(a, i, u);
        case 27:
            return kb(a, i, u);
        case 29:
            return Pb(a, i, u);
        case 35:
            return Fb(a, i, u);
        default:
            throw new ip(u)
    }
}

function Ib(a, i) {
    try {
        return Ut(a, 0, i)
    } catch (u) {
        throw new p1(u)
    }
}
var Wb = () => T;
Wb.toString();

function uy(a, i) {
    let u = cp(i.plugins),
        r = vb({
            plugins: u,
            refs: i.refs,
            features: i.features,
            disabledFeatures: i.disabledFeatures,
            depthLimit: i.depthLimit
        });
    return Ib(r, a)
}
async function $b(a, i = {}) {
    let u = cp(i.plugins),
        r = K1(1, {
            plugins: u,
            disabledFeatures: i.disabledFeatures
        });
    return {
        t: await ob(r, a),
        f: r.base.features,
        m: Array.from(r.base.marked)
    }
}

function t_(a) {
    return {
        tag: "$TSR/t/" + a.key,
        test: a.test,
        parse: {
            sync(i, u, r) {
                return {
                    v: u.parse(a.toSerializable(i))
                }
            },
            async async (i, u, r) {
                return {
                    v: await u.parse(a.toSerializable(i))
                }
            },
            stream(i, u, r) {
                return {
                    v: u.parse(a.toSerializable(i))
                }
            }
        },
        serialize: void 0,
        deserialize(i, u, r) {
            return a.fromSerializable(u.deserialize(i.v))
        }
    }
}
var e_ = class {
        constructor(a, i) {
            this.stream = a, this.hint = i ? .hint ? ? "binary"
        }
    },
    Ss = globalThis.Buffer,
    yp = !!Ss && typeof Ss.from == "function";

function pp(a) {
    if (a.length === 0) return "";
    if (yp) return Ss.from(a).toString("base64");
    const i = 32768,
        u = [];
    for (let r = 0; r < a.length; r += i) {
        const c = a.subarray(r, r + i);
        u.push(String.fromCharCode.apply(null, c))
    }
    return btoa(u.join(""))
}

function vp(a) {
    if (a.length === 0) return new Uint8Array(0);
    if (yp) {
        const r = Ss.from(a, "base64");
        return new Uint8Array(r.buffer, r.byteOffset, r.byteLength)
    }
    const i = atob(a),
        u = new Uint8Array(i.length);
    for (let r = 0; r < i.length; r++) u[r] = i.charCodeAt(r);
    return u
}
var wi = Object.create(null),
    Di = Object.create(null),
    n_ = a => new ReadableStream({
        start(i) {
            a.on({
                next(u) {
                    try {
                        i.enqueue(vp(u))
                    } catch {}
                },
                throw (u) {
                    i.error(u)
                },
                return () {
                    try {
                        i.close()
                    } catch {}
                }
            })
        }
    }),
    a_ = new TextEncoder,
    l_ = a => new ReadableStream({
        start(i) {
            a.on({
                next(u) {
                    try {
                        typeof u == "string" ? i.enqueue(a_.encode(u)) : i.enqueue(vp(u.$b64))
                    } catch {}
                },
                throw (u) {
                    i.error(u)
                },
                return () {
                    try {
                        i.close()
                    } catch {}
                }
            })
        }
    }),
    i_ = "(s=>new ReadableStream({start(c){s.on({next(b){try{const d=atob(b),a=new Uint8Array(d.length);for(let i=0;i<d.length;i++)a[i]=d.charCodeAt(i);c.enqueue(a)}catch(_){}},throw(e){c.error(e)},return(){try{c.close()}catch(_){}}})}}))",
    u_ = "(s=>{const e=new TextEncoder();return new ReadableStream({start(c){s.on({next(v){try{if(typeof v==='string'){c.enqueue(e.encode(v))}else{const d=atob(v.$b64),a=new Uint8Array(d.length);for(let i=0;i<d.length;i++)a[i]=d.charCodeAt(i);c.enqueue(a)}}catch(_){}},throw(x){c.error(x)},return(){try{c.close()}catch(_){}}})}})})";

function sy(a) {
    const i = Na(),
        u = a.getReader();
    return (async () => {
        try {
            for (;;) {
                const {
                    done: r,
                    value: c
                } = await u.read();
                if (r) {
                    i.return(void 0);
                    break
                }
                i.next(pp(c))
            }
        } catch (r) {
            i.throw(r)
        } finally {
            u.releaseLock()
        }
    })(), i
}

function ry(a) {
    const i = Na(),
        u = a.getReader(),
        r = new TextDecoder("utf-8", {
            fatal: !0
        });
    return (async () => {
        try {
            for (;;) {
                const {
                    done: c,
                    value: f
                } = await u.read();
                if (c) {
                    try {
                        const h = r.decode();
                        h.length > 0 && i.next(h)
                    } catch {}
                    i.return(void 0);
                    break
                }
                try {
                    const h = r.decode(f, {
                        stream: !0
                    });
                    h.length > 0 && i.next(h)
                } catch {
                    i.next({
                        $b64: pp(f)
                    })
                }
            }
        } catch (c) {
            i.throw(c)
        } finally {
            u.releaseLock()
        }
    })(), i
}
var s_ = {
    tag: "tss/RawStream",
    extends: [{
        tag: "tss/RawStreamFactory",
        test(a) {
            return a === wi
        },
        parse: {
            sync(a, i, u) {
                return {}
            },
            async async (a, i, u) {
                return {}
            },
            stream(a, i, u) {
                return {}
            }
        },
        serialize(a, i, u) {
            return i_
        },
        deserialize(a, i, u) {
            return wi
        }
    }, {
        tag: "tss/RawStreamFactoryText",
        test(a) {
            return a === Di
        },
        parse: {
            sync(a, i, u) {
                return {}
            },
            async async (a, i, u) {
                return {}
            },
            stream(a, i, u) {
                return {}
            }
        },
        serialize(a, i, u) {
            return u_
        },
        deserialize(a, i, u) {
            return Di
        }
    }],
    test(a) {
        return a instanceof e_
    },
    parse: {
        sync(a, i, u) {
            const r = a.hint === "text" ? Di : wi;
            return {
                hint: i.parse(a.hint),
                factory: i.parse(r),
                stream: i.parse(Na())
            }
        },
        async async (a, i, u) {
            const r = a.hint === "text" ? Di : wi,
                c = a.hint === "text" ? ry(a.stream) : sy(a.stream);
            return {
                hint: await i.parse(a.hint),
                factory: await i.parse(r),
                stream: await i.parse(c)
            }
        },
        stream(a, i, u) {
            const r = a.hint === "text" ? Di : wi,
                c = a.hint === "text" ? ry(a.stream) : sy(a.stream);
            return {
                hint: i.parse(a.hint),
                factory: i.parse(r),
                stream: i.parse(c)
            }
        }
    },
    serialize(a, i, u) {
        return "(" + i.serialize(a.factory) + ")(" + i.serialize(a.stream) + ")"
    },
    deserialize(a, i, u) {
        const r = i.deserialize(a.stream);
        return i.deserialize(a.hint) === "text" ? l_(r) : n_(r)
    }
};

function r_(a) {
    return {
        tag: "tss/RawStream",
        test: () => !1,
        parse: {},
        serialize() {
            throw new Error("RawStreamDeserializePlugin.serialize should not be called. Client only deserializes.")
        },
        deserialize(i, u, r) {
            return a(typeof u ? .deserialize == "function" ? u.deserialize(i.streamId) : i.streamId)
        }
    }
}
var o_ = {
        tag: "$TSR/Error",
        test(a) {
            return a instanceof Error
        },
        parse: {
            sync(a, i) {
                return {
                    message: i.parse(a.message)
                }
            },
            async async (a, i) {
                return {
                    message: await i.parse(a.message)
                }
            },
            stream(a, i) {
                return {
                    message: i.parse(a.message)
                }
            }
        },
        serialize(a, i) {
            return "new Error(" + i.serialize(a.message) + ")"
        },
        deserialize(a, i) {
            return new Error(i.deserialize(a.message))
        }
    },
    $n = {},
    gp = a => new ReadableStream({
        start: i => {
            a.on({
                next: u => {
                    try {
                        i.enqueue(u)
                    } catch {}
                },
                throw: u => {
                    i.error(u)
                },
                return: () => {
                    try {
                        i.close()
                    } catch {}
                }
            })
        }
    }),
    c_ = {
        tag: "seroval-plugins/web/ReadableStreamFactory",
        test(a) {
            return a === $n
        },
        parse: {
            sync() {
                return $n
            },
            async async () {
                return await Promise.resolve($n)
            },
            stream() {
                return $n
            }
        },
        serialize() {
            return gp.toString()
        },
        deserialize() {
            return $n
        }
    };

function oy(a) {
    let i = Na(),
        u = a.getReader();
    async function r() {
        try {
            let c = await u.read();
            c.done ? i.return(c.value) : (i.next(c.value), await r())
        } catch (c) {
            i.throw(c)
        }
    }
    return r().catch(() => {}), i
}
var f_ = {
        tag: "seroval/plugins/web/ReadableStream",
        extends: [c_],
        test(a) {
            return typeof ReadableStream > "u" ? !1 : a instanceof ReadableStream
        },
        parse: {
            sync(a, i) {
                return {
                    factory: i.parse($n),
                    stream: i.parse(Na())
                }
            },
            async async (a, i) {
                return {
                    factory: await i.parse($n),
                    stream: await i.parse(oy(a))
                }
            },
            stream(a, i) {
                return {
                    factory: i.parse($n),
                    stream: i.parse(oy(a))
                }
            }
        },
        serialize(a, i) {
            return "(" + i.serialize(a.factory) + ")(" + i.serialize(a.stream) + ")"
        },
        deserialize(a, i) {
            let u = i.deserialize(a.stream);
            return gp(u)
        }
    },
    d_ = f_,
    h_ = [o_, s_, d_];

function m_() {
    return [...My() ? .serializationAdapters ? .map(t_) ? ? [], ...h_]
}
var cy = new TextDecoder,
    y_ = new Uint8Array(0),
    fy = 16 * 1024 * 1024,
    dy = 32 * 1024 * 1024,
    hy = 1024,
    my = 1e5;

function p_(a) {
    const i = new Map,
        u = new Map,
        r = new Set;
    let c = !1,
        f = null,
        h = 0,
        y;
    const p = new ReadableStream({
        start(g) {
            y = g
        },
        cancel() {
            c = !0;
            try {
                f ? .cancel()
            } catch {}
            i.forEach(g => {
                try {
                    g.error(new Error("Framed response cancelled"))
                } catch {}
            }), i.clear(), u.clear(), r.clear()
        }
    });

    function m(g) {
        const _ = u.get(g);
        if (_) return _;
        if (r.has(g)) return new ReadableStream({
            start(O) {
                O.close()
            }
        });
        if (u.size >= hy) throw new Error(`Too many raw streams in framed response (max ${hy})`);
        const E = new ReadableStream({
            start(O) {
                i.set(g, O)
            },
            cancel() {
                r.add(g), i.delete(g), u.delete(g)
            }
        });
        return u.set(g, E), E
    }

    function S(g) {
        return m(g), i.get(g)
    }
    return (async () => {
        const g = a.getReader();
        f = g;
        const _ = [];
        let E = 0;

        function O() {
            if (E < 9) return null;
            const A = _[0];
            if (A.length >= 9) return {
                type: A[0],
                streamId: (A[1] << 24 | A[2] << 16 | A[3] << 8 | A[4]) >>> 0,
                length: (A[5] << 24 | A[6] << 16 | A[7] << 8 | A[8]) >>> 0
            };
            const z = new Uint8Array(9);
            let X = 0,
                Q = 9;
            for (let H = 0; H < _.length && Q > 0; H++) {
                const W = _[H],
                    F = Math.min(W.length, Q);
                z.set(W.subarray(0, F), X), X += F, Q -= F
            }
            return {
                type: z[0],
                streamId: (z[1] << 24 | z[2] << 16 | z[3] << 8 | z[4]) >>> 0,
                length: (z[5] << 24 | z[6] << 16 | z[7] << 8 | z[8]) >>> 0
            }
        }

        function w(A) {
            if (A === 0) return y_;
            const z = new Uint8Array(A);
            let X = 0,
                Q = A;
            for (; Q > 0 && _.length > 0;) {
                const H = _[0];
                if (!H) break;
                const W = Math.min(H.length, Q);
                z.set(H.subarray(0, W), X), X += W, Q -= W, W === H.length ? _.shift() : _[0] = H.subarray(W)
            }
            return E -= A, z
        }
        try {
            for (;;) {
                const {
                    done: A,
                    value: z
                } = await g.read();
                if (c || A) break;
                if (z) {
                    if (E + z.length > dy) throw new Error(`Framed response buffer exceeded ${dy} bytes`);
                    for (_.push(z), E += z.length;;) {
                        const X = O();
                        if (!X) break;
                        const {
                            type: Q,
                            streamId: H,
                            length: W
                        } = X;
                        if (Q !== En.JSON && Q !== En.CHUNK && Q !== En.END && Q !== En.ERROR) throw new Error(`Unknown frame type: ${Q}`);
                        if (Q === En.JSON) {
                            if (H !== 0) throw new Error("Invalid JSON frame streamId (expected 0)")
                        } else if (H === 0) throw new Error("Invalid raw frame streamId (expected non-zero)");
                        if (W > fy) throw new Error(`Frame payload too large: ${W} bytes (max ${fy})`);
                        const F = 9 + W;
                        if (E < F) break;
                        if (++h > my) throw new Error(`Too many frames in framed response (max ${my})`);
                        w(9);
                        const V = w(W);
                        switch (Q) {
                            case En.JSON:
                                try {
                                    y.enqueue(cy.decode(V))
                                } catch {}
                                break;
                            case En.CHUNK:
                                {
                                    const J = S(H);J && J.enqueue(V);
                                    break
                                }
                            case En.END:
                                {
                                    const J = S(H);
                                    if (r.add(H), J) {
                                        try {
                                            J.close()
                                        } catch {}
                                        i.delete(H)
                                    }
                                    break
                                }
                            case En.ERROR:
                                {
                                    const J = S(H);
                                    if (r.add(H), J) {
                                        const P = cy.decode(V);
                                        J.error(new Error(P)), i.delete(H)
                                    }
                                    break
                                }
                        }
                    }
                }
            }
            if (E !== 0) throw new Error("Incomplete frame at end of framed response");
            try {
                y.close()
            } catch {}
            i.forEach(A => {
                try {
                    A.close()
                } catch {}
            }), i.clear()
        } catch (A) {
            try {
                y.error(A)
            } catch {}
            i.forEach(z => {
                try {
                    z.error(A)
                } catch {}
            }), i.clear()
        } finally {
            try {
                g.releaseLock()
            } catch {}
            f = null
        }
    })(), {
        getOrCreateStream: m,
        jsonChunks: p
    }
}
var Yi = null;
async function yc(a) {
    a.length > 0 && await Promise.allSettled(a)
}
var v_ = Object.prototype.hasOwnProperty;

function Sp(a) {
    for (const i in a)
        if (v_.call(a, i)) return !0;
    return !1
}
async function g_(a, i, u) {
    Yi || (Yi = m_());
    const r = i[0],
        c = r.fetch ? ? u,
        f = r.data instanceof FormData ? "formData" : "payload",
        h = r.headers ? new Headers(r.headers) : new Headers;
    if (h.set("x-tsr-serverFn", "true"), f === "payload" && h.set("accept", `${p0}, application/x-ndjson, application/json`), r.method === "GET") {
        if (f === "formData") throw new Error("FormData is not supported with GET requests");
        const p = await bp(r);
        if (p !== void 0) {
            const m = Ly({
                payload: p
            });
            a.includes("?") ? a += `&${m}` : a += `?${m}`
        }
    }
    let y;
    if (r.method === "POST") {
        const p = await S_(r);
        p ? .contentType && h.set("content-type", p.contentType), y = p ? .body
    }
    return await b_(async () => c(a, {
        method: r.method,
        headers: h,
        signal: r.signal,
        body: y
    }))
}
async function bp(a) {
    let i = !1;
    const u = {};
    if (a.data !== void 0 && (i = !0, u.data = a.data), a.context && Sp(a.context) && (i = !0, u.context = a.context), i) return _p(u)
}
async function _p(a) {
    return JSON.stringify(await Promise.resolve($b(a, {
        plugins: Yi
    })))
}
async function S_(a) {
    if (a.data instanceof FormData) {
        let u;
        return a.context && Sp(a.context) && (u = await _p(a.context)), u !== void 0 && a.data.set(y0, u), {
            body: a.data
        }
    }
    const i = await bp(a);
    if (i) return {
        body: i,
        contentType: "application/json"
    }
}
async function b_(a) {
    let i;
    try {
        i = await a()
    } catch (r) {
        if (r instanceof Response) i = r;
        else throw console.log(r), r
    }
    if (i.headers.get("x-tss-raw") === "true") return i;
    const u = i.headers.get("content-type");
    if (u || Ee(), i.headers.get("x-tss-serialized")) {
        let r;
        if (u.includes("application/x-tss-framed")) {
            if (S0(u), !i.body) throw new Error("No response body for framed response");
            const {
                getOrCreateStream: c,
                jsonChunks: f
            } = p_(i.body), h = [r_(c), ...Yi || []], y = new Map;
            r = await __({
                jsonStream: f,
                onMessage: p => uy(p, {
                    refs: y,
                    plugins: h
                }),
                onError(p, m) {
                    console.error(p, m)
                }
            })
        } else if (u.includes("application/json")) {
            const c = await i.json(),
                f = [];
            r = uy(c, {
                plugins: Yi
            }), await yc(f)
        }
        if (r || Ee(), r instanceof Error) throw r;
        return r
    }
    if (u.includes("application/json")) {
        const r = await i.json(),
            c = eS(r);
        if (c) throw c;
        if (ne(r)) throw r;
        return r
    }
    if (!i.ok) throw new Error(await i.text());
    return i
}
async function __({
    jsonStream: a,
    onMessage: i,
    onError: u
}) {
    const r = a.getReader(),
        {
            value: c,
            done: f
        } = await r.read();
    if (f || !c) throw new Error("Stream ended before first object");
    const h = JSON.parse(c);
    let y = !1;
    const p = (async () => {
        try {
            for (;;) {
                const {
                    value: g,
                    done: _
                } = await r.read();
                if (_) break;
                if (g) try {
                    const E = [];
                    try {
                        i(JSON.parse(g))
                    } finally {}
                    await yc(E)
                } catch (E) {
                    u ? .(`Invalid JSON: ${g}`, E)
                }
            }
        } catch (g) {
            y || u ? .("Stream processing error:", g)
        }
    })();
    let m;
    const S = [];
    try {
        m = i(h)
    } catch (g) {
        throw y = !0, r.cancel().catch(() => {}), g
    }
    return await yc(S), Promise.resolve(m).catch(() => {
        y = !0, r.cancel().catch(() => {})
    }), p.finally(() => {
        try {
            r.releaseLock()
        } catch {}
    }), m
}

function E_(a) {
    const i = "/_serverFn/" + a;
    return Object.assign((...c) => {
        const f = My() ? .serverFns ? .fetch;
        return g_(i, c, f ? ? fetch)
    }, {
        url: i,
        serverFnMeta: {
            id: a
        },
        [fc]: !0
    })
}
var R_ = {
    key: "$TSS/serverfn",
    test: a => typeof a != "function" || !(fc in a) ? !1 : !!a[fc],
    toSerializable: ({
        serverFnMeta: a
    }) => ({
        functionId: a.id
    }),
    fromSerializable: ({
        functionId: a
    }) => E_(a)
};

function yy(a) {
    return a.replaceAll("\0", "/").replaceAll("�", "/")
}

function T_(a, i) {
    a.id = i.i, a.__beforeLoadContext = i.b, a.loaderData = i.l, a.status = i.s, a.ssr = i.ssr, a.updatedAt = i.u, a.error = i.e, i.g !== void 0 && (a.globalNotFound = i.g)
}
async function A_(a) {
    window.$_TSR || Ee();
    const i = a.options.serializationAdapters;
    if (i ? .length) {
        const A = new Map;
        i.forEach(z => {
            A.set(z.key, z.fromSerializable)
        }), window.$_TSR.t = A, window.$_TSR.buffer.forEach(z => z())
    }
    window.$_TSR.initialized = !0, window.$_TSR.router || Ee();
    const u = window.$_TSR.router;
    u.matches.forEach(A => {
        A.i = yy(A.i)
    }), u.lastMatchId && (u.lastMatchId = yy(u.lastMatchId));
    const {
        manifest: r,
        dehydratedData: c,
        lastMatchId: f
    } = u;
    a.ssr = {
        manifest: r
    };
    const h = document.querySelector('meta[property="csp-nonce"]') ? .content;
    a.options.ssr = {
        nonce: h
    };
    const y = a.matchRoutes(a.stores.location.get()),
        p = Promise.all(y.map(A => a.loadRouteChunk(a.looseRoutesById[A.routeId])));

    function m(A) {
        const z = a.looseRoutesById[A.routeId].options.pendingMinMs ? ? a.options.defaultPendingMinMs;
        if (z) {
            const X = Ua();
            A._nonReactive.minPendingPromise = X, A._forcePending = !0, setTimeout(() => {
                X.resolve(), a.updateMatch(A.id, Q => (Q._nonReactive.minPendingPromise = void 0, { ...Q,
                    _forcePending: void 0
                }))
            }, z)
        }
    }

    function S(A) {
        const z = a.looseRoutesById[A.routeId];
        z && (z.options.ssr = A.ssr)
    }
    let g;
    y.forEach(A => {
        const z = u.matches.find(X => X.i === A.id);
        if (!z) {
            A._nonReactive.dehydrated = !1, A.ssr = !1, S(A);
            return
        }
        T_(A, z), S(A), A._nonReactive.dehydrated = A.ssr !== !1, (A.ssr === "data-only" || A.ssr === !1) && g === void 0 && (g = A.index, m(A))
    }), a.stores.setMatches(y), await a.options.hydrate ? .(c);
    const _ = a.stores.matches.get(),
        E = a.stores.location.get();
    await Promise.all(_.map(async A => {
        try {
            const z = a.looseRoutesById[A.routeId],
                X = _[A.index - 1] ? .context ? ? a.options.context;
            if (z.options.context) {
                const F = {
                    deps: A.loaderDeps,
                    params: A.params,
                    context: X ? ? {},
                    location: E,
                    navigate: V => a.navigate({ ...V,
                        _fromLocation: E
                    }),
                    buildLocation: a.buildLocation,
                    cause: A.cause,
                    abortController: A.abortController,
                    preload: !1,
                    matches: y,
                    routeId: z.id
                };
                A.__routeContext = z.options.context(F) ? ? void 0
            }
            A.context = { ...X,
                ...A.__routeContext,
                ...A.__beforeLoadContext
            };
            const Q = {
                    ssr: a.options.ssr,
                    matches: _,
                    match: A,
                    params: A.params,
                    loaderData: A.loaderData
                },
                H = await z.options.head ? .(Q),
                W = await z.options.scripts ? .(Q);
            A.meta = H ? .meta, A.links = H ? .links, A.headScripts = H ? .scripts, A.styles = H ? .styles, A.scripts = W
        } catch (z) {
            if (ne(z)) A.error = {
                isNotFound: !0
            }, console.error(`NotFound error during hydration for routeId: ${A.routeId}`, z);
            else throw A.error = z, console.error(`Error during hydration for route ${A.routeId}:`, z), z
        }
    }));
    const O = y[y.length - 1].id !== f;
    if (!y.some(A => A.ssr === !1) && !O) return y.forEach(A => {
        A._nonReactive.dehydrated = void 0
    }), a.stores.resolvedLocation.set(a.stores.location.get()), p;
    const w = Promise.resolve().then(() => a.load()).catch(A => {
        console.error("Error during router hydration:", A)
    });
    if (O) {
        const A = y[1];
        A || Ee(), m(A), A._displayPending = !0, A._nonReactive.displayPendingPromise = w, w.then(() => {
            a.batch(() => {
                a.stores.status.get() === "pending" && (a.stores.status.set("idle"), a.stores.resolvedLocation.set(a.stores.location.get())), a.updateMatch(A.id, z => ({ ...z,
                    _displayPending: void 0,
                    displayPendingPromise: void 0
                }))
            })
        })
    }
    return p
}
var bs = et.use,
    Ui = typeof window < "u" ? et.useLayoutEffect : et.useEffect;

function lc(a) {
    const i = et.useRef({
            value: a,
            prev: null
        }),
        u = i.current.value;
    return a !== u && (i.current = {
        value: a,
        prev: u
    }), i.current.prev
}

function x_(a, i, u = {}, r = {}) {
    et.useEffect(() => {
        if (!a.current || r.disabled || typeof IntersectionObserver != "function") return;
        const c = new IntersectionObserver(([f]) => {
            i(f)
        }, u);
        return c.observe(a.current), () => {
            c.disconnect()
        }
    }, [i, u, r.disabled, a])
}

function M_(a) {
    const i = et.useRef(null);
    return et.useImperativeHandle(a, () => i.current, []), i
}

function O_({
    promise: a
}) {
    if (bs) return bs(a);
    const i = ES(a);
    if (i[$e].status === "pending") throw i;
    if (i[$e].status === "error") throw i[$e].error;
    return i[$e].data
}

function z_(a) {
    const i = Z.jsx(C_, { ...a
    });
    return a.fallback ? Z.jsx(et.Suspense, {
        fallback: a.fallback,
        children: i
    }) : i
}

function C_(a) {
    const i = O_(a);
    return a.children(i)
}

function xc(a) {
    const i = a.errorComponent ? ? Mc;
    return Z.jsx(w_, {
        getResetKey: a.getResetKey,
        onCatch: a.onCatch,
        children: ({
            error: u,
            reset: r
        }) => u ? et.createElement(i, {
            error: u,
            reset: r
        }) : a.children
    })
}
var w_ = class extends et.Component {
    constructor(...a) {
        super(...a), this.state = {
            error: null
        }
    }
    static getDerivedStateFromProps(a, i) {
        const u = a.getResetKey();
        return i.error && i.resetKey !== u ? {
            resetKey: u,
            error: null
        } : {
            resetKey: u
        }
    }
    static getDerivedStateFromError(a) {
        return {
            error: a
        }
    }
    reset() {
        this.setState({
            error: null
        })
    }
    componentDidCatch(a, i) {
        this.props.onCatch && this.props.onCatch(a, i)
    }
    render() {
        return this.props.children({
            error: this.state.error,
            reset: () => {
                this.reset()
            }
        })
    }
};

function Mc({
    error: a
}) {
    const [i, u] = et.useState(!1);
    return Z.jsxs("div", {
        style: {
            padding: ".5rem",
            maxWidth: "100%"
        },
        children: [Z.jsxs("div", {
            style: {
                display: "flex",
                alignItems: "center",
                gap: ".5rem"
            },
            children: [Z.jsx("strong", {
                style: {
                    fontSize: "1rem"
                },
                children: "Something went wrong!"
            }), Z.jsx("button", {
                style: {
                    appearance: "none",
                    fontSize: ".6em",
                    border: "1px solid currentColor",
                    padding: ".1rem .2rem",
                    fontWeight: "bold",
                    borderRadius: ".25rem"
                },
                onClick: () => u(r => !r),
                children: i ? "Hide Error" : "Show Error"
            })]
        }), Z.jsx("div", {
            style: {
                height: ".25rem"
            }
        }), i ? Z.jsx("div", {
            children: Z.jsx("pre", {
                style: {
                    fontSize: ".7em",
                    border: "1px solid red",
                    borderRadius: ".25rem",
                    padding: ".3rem",
                    color: "red",
                    overflow: "auto"
                },
                children: a.message ? Z.jsx("code", {
                    children: a.message
                }) : null
            })
        }) : null]
    })
}

function D_({
    children: a,
    fallback: i = null
}) {
    return Oc() ? Z.jsx(Ni.Fragment, {
        children: a
    }) : Z.jsx(Ni.Fragment, {
        children: i
    })
}

function Oc() {
    return Ni.useSyncExternalStore(L_, () => !0, () => !1)
}

function L_() {
    return () => {}
}
var Ep = et.createContext(null);

function fe(a) {
    return et.useContext(Ep)
}
var zs = et.createContext(void 0),
    U_ = et.createContext(void 0),
    qt = (a => (a[a.None = 0] = "None", a[a.Mutable = 1] = "Mutable", a[a.Watching = 2] = "Watching", a[a.RecursedCheck = 4] = "RecursedCheck", a[a.Recursed = 8] = "Recursed", a[a.Dirty = 16] = "Dirty", a[a.Pending = 32] = "Pending", a))(qt || {});

function N_({
    update: a,
    notify: i,
    unwatched: u
}) {
    return {
        link: r,
        unlink: c,
        propagate: f,
        checkDirty: h,
        shallowPropagate: y
    };

    function r(m, S, g) {
        const _ = S.depsTail;
        if (_ !== void 0 && _.dep === m) return;
        const E = _ !== void 0 ? _.nextDep : S.deps;
        if (E !== void 0 && E.dep === m) {
            E.version = g, S.depsTail = E;
            return
        }
        const O = m.subsTail;
        if (O !== void 0 && O.version === g && O.sub === S) return;
        const w = S.depsTail = m.subsTail = {
            version: g,
            dep: m,
            sub: S,
            prevDep: _,
            nextDep: E,
            prevSub: O,
            nextSub: void 0
        };
        E !== void 0 && (E.prevDep = w), _ !== void 0 ? _.nextDep = w : S.deps = w, O !== void 0 ? O.nextSub = w : m.subs = w
    }

    function c(m, S = m.sub) {
        const g = m.dep,
            _ = m.prevDep,
            E = m.nextDep,
            O = m.nextSub,
            w = m.prevSub;
        return E !== void 0 ? E.prevDep = _ : S.depsTail = _, _ !== void 0 ? _.nextDep = E : S.deps = E, O !== void 0 ? O.prevSub = w : g.subsTail = w, w !== void 0 ? w.nextSub = O : (g.subs = O) === void 0 && u(g), E
    }

    function f(m) {
        let S = m.nextSub,
            g;
        t: do {
            const _ = m.sub;
            let E = _.flags;
            if (E & 60 ? E & 12 ? E & 4 ? !(E & 48) && p(m, _) ? (_.flags = E | 40, E &= 1) : E = 0 : _.flags = E & -9 | 32 : E = 0 : _.flags = E | 32, E & 2 && i(_), E & 1) {
                const O = _.subs;
                if (O !== void 0) {
                    const w = (m = O).nextSub;
                    w !== void 0 && (g = {
                        value: S,
                        prev: g
                    }, S = w);
                    continue
                }
            }
            if ((m = S) !== void 0) {
                S = m.nextSub;
                continue
            }
            for (; g !== void 0;)
                if (m = g.value, g = g.prev, m !== void 0) {
                    S = m.nextSub;
                    continue t
                }
            break
        } while (!0)
    }

    function h(m, S) {
        let g, _ = 0,
            E = !1;
        t: do {
            const O = m.dep,
                w = O.flags;
            if (S.flags & 16) E = !0;
            else if ((w & 17) === 17) {
                if (a(O)) {
                    const A = O.subs;
                    A.nextSub !== void 0 && y(A), E = !0
                }
            } else if ((w & 33) === 33) {
                (m.nextSub !== void 0 || m.prevSub !== void 0) && (g = {
                    value: m,
                    prev: g
                }), m = O.deps, S = O, ++_;
                continue
            }
            if (!E) {
                const A = m.nextDep;
                if (A !== void 0) {
                    m = A;
                    continue
                }
            }
            for (; _--;) {
                const A = S.subs,
                    z = A.nextSub !== void 0;
                if (z ? (m = g.value, g = g.prev) : m = A, E) {
                    if (a(S)) {
                        z && y(A), S = m.sub;
                        continue
                    }
                    E = !1
                } else S.flags &= -33;
                S = m.sub;
                const X = m.nextDep;
                if (X !== void 0) {
                    m = X;
                    continue t
                }
            }
            return E
        } while (!0)
    }

    function y(m) {
        do {
            const S = m.sub,
                g = S.flags;
            (g & 48) === 32 && (S.flags = g | 16, (g & 6) === 2 && i(S))
        } while ((m = m.nextSub) !== void 0)
    }

    function p(m, S) {
        let g = S.depsTail;
        for (; g !== void 0;) {
            if (g === m) return !0;
            g = g.prevDep
        }
        return !1
    }
}

function B_(a, i, u) {
    const r = typeof a == "object",
        c = r ? a : void 0;
    return {
        next: (r ? a.next : a) ? .bind(c),
        error: (r ? a.error : i) ? .bind(c),
        complete: (r ? a.complete : u) ? .bind(c)
    }
}
const pc = [];
let ms = 0;
const {
    link: py,
    unlink: j_,
    propagate: H_,
    checkDirty: Rp,
    shallowPropagate: vy
} = N_({
    update(a) {
        return a._update()
    },
    notify(a) {
        pc[vc++] = a, a.flags &= ~qt.Watching
    },
    unwatched(a) {
        a.depsTail !== void 0 && (a.depsTail = void 0, a.flags = qt.Mutable | qt.Dirty, _s(a))
    }
});
let os = 0,
    vc = 0,
    We, gc = 0;

function Tp(a) {
    try {
        ++gc, a()
    } finally {
        --gc || Ap()
    }
}

function _s(a) {
    const i = a.depsTail;
    let u = i !== void 0 ? i.nextDep : a.deps;
    for (; u !== void 0;) u = j_(u, a)
}

function Ap() {
    if (!(gc > 0)) {
        for (; os < vc;) {
            const a = pc[os];
            pc[os++] = void 0, a.notify()
        }
        os = 0, vc = 0
    }
}

function gy(a, i) {
    const u = typeof a == "function",
        r = a,
        c = {
            _snapshot: u ? void 0 : a,
            subs: void 0,
            subsTail: void 0,
            deps: void 0,
            depsTail: void 0,
            flags: u ? qt.None : qt.Mutable,
            get() {
                return We !== void 0 && py(c, We, ms), c._snapshot
            },
            subscribe(f) {
                const h = B_(f),
                    y = {
                        current: !1
                    },
                    p = q_(() => {
                        c.get(), y.current ? h.next ? .(c._snapshot) : y.current = !0
                    });
                return {
                    unsubscribe: () => {
                        p.stop()
                    }
                }
            },
            _update(f) {
                const h = We,
                    y = i ? .compare ? ? Object.is;
                if (u) We = c, ++ms, c.depsTail = void 0;
                else if (f === void 0) return !1;
                u && (c.flags = qt.Mutable | qt.RecursedCheck);
                try {
                    const p = c._snapshot,
                        m = typeof f == "function" ? f(p) : f === void 0 && u ? r(p) : f;
                    return p === void 0 || !y(p, m) ? (c._snapshot = m, !0) : !1
                } finally {
                    We = h, u && (c.flags &= ~qt.RecursedCheck), _s(c)
                }
            }
        };
    return u ? (c.flags = qt.Mutable | qt.Dirty, c.get = function() {
        const f = c.flags;
        if (f & qt.Dirty || f & qt.Pending && Rp(c.deps, c)) {
            if (c._update()) {
                const h = c.subs;
                h !== void 0 && vy(h)
            }
        } else f & qt.Pending && (c.flags = f & ~qt.Pending);
        return We !== void 0 && py(c, We, ms), c._snapshot
    }) : c.set = function(f) {
        if (c._update(f)) {
            const h = c.subs;
            h !== void 0 && (H_(h), vy(h), Ap())
        }
    }, c
}

function q_(a) {
    const i = () => {
            const r = We;
            We = u, ++ms, u.depsTail = void 0, u.flags = qt.Watching | qt.RecursedCheck;
            try {
                return a()
            } finally {
                We = r, u.flags &= ~qt.RecursedCheck, _s(u)
            }
        },
        u = {
            deps: void 0,
            depsTail: void 0,
            subs: void 0,
            subsTail: void 0,
            flags: qt.Watching | qt.RecursedCheck,
            notify() {
                const r = this.flags;
                r & qt.Dirty || r & qt.Pending && Rp(this.deps, this) ? i() : this.flags = qt.Watching
            },
            stop() {
                this.flags = qt.None, this.depsTail = void 0, _s(this)
            }
        };
    return i(), u
}
var ic = {
        exports: {}
    },
    uc = {},
    sc = {
        exports: {}
    },
    rc = {};
var Sy;

function Y_() {
    if (Sy) return rc;
    Sy = 1;
    var a = Gi();

    function i(g, _) {
        return g === _ && (g !== 0 || 1 / g === 1 / _) || g !== g && _ !== _
    }
    var u = typeof Object.is == "function" ? Object.is : i,
        r = a.useState,
        c = a.useEffect,
        f = a.useLayoutEffect,
        h = a.useDebugValue;

    function y(g, _) {
        var E = _(),
            O = r({
                inst: {
                    value: E,
                    getSnapshot: _
                }
            }),
            w = O[0].inst,
            A = O[1];
        return f(function() {
            w.value = E, w.getSnapshot = _, p(w) && A({
                inst: w
            })
        }, [g, E, _]), c(function() {
            return p(w) && A({
                inst: w
            }), g(function() {
                p(w) && A({
                    inst: w
                })
            })
        }, [g]), h(E), E
    }

    function p(g) {
        var _ = g.getSnapshot;
        g = g.value;
        try {
            var E = _();
            return !u(g, E)
        } catch {
            return !0
        }
    }

    function m(g, _) {
        return _()
    }
    var S = typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u" ? m : y;
    return rc.useSyncExternalStore = a.useSyncExternalStore !== void 0 ? a.useSyncExternalStore : S, rc
}
var by;

function G_() {
    return by || (by = 1, sc.exports = Y_()), sc.exports
}
var _y;

function X_() {
    if (_y) return uc;
    _y = 1;
    var a = Gi(),
        i = G_();

    function u(m, S) {
        return m === S && (m !== 0 || 1 / m === 1 / S) || m !== m && S !== S
    }
    var r = typeof Object.is == "function" ? Object.is : u,
        c = i.useSyncExternalStore,
        f = a.useRef,
        h = a.useEffect,
        y = a.useMemo,
        p = a.useDebugValue;
    return uc.useSyncExternalStoreWithSelector = function(m, S, g, _, E) {
        var O = f(null);
        if (O.current === null) {
            var w = {
                hasValue: !1,
                value: null
            };
            O.current = w
        } else w = O.current;
        O = y(function() {
            function z(F) {
                if (!X) {
                    if (X = !0, Q = F, F = _(F), E !== void 0 && w.hasValue) {
                        var V = w.value;
                        if (E(V, F)) return H = V
                    }
                    return H = F
                }
                if (V = H, r(Q, F)) return V;
                var J = _(F);
                return E !== void 0 && E(V, J) ? (Q = F, V) : (Q = F, H = J)
            }
            var X = !1,
                Q, H, W = g === void 0 ? null : g;
            return [function() {
                return z(S())
            }, W === null ? void 0 : function() {
                return z(W())
            }]
        }, [S, g, _, E]);
        var A = c(m, O[0], O[1]);
        return h(function() {
            w.hasValue = !0, w.value = A
        }, [A]), p(A), A
    }, uc
}
var Ey;

function V_() {
    return Ey || (Ey = 1, ic.exports = X_()), ic.exports
}
var Q_ = V_();

function Z_(a, i) {
    return a === i
}

function Ft(a, i, u = Z_) {
    const r = et.useCallback(h => {
            if (!a) return () => {};
            const {
                unsubscribe: y
            } = a.subscribe(h);
            return y
        }, [a]),
        c = et.useCallback(() => a ? .get(), [a]);
    return Q_.useSyncExternalStoreWithSelector(r, c, c, i, u)
}
var K_ = {
    get: () => {},
    subscribe: () => ({
        unsubscribe: () => {}
    })
};

function Ba(a) {
    const i = fe(),
        u = et.useContext(a.from ? U_ : zs),
        r = a.from ? ? u,
        c = r ? a.from ? i.stores.getRouteMatchStore(r) : i.stores.matchStores.get(r) : void 0,
        f = et.useRef(void 0);
    return Ft(c ? ? K_, h => {
        if ((a.shouldThrow ? ? !0) && !h && Ee(), h === void 0) return;
        const y = a.select ? a.select(h) : h;
        if (a.structuralSharing ? ? i.options.defaultStructuralSharing) {
            const p = Oa(f.current, y);
            return f.current = p, p
        }
        return y
    })
}

function xp(a) {
    return Ba({
        from: a.from,
        strict: a.strict,
        structuralSharing: a.structuralSharing,
        select: i => a.select ? a.select(i.loaderData) : i.loaderData
    })
}

function Mp(a) {
    const {
        select: i,
        ...u
    } = a;
    return Ba({ ...u,
        select: r => i ? i(r.loaderDeps) : r.loaderDeps
    })
}

function Op(a) {
    return Ba({
        from: a.from,
        shouldThrow: a.shouldThrow,
        structuralSharing: a.structuralSharing,
        strict: a.strict,
        select: i => {
            const u = a.strict === !1 ? i.params : i._strictParams;
            return a.select ? a.select(u) : u
        }
    })
}

function zp(a) {
    return Ba({
        from: a.from,
        strict: a.strict,
        shouldThrow: a.shouldThrow,
        structuralSharing: a.structuralSharing,
        select: i => a.select ? a.select(i.search) : i.search
    })
}

function Cp(a) {
    const i = fe();
    return et.useCallback(u => i.navigate({ ...u,
        from: u.from ? ? a ? .from
    }), [a ? .from, i])
}

function wp(a) {
    return Ba({ ...a,
        select: i => a.select ? a.select(i.context) : i.context
    })
}
var J_ = xy();

function k_(a, i) {
    const u = fe(),
        r = M_(i),
        {
            activeProps: c,
            inactiveProps: f,
            activeOptions: h,
            to: y,
            preload: p,
            preloadDelay: m,
            preloadIntentProximity: S,
            hashScrollIntoView: g,
            replace: _,
            startTransition: E,
            resetScroll: O,
            viewTransition: w,
            children: A,
            target: z,
            disabled: X,
            style: Q,
            className: H,
            onClick: W,
            onBlur: F,
            onFocus: V,
            onMouseEnter: J,
            onMouseLeave: P,
            onTouchStart: ut,
            ignoreBlocker: tt,
            params: dt,
            search: vt,
            hash: Yt,
            state: Ot,
            mask: B,
            reloadDocument: K,
            unsafeRelative: it,
            from: Rt,
            _fromLocation: At,
            ...M
        } = a,
        Y = Oc(),
        k = et.useMemo(() => a, [u, a.from, a._fromLocation, a.hash, a.to, a.search, a.params, a.state, a.mask, a.unsafeRelative]),
        I = Ft(u.stores.location, Nt => Nt, (Nt, ae) => Nt.href === ae.href),
        at = et.useMemo(() => {
            const Nt = {
                _fromLocation: I,
                ...k
            };
            return u.buildLocation(Nt)
        }, [u, I, k]),
        ft = at.maskedLocation ? at.maskedLocation.publicHref : at.publicHref,
        St = at.maskedLocation ? at.maskedLocation.external : at.external,
        Vt = et.useMemo(() => t2(ft, St, u.history, X), [X, St, ft, u.history]),
        Dt = et.useMemo(() => {
            if (Vt ? .external) return ys(Vt.href, u.protocolAllowlist) ? void 0 : Vt.href;
            if (!e2(y) && !(typeof y != "string" || y.indexOf(":") === -1)) try {
                return new URL(y), ys(y, u.protocolAllowlist) ? void 0 : y
            } catch {}
        }, [y, Vt, u.protocolAllowlist]),
        tn = et.useMemo(() => {
            if (Dt) return !1;
            if (h ? .exact) {
                if (!G0(I.pathname, at.pathname, u.basepath)) return !1
            } else {
                const Nt = ps(I.pathname, u.basepath),
                    ae = ps(at.pathname, u.basepath);
                if (!(Nt.startsWith(ae) && (Nt.length === ae.length || Nt[ae.length] === "/"))) return !1
            }
            return (h ? .includeSearch ? ? !0) && !be(I.search, at.search, {
                partial: !h ? .exact,
                ignoreUndefined: !h ? .explicitUndefined
            }) ? !1 : h ? .includeHash ? Y && I.hash === at.hash : !0
        }, [h ? .exact, h ? .explicitUndefined, h ? .includeHash, h ? .includeSearch, I, Dt, Y, at.hash, at.pathname, at.search, u.basepath]),
        en = tn ? ta(c, {}) ? ? P_ : oc,
        xn = tn ? oc : ta(f, {}) ? ? oc,
        Cl = [H, en.className, xn.className].filter(Boolean).join(" "),
        Ke = (Q || en.style || xn.style) && { ...Q,
            ...en.style,
            ...xn.style
        },
        [wl, ja] = et.useState(!1),
        Vi = et.useRef(!1),
        nn = a.reloadDocument || Dt ? !1 : p ? ? u.options.defaultPreload,
        ra = m ? ? u.options.defaultPreloadDelay ? ? 0,
        Xe = et.useCallback(() => {
            u.preloadRoute({ ...k,
                _builtLocation: at
            }).catch(Nt => {
                console.warn(Nt), console.warn(RS)
            })
        }, [u, k, at]);
    x_(r, et.useCallback(Nt => {
        Nt ? .isIntersecting && Xe()
    }, [Xe]), $_, {
        disabled: !!X || nn !== "viewport"
    }), et.useEffect(() => {
        Vi.current || !X && nn === "render" && (Xe(), Vi.current = !0)
    }, [X, Xe, nn]);
    const Dl = Nt => {
        const ae = Nt.currentTarget.getAttribute("target"),
            Je = z !== void 0 ? z : ae;
        if (!X && !n2(Nt) && !Nt.defaultPrevented && (!Je || Je === "_self") && Nt.button === 0) {
            Nt.preventDefault(), J_.flushSync(() => {
                ja(!0)
            });
            const Ha = u.subscribe("onResolved", () => {
                Ha(), ja(!1)
            });
            u.navigate({ ...k,
                replace: _,
                resetScroll: O,
                hashScrollIntoView: g,
                startTransition: E,
                viewTransition: w,
                ignoreBlocker: tt
            })
        }
    };
    if (Dt) return { ...M,
        ref: r,
        href: Dt,
        ...A && {
            children: A
        },
        ...z && {
            target: z
        },
        ...X && {
            disabled: X
        },
        ...Q && {
            style: Q
        },
        ...H && {
            className: H
        },
        ...W && {
            onClick: W
        },
        ...F && {
            onBlur: F
        },
        ...V && {
            onFocus: V
        },
        ...J && {
            onMouseEnter: J
        },
        ...P && {
            onMouseLeave: P
        },
        ...ut && {
            onTouchStart: ut
        }
    };
    const Qi = Nt => {
            if (X || nn !== "intent") return;
            if (!ra) {
                Xe();
                return
            }
            const ae = Nt.currentTarget;
            if (Li.has(ae)) return;
            const Je = setTimeout(() => {
                Li.delete(ae), Xe()
            }, ra);
            Li.set(ae, Je)
        },
        Cs = Nt => {
            X || nn !== "intent" || Xe()
        },
        oe = Nt => {
            if (X || !nn || !ra) return;
            const ae = Nt.currentTarget,
                Je = Li.get(ae);
            Je && (clearTimeout(Je), Li.delete(ae))
        };
    return { ...M,
        ...en,
        ...xn,
        href: Vt ? .href,
        ref: r,
        onClick: Rl([W, Dl]),
        onBlur: Rl([F, oe]),
        onFocus: Rl([V, Qi]),
        onMouseEnter: Rl([J, Qi]),
        onMouseLeave: Rl([P, oe]),
        onTouchStart: Rl([ut, Cs]),
        disabled: !!X,
        target: z,
        ...Ke && {
            style: Ke
        },
        ...Cl && {
            className: Cl
        },
        ...X && F_,
        ...tn && I_,
        ...Y && wl && W_
    }
}
var oc = {},
    P_ = {
        className: "active"
    },
    F_ = {
        role: "link",
        "aria-disabled": !0
    },
    I_ = {
        "data-status": "active",
        "aria-current": "page"
    },
    W_ = {
        "data-transitioning": "transitioning"
    },
    Li = new WeakMap,
    $_ = {
        rootMargin: "100px"
    },
    Rl = a => i => {
        for (const u of a)
            if (u) {
                if (i.defaultPrevented) return;
                u(i)
            }
    };

function t2(a, i, u, r) {
    if (!r) return i ? {
        href: a,
        external: !0
    } : {
        href: u.createHref(a) || "/",
        external: !1
    }
}

function e2(a) {
    if (typeof a != "string") return !1;
    const i = a.charCodeAt(0);
    return i === 47 ? a.charCodeAt(1) !== 47 : i === 46
}
var Dp = et.forwardRef((a, i) => {
    const {
        _asChild: u,
        ...r
    } = a, {
        type: c,
        ...f
    } = k_(r, i), h = typeof r.children == "function" ? r.children({
        isActive: f["data-status"] === "active"
    }) : r.children;
    if (!u) {
        const {
            disabled: y,
            ...p
        } = f;
        return et.createElement("a", p, h)
    }
    return et.createElement(u, f, h)
});

function n2(a) {
    return !!(a.metaKey || a.altKey || a.ctrlKey || a.shiftKey)
}
var a2 = class extends Yy {
    constructor(i) {
        super(i), this.useMatch = u => Ba({
            select: u ? .select,
            from: this.id,
            structuralSharing: u ? .structuralSharing
        }), this.useRouteContext = u => wp({ ...u,
            from: this.id
        }), this.useSearch = u => zp({
            select: u ? .select,
            structuralSharing: u ? .structuralSharing,
            from: this.id
        }), this.useParams = u => Op({
            select: u ? .select,
            structuralSharing: u ? .structuralSharing,
            from: this.id
        }), this.useLoaderDeps = u => Mp({ ...u,
            from: this.id
        }), this.useLoaderData = u => xp({ ...u,
            from: this.id
        }), this.useNavigate = () => Cp({
            from: this.fullPath
        }), this.Link = Ni.forwardRef((u, r) => Z.jsx(Dp, {
            ref: r,
            from: this.fullPath,
            ...u
        }))
    }
};

function l2(a) {
    return new a2(a)
}
var i2 = class extends AS {
    constructor(a) {
        super(a), this.useMatch = i => Ba({
            select: i ? .select,
            from: this.id,
            structuralSharing: i ? .structuralSharing
        }), this.useRouteContext = i => wp({ ...i,
            from: this.id
        }), this.useSearch = i => zp({
            select: i ? .select,
            structuralSharing: i ? .structuralSharing,
            from: this.id
        }), this.useParams = i => Op({
            select: i ? .select,
            structuralSharing: i ? .structuralSharing,
            from: this.id
        }), this.useLoaderDeps = i => Mp({ ...i,
            from: this.id
        }), this.useLoaderData = i => xp({ ...i,
            from: this.id
        }), this.useNavigate = () => Cp({
            from: this.fullPath
        }), this.Link = Ni.forwardRef((i, u) => Z.jsx(Dp, {
            ref: u,
            from: this.fullPath,
            ...i
        }))
    }
};

function u2(a) {
    return new i2(a)
}

function Lp(a) {
    return new s2(a, {
        silent: !0
    }).createRoute
}
var s2 = class {
    constructor(a, i) {
        this.path = a, this.createRoute = u => {
            const r = l2(u);
            return r.isRoot = !1, r
        }, this.silent = i ? .silent
    }
};

function Up(a, i) {
    let u, r, c, f;
    const h = () => (u || (u = a().then(p => {
            u = void 0, r = p[i]
        }).catch(p => {
            if (c = p, R0(c) && c instanceof Error && typeof window < "u" && typeof sessionStorage < "u") {
                const m = `tanstack_router_reload:${c.message}`;
                sessionStorage.getItem(m) || (sessionStorage.setItem(m, "1"), f = !0)
            }
        })), u),
        y = function(m) {
            if (f) throw window.location.reload(), new Promise(() => {});
            if (c) throw c;
            if (!r)
                if (bs) bs(h());
                else throw h();
            return et.createElement(r, m)
        };
    return y.preload = h, y
}

function r2(a) {
    const i = fe(),
        u = `not-found-${Ft(i.stores.location,r=>r.pathname)}-${Ft(i.stores.status,r=>r)}`;
    return Z.jsx(xc, {
        getResetKey: () => u,
        onCatch: (r, c) => {
            if (ne(r)) a.onCatch ? .(r, c);
            else throw r
        },
        errorComponent: ({
            error: r
        }) => {
            if (ne(r)) return a.fallback ? .(r);
            throw r
        },
        children: a.children
    })
}

function o2() {
    return Z.jsx("p", {
        children: "Not Found"
    })
}

function Tl(a) {
    return Z.jsx(Z.Fragment, {
        children: a.children
    })
}

function Np(a, i, u) {
    return i.options.notFoundComponent ? Z.jsx(i.options.notFoundComponent, { ...u
    }) : a.options.defaultNotFoundComponent ? Z.jsx(a.options.defaultNotFoundComponent, { ...u
    }) : Z.jsx(o2, {})
}

function c2(a) {
    return null
}

function f2() {
    return c2(fe()), null
}
var Bp = et.memo(function({
    matchId: i
}) {
    const u = fe(),
        r = u.stores.matchStores.get(i);
    r || Ee();
    const c = Ft(u.stores.loadedAt, h => h),
        f = Ft(r, h => h);
    return Z.jsx(d2, {
        router: u,
        matchId: i,
        resetKey: c,
        matchState: et.useMemo(() => {
            const h = f.routeId,
                y = u.routesById[h].parentRoute ? .id;
            return {
                routeId: h,
                ssr: f.ssr,
                _displayPending: f._displayPending,
                parentRouteId: y
            }
        }, [f._displayPending, f.routeId, f.ssr, u.routesById])
    })
});

function d2({
    router: a,
    matchId: i,
    resetKey: u,
    matchState: r
}) {
    const c = a.routesById[r.routeId],
        f = c.options.pendingComponent ? ? a.options.defaultPendingComponent,
        h = f ? Z.jsx(f, {}) : null,
        y = c.options.errorComponent ? ? a.options.defaultErrorComponent,
        p = c.options.onCatch ? ? a.options.defaultOnCatch,
        m = c.isRoot ? c.options.notFoundComponent ? ? a.options.notFoundRoute ? .options.component : c.options.notFoundComponent,
        S = r.ssr === !1 || r.ssr === "data-only",
        g = (!c.isRoot || c.options.wrapInSuspense || S) && (c.options.wrapInSuspense ? ? f ? ? (c.options.errorComponent ? .preload || S)) ? et.Suspense : Tl,
        _ = y ? xc : Tl,
        E = m ? r2 : Tl;
    return Z.jsxs(c.isRoot ? c.options.shellComponent ? ? Tl : Tl, {
        children: [Z.jsx(zs.Provider, {
            value: i,
            children: Z.jsx(g, {
                fallback: h,
                children: Z.jsx(_, {
                    getResetKey: () => u,
                    errorComponent: y || Mc,
                    onCatch: (O, w) => {
                        if (ne(O)) throw O.routeId ? ? = r.routeId, O;
                        p ? .(O, w)
                    },
                    children: Z.jsx(E, {
                        fallback: O => {
                            if (O.routeId ? ? = r.routeId, !m || O.routeId && O.routeId !== r.routeId || !O.routeId && !c.isRoot) throw O;
                            return et.createElement(m, O)
                        },
                        children: S || r._displayPending ? Z.jsx(D_, {
                            fallback: h,
                            children: Z.jsx(Ry, {
                                matchId: i
                            })
                        }) : Z.jsx(Ry, {
                            matchId: i
                        })
                    })
                })
            })
        }), r.parentRouteId === Da ? Z.jsxs(Z.Fragment, {
            children: [Z.jsx(h2, {
                resetKey: u
            }), a.options.scrollRestoration && Oy ? Z.jsx(f2, {}) : null]
        }) : null]
    })
}

function h2({
    resetKey: a
}) {
    const i = fe(),
        u = et.useRef(void 0);
    return Ui(() => {
        const r = i.latestLocation.href;
        (u.current === void 0 || u.current !== r) && (i.emit({
            type: "onRendered",
            ...xl(i.stores.location.get(), i.stores.resolvedLocation.get())
        }), u.current = r)
    }, [i.latestLocation.state.__TSR_key, a, i]), null
}
var Ry = et.memo(function({
        matchId: i
    }) {
        const u = fe(),
            r = (S, g) => u.getMatch(S.id) ? ._nonReactive[g] ? ? S._nonReactive[g],
            c = u.stores.matchStores.get(i);
        c || Ee();
        const f = Ft(c, S => S),
            h = f.routeId,
            y = u.routesById[h],
            p = et.useMemo(() => {
                const S = (u.routesById[h].options.remountDeps ? ? u.options.defaultRemountDeps) ? .({
                    routeId: h,
                    loaderDeps: f.loaderDeps,
                    params: f._strictParams,
                    search: f._strictSearch
                });
                return S ? JSON.stringify(S) : void 0
            }, [h, f.loaderDeps, f._strictParams, f._strictSearch, u.options.defaultRemountDeps, u.routesById]),
            m = et.useMemo(() => {
                const S = y.options.component ? ? u.options.defaultComponent;
                return S ? Z.jsx(S, {}, p) : Z.jsx(m2, {})
            }, [p, y.options.component, u.options.defaultComponent]);
        if (f._displayPending) throw r(f, "displayPendingPromise");
        if (f._forcePending) throw r(f, "minPendingPromise");
        if (f.status === "pending") {
            const S = y.options.pendingMinMs ? ? u.options.defaultPendingMinMs;
            if (S) {
                const g = u.getMatch(f.id);
                if (g && !g._nonReactive.minPendingPromise) {
                    const _ = Ua();
                    g._nonReactive.minPendingPromise = _, setTimeout(() => {
                        _.resolve(), g._nonReactive.minPendingPromise = void 0
                    }, S)
                }
            }
            throw r(f, "loadPromise")
        }
        if (f.status === "notFound") return ne(f.error) || Ee(), Np(u, y, f.error);
        if (f.status === "redirected") throw _e(f.error) || Ee(), r(f, "loadPromise");
        if (f.status === "error") throw f.error;
        return m
    }),
    m2 = et.memo(function() {
        const i = fe(),
            u = et.useContext(zs);
        let r, c = !1,
            f; {
            const m = u ? i.stores.matchStores.get(u) : void 0;
            [r, c] = Ft(m, S => [S ? .routeId, S ? .globalNotFound ? ? !1]), f = Ft(i.stores.matchesId, S => S[S.findIndex(g => g === u) + 1])
        }
        const h = r ? i.routesById[r] : void 0,
            y = i.options.defaultPendingComponent ? Z.jsx(i.options.defaultPendingComponent, {}) : null;
        if (c) return h || Ee(), Np(i, h, void 0);
        if (!f) return null;
        const p = Z.jsx(Bp, {
            matchId: f
        });
        return r === Da ? Z.jsx(et.Suspense, {
            fallback: y,
            children: p
        }) : p
    });

function y2() {
    const a = fe(),
        i = et.useRef({
            router: a,
            mounted: !1
        }),
        [u, r] = et.useState(!1),
        c = Ft(a.stores.isLoading, g => g),
        f = Ft(a.stores.hasPending, g => g),
        h = lc(c),
        y = c || u || f,
        p = lc(y),
        m = c || f,
        S = lc(m);
    return a.startTransition = g => {
        r(!0), et.startTransition(() => {
            g(), r(!1)
        })
    }, et.useEffect(() => {
        const g = a.history.subscribe(a.load),
            _ = a.buildLocation({
                to: a.latestLocation.pathname,
                search: !0,
                params: !0,
                hash: !0,
                state: !0,
                _includeValidateSearch: !0
            });
        return na(a.latestLocation.publicHref) !== na(_.publicHref) && a.commitLocation({ ..._,
            replace: !0
        }), () => {
            g()
        }
    }, [a, a.history]), Ui(() => {
        if (typeof window < "u" && a.ssr || i.current.router === a && i.current.mounted) return;
        i.current = {
            router: a,
            mounted: !0
        }, (async () => {
            try {
                await a.load()
            } catch (_) {
                console.error(_)
            }
        })()
    }, [a]), Ui(() => {
        h && !c && a.emit({
            type: "onLoad",
            ...xl(a.stores.location.get(), a.stores.resolvedLocation.get())
        })
    }, [h, a, c]), Ui(() => {
        S && !m && a.emit({
            type: "onBeforeRouteMount",
            ...xl(a.stores.location.get(), a.stores.resolvedLocation.get())
        })
    }, [m, S, a]), Ui(() => {
        if (p && !y) {
            const g = xl(a.stores.location.get(), a.stores.resolvedLocation.get());
            a.emit({
                type: "onResolved",
                ...g
            }), Tp(() => {
                a.stores.status.set("idle"), a.stores.resolvedLocation.set(a.stores.location.get())
            }), g.hrefChanged && xS(a)
        }
    }, [y, p, a]), null
}

function p2() {
    const a = fe(),
        i = a.routesById[Da].options.pendingComponent ? ? a.options.defaultPendingComponent,
        u = i ? Z.jsx(i, {}) : null,
        r = Z.jsxs(typeof document < "u" && a.ssr ? Tl : et.Suspense, {
            fallback: u,
            children: [Z.jsx(y2, {}), Z.jsx(v2, {})]
        });
    return a.options.InnerWrap ? Z.jsx(a.options.InnerWrap, {
        children: r
    }) : r
}

function v2() {
    const a = fe(),
        i = Ft(a.stores.firstId, c => c),
        u = Ft(a.stores.loadedAt, c => c),
        r = i ? Z.jsx(Bp, {
            matchId: i
        }) : null;
    return Z.jsx(zs.Provider, {
        value: i,
        children: a.options.disableGlobalCatchBoundary ? r : Z.jsx(xc, {
            getResetKey: () => u,
            errorComponent: Mc,
            onCatch: void 0,
            children: r
        })
    })
}
var g2 = a => ({
        createMutableStore: gy,
        createReadonlyStore: gy,
        batch: Tp
    }),
    S2 = a => new b2(a),
    b2 = class extends yS {
        constructor(a) {
            super(a, g2)
        }
    };

function _2({
    router: a,
    children: i,
    ...u
}) {
    Object.keys(u).length > 0 && a.update({ ...a.options,
        ...u,
        context: { ...a.options.context,
            ...u.context
        }
    });
    const r = Z.jsx(Ep.Provider, {
        value: a,
        children: i
    });
    return a.options.Wrap ? Z.jsx(a.options.Wrap, {
        children: r
    }) : r
}

function E2({
    router: a,
    ...i
}) {
    return Z.jsx(_2, {
        router: a,
        ...i,
        children: Z.jsx(p2, {})
    })
}

function jp({
    tag: a,
    attrs: i,
    children: u,
    nonce: r
}) {
    switch (a) {
        case "title":
            return Z.jsx("title", { ...i,
                suppressHydrationWarning: !0,
                children: u
            });
        case "meta":
            return Z.jsx("meta", { ...i,
                suppressHydrationWarning: !0
            });
        case "link":
            return Z.jsx("link", { ...i,
                precedence: i ? .precedence ? ? (i ? .rel === "stylesheet" ? "default" : void 0),
                nonce: r,
                suppressHydrationWarning: !0
            });
        case "style":
            return Z.jsx("style", { ...i,
                dangerouslySetInnerHTML: {
                    __html: u
                },
                nonce: r
            });
        case "script":
            return Z.jsx(R2, {
                attrs: i,
                children: u
            });
        default:
            return null
    }
}

function R2({
    attrs: a,
    children: i
}) {
    fe();
    const u = Oc(),
        r = typeof a ? .type == "string" && a.type !== "" && a.type !== "text/javascript" && a.type !== "module";
    if (et.useEffect(() => {
            if (!r) {
                if (a ? .src) {
                    const c = (() => {
                        try {
                            const h = document.baseURI || window.location.href;
                            return new URL(a.src, h).href
                        } catch {
                            return a.src
                        }
                    })();
                    if (Array.from(document.querySelectorAll("script[src]")).find(h => h.src === c)) return;
                    const f = document.createElement("script");
                    for (const [h, y] of Object.entries(a)) h !== "suppressHydrationWarning" && y !== void 0 && y !== !1 && f.setAttribute(h, typeof y == "boolean" ? "" : String(y));
                    return document.head.appendChild(f), () => {
                        f.parentNode && f.parentNode.removeChild(f)
                    }
                }
                if (typeof i == "string") {
                    const c = typeof a ? .type == "string" ? a.type : "text/javascript",
                        f = typeof a ? .nonce == "string" ? a.nonce : void 0;
                    if (Array.from(document.querySelectorAll("script:not([src])")).find(y => {
                            if (!(y instanceof HTMLScriptElement)) return !1;
                            const p = y.getAttribute("type") ? ? "text/javascript",
                                m = y.getAttribute("nonce") ? ? void 0;
                            return y.textContent === i && p === c && m === f
                        })) return;
                    const h = document.createElement("script");
                    if (h.textContent = i, a)
                        for (const [y, p] of Object.entries(a)) y !== "suppressHydrationWarning" && p !== void 0 && p !== !1 && h.setAttribute(y, typeof p == "boolean" ? "" : String(p));
                    return document.head.appendChild(h), () => {
                        h.parentNode && h.parentNode.removeChild(h)
                    }
                }
            }
        }, [a, i, r]), r && typeof i == "string") return Z.jsx("script", { ...a,
        suppressHydrationWarning: !0,
        dangerouslySetInnerHTML: {
            __html: i
        }
    });
    if (!u) {
        if (a ? .src) return Z.jsx("script", { ...a,
            suppressHydrationWarning: !0
        });
        if (typeof i == "string") return Z.jsx("script", { ...a,
            dangerouslySetInnerHTML: {
                __html: i
            },
            suppressHydrationWarning: !0
        })
    }
    return null
}
var T2 = a => {
    const i = fe(),
        u = i.options.ssr ? .nonce,
        r = Ft(i.stores.matches, m => m.map(S => S.meta).filter(Boolean), be),
        c = et.useMemo(() => {
            const m = [],
                S = {};
            let g;
            for (let _ = r.length - 1; _ >= 0; _--) {
                const E = r[_];
                for (let O = E.length - 1; O >= 0; O--) {
                    const w = E[O];
                    if (w)
                        if (w.title) g || (g = {
                            tag: "title",
                            children: w.title
                        });
                        else if ("script:ld+json" in w) try {
                        const A = JSON.stringify(w["script:ld+json"]);
                        m.push({
                            tag: "script",
                            attrs: {
                                type: "application/ld+json"
                            },
                            children: O0(A)
                        })
                    } catch {} else {
                        const A = w.name ? ? w.property;
                        if (A) {
                            if (S[A]) continue;
                            S[A] = !0
                        }
                        m.push({
                            tag: "meta",
                            attrs: { ...w,
                                nonce: u
                            }
                        })
                    }
                }
            }
            return g && m.push(g), u && m.push({
                tag: "meta",
                attrs: {
                    property: "csp-nonce",
                    content: u
                }
            }), m.reverse(), m
        }, [r, u]),
        f = Ft(i.stores.matches, m => {
            const S = m.map(E => E.links).filter(Boolean).flat(1).map(E => ({
                    tag: "link",
                    attrs: { ...E,
                        nonce: u
                    }
                })),
                g = i.ssr ? .manifest,
                _ = m.map(E => g ? .routes[E.routeId] ? .assets ? ? []).filter(Boolean).flat(1).filter(E => E.tag === "link").map(E => ({
                    tag: "link",
                    attrs: { ...E.attrs,
                        crossOrigin: ny(a, "stylesheet") ? ? E.attrs ? .crossOrigin,
                        suppressHydrationWarning: !0,
                        nonce: u
                    }
                }));
            return [...S, ..._]
        }, be),
        h = Ft(i.stores.matches, m => {
            const S = [];
            return m.map(g => i.looseRoutesById[g.routeId]).forEach(g => i.ssr ? .manifest ? .routes[g.id] ? .preloads ? .filter(Boolean).forEach(_ => {
                const E = TS(_);
                S.push({
                    tag: "link",
                    attrs: {
                        rel: "modulepreload",
                        href: E.href,
                        crossOrigin: ny(a, "modulepreload") ? ? E.crossOrigin,
                        nonce: u
                    }
                })
            })), S
        }, be),
        y = Ft(i.stores.matches, m => m.map(S => S.styles).flat(1).filter(Boolean).map(({
            children: S,
            ...g
        }) => ({
            tag: "style",
            attrs: { ...g,
                nonce: u
            },
            children: S
        })), be),
        p = Ft(i.stores.matches, m => m.map(S => S.headScripts).flat(1).filter(Boolean).map(({
            children: S,
            ...g
        }) => ({
            tag: "script",
            attrs: { ...g,
                nonce: u
            },
            children: S
        })), be);
    return A2([...c, ...h, ...f, ...y, ...p], m => JSON.stringify(m))
};

function A2(a, i) {
    const u = new Set;
    return a.filter(r => {
        const c = i(r);
        return u.has(c) ? !1 : (u.add(c), !0)
    })
}

function x2(a) {
    const i = T2(a.assetCrossOrigin),
        u = fe().options.ssr ? .nonce;
    return Z.jsx(Z.Fragment, {
        children: i.map(r => et.createElement(jp, { ...r,
            key: `tsr-meta-${JSON.stringify(r)}`,
            nonce: u
        }))
    })
}
var M2 = () => {
    const a = fe(),
        i = a.options.ssr ? .nonce,
        u = f => {
            const h = [],
                y = a.ssr ? .manifest;
            return y ? (f.map(p => a.looseRoutesById[p.routeId]).forEach(p => y.routes[p.id] ? .assets ? .filter(m => m.tag === "script").forEach(m => {
                h.push({
                    tag: "script",
                    attrs: { ...m.attrs,
                        nonce: i
                    },
                    children: m.children
                })
            })), h) : []
        },
        r = f => f.map(h => h.scripts).flat(1).filter(Boolean).map(({
            children: h,
            ...y
        }) => ({
            tag: "script",
            attrs: { ...y,
                suppressHydrationWarning: !0,
                nonce: i
            },
            children: h
        })),
        c = Ft(a.stores.matches, u, be);
    return O2(a, Ft(a.stores.matches, r, be), c)
};

function O2(a, i, u) {
    let r;
    a.serverSsr && (r = a.serverSsr.takeBufferedScripts());
    const c = [...i, ...u];
    return r && c.unshift(r), Z.jsx(Z.Fragment, {
        children: c.map((f, h) => et.createElement(jp, { ...f,
            key: `tsr-scripts-${f.tag}-${h}`
        }))
    })
}
const Hp = (...a) => a.filter((i, u, r) => !!i && i.trim() !== "" && r.indexOf(i) === u).join(" ").trim();
const z2 = a => a.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const C2 = a => a.replace(/^([A-Z])|[\s-_]+(\w)/g, (i, u, r) => r ? r.toUpperCase() : u.toLowerCase());
const Ty = a => {
    const i = C2(a);
    return i.charAt(0).toUpperCase() + i.slice(1)
};
var w2 = {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
};
const D2 = a => {
    for (const i in a)
        if (i.startsWith("aria-") || i === "role" || i === "title") return !0;
    return !1
};
const L2 = et.forwardRef(({
    color: a = "currentColor",
    size: i = 24,
    strokeWidth: u = 2,
    absoluteStrokeWidth: r,
    className: c = "",
    children: f,
    iconNode: h,
    ...y
}, p) => et.createElement("svg", {
    ref: p,
    ...w2,
    width: i,
    height: i,
    stroke: a,
    strokeWidth: r ? Number(u) * 24 / Number(i) : u,
    className: Hp("lucide", c),
    ...!f && !D2(y) && {
        "aria-hidden": "true"
    },
    ...y
}, [...h.map(([m, S]) => et.createElement(m, S)), ...Array.isArray(f) ? f : [f]]));
const U2 = (a, i) => {
    const u = et.forwardRef(({
        className: r,
        ...c
    }, f) => et.createElement(L2, {
        ref: f,
        iconNode: i,
        className: Hp(`lucide-${z2(Ty(a))}`, `lucide-${a}`, r),
        ...c
    }));
    return u.displayName = Ty(a), u
};
const N2 = [
        ["path", {
            d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
            key: "9njp5v"
        }]
    ],
    B2 = U2("phone", N2),
    zc = u2({
        head: () => ({
            meta: [{
                charSet: "utf-8"
            }, {
                name: "viewport",
                content: "width=device-width, initial-scale=1"
            }, {
                title: "CallPilot — AI That Answers Calls & Books Appointments 24/7"
            }, {
                name: "description",
                content: "Never miss a call again. CallPilot is an AI voice agent that answers calls, qualifies leads, and books appointments automatically — even at 2am."
            }]
        }),
        shellComponent: j2
    });

function j2({
    children: a
}) {
    return Z.jsxs("html", {
        lang: "en",
        children: [Z.jsxs("head", {
            children: [Z.jsx(x2, {}), Z.jsx("link", {
                rel: "preconnect",
                href: "https://fonts.googleapis.com"
            }), Z.jsx("link", {
                rel: "preconnect",
                href: "https://fonts.gstatic.com",
                crossOrigin: "anonymous"
            }), Z.jsx("link", {
                href: "https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;12..96,600;12..96,700;12..96,800&family=Instrument+Sans:ital,wght@0,400;0,500;0,600;1,400&display=swap",
                rel: "stylesheet"
            })]
        }), Z.jsxs("body", {
            className: "noise-overlay",
            children: [Z.jsx(H2, {}), Z.jsx("div", {
                style: {
                    height: "64px"
                }
            }), a, Z.jsx(M2, {})]
        })]
    })
}

function H2() {
    return Z.jsx("nav", {
        className: "fixed top-0 left-0 right-0 z-50 border-b border-wire",
        style: {
            backgroundColor: "rgba(9,9,11,0.92)",
            backdropFilter: "blur(12px)"
        },
        children: Z.jsxs("div", {
            className: "max-w-5xl mx-auto px-6 h-16 flex items-center justify-between",
            children: [Z.jsxs("a", {
                href: "/",
                className: "flex items-center gap-2.5",
                children: [Z.jsx("div", {
                    className: "w-7 h-7 rounded-lg bg-gold flex items-center justify-center",
                    children: Z.jsx(B2, {
                        size: 13,
                        className: "text-ink"
                    })
                }), Z.jsx("span", {
                    className: "font-bold text-lg text-cream",
                    style: {
                        fontFamily: "Bricolage Grotesque, sans-serif"
                    },
                    children: "CallPilot"
                })]
            }), Z.jsxs("div", {
                className: "hidden md:flex items-center gap-8 text-sm text-dim",
                children: [Z.jsx("a", {
                    href: "#how-it-works",
                    className: "hover:text-cream transition-colors",
                    children: "How It Works"
                }), Z.jsx("a", {
                    href: "#pricing",
                    className: "hover:text-cream transition-colors",
                    children: "Pricing"
                }), Z.jsx("a", {
                    href: "#faq",
                    className: "hover:text-cream transition-colors",
                    children: "FAQ"
                })]
            }), Z.jsx("a", {
                href: "#demo",
                className: "px-5 py-2 bg-gold text-ink rounded-lg font-semibold text-sm hover:bg-amber-400 transition-colors",
                children: "Book Demo"
            })]
        })
    })
}
const q2 = "modulepreload",
    Y2 = function(a) {
        return "/" + a
    },
    Ay = {},
    qp = function(i, u, r) {
        let c = Promise.resolve();
        if (u && u.length > 0) {
            let p = function(m) {
                return Promise.all(m.map(S => Promise.resolve(S).then(g => ({
                    status: "fulfilled",
                    value: g
                }), g => ({
                    status: "rejected",
                    reason: g
                }))))
            };
            document.getElementsByTagName("link");
            const h = document.querySelector("meta[property=csp-nonce]"),
                y = h ? .nonce || h ? .getAttribute("nonce");
            c = p(u.map(m => {
                if (m = Y2(m), m in Ay) return;
                Ay[m] = !0;
                const S = m.endsWith(".css"),
                    g = S ? '[rel="stylesheet"]' : "";
                if (document.querySelector(`link[href="${m}"]${g}`)) return;
                const _ = document.createElement("link");
                if (_.rel = S ? "stylesheet" : q2, S || (_.as = "script"), _.crossOrigin = "", _.href = m, y && _.setAttribute("nonce", y), document.head.appendChild(_), S) return new Promise((E, O) => {
                    _.addEventListener("load", E), _.addEventListener("error", () => O(new Error(`Unable to preload CSS for ${m}`)))
                })
            }))
        }

        function f(h) {
            const y = new Event("vite:preloadError", {
                cancelable: !0
            });
            if (y.payload = h, window.dispatchEvent(y), !y.defaultPrevented) throw h
        }
        return c.then(h => {
            for (const y of h || []) y.status === "rejected" && f(y.reason);
            return i().catch(f)
        })
    },
    G2 = () => qp(() =>
        import ("./faq-NaKEF1lm.js"), __vite__mapDeps([0, 1])),
    X2 = Lp("/faq")({
        component: Up(G2, "component")
    }),
    V2 = () => qp(() =>
        import ("./index-AJhdsfAu.js"), __vite__mapDeps([2, 1])),
    Q2 = Lp("/")({
        component: Up(V2, "component")
    }),
    Z2 = X2.update({
        id: "/faq",
        path: "/faq",
        getParentRoute: () => zc
    }),
    K2 = Q2.update({
        id: "/",
        path: "/",
        getParentRoute: () => zc
    }),
    J2 = {
        IndexRoute: K2,
        FaqRoute: Z2
    },
    k2 = zc._addFileChildren(J2),
    P2 = () => S2({
        routeTree: k2,
        scrollRestoration: !0,
        defaultPreloadStaleTime: 0
    });
async function F2() {
    const a = await P2();
    let i;
    return i = [], window.__TSS_START_OPTIONS__ = {
        serializationAdapters: i
    }, i.push(R_), a.options.serializationAdapters && i.push(...a.options.serializationAdapters), a.update({
        basepath: "",
        serializationAdapters: i
    }), a.stores.matchesId.get().length || await A_(a), a
}
async function I2() {
    const a = await F2();
    return window.$_TSR ? .h(), a
}
var cc;

function W2() {
    return cc || (cc = I2()), Z.jsx(z_, {
        promise: cc,
        children: a => Z.jsx(E2, {
            router: a
        })
    })
}
et.startTransition(() => {
    m0.hydrateRoot(document, Z.jsx(et.StrictMode, {
        children: Z.jsx(W2, {})
    }))
});
export {
    Dp as L, B2 as P, U2 as c, Z as j, et as r
};